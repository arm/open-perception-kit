"""Relink the isolated benchmark with the current inference attribute schema."""
from pathlib import Path
import json
import shlex
import shutil
import subprocess

BUILD = Path('/work/development/build')
ROOT = Path('/bench')
SCHEMA_NAME = 'urn:arm:opk:schema:inference-op:v1'
HEADER_DELIMITER = 'OPKSCHEMA'
source = ROOT / 'config-validator'
source.mkdir(exist_ok=True)
schema = json.loads((ROOT / 'inference.schema.json').read_text())
assert schema['$id'] == SCHEMA_NAME
header = (BUILD / 'config-validator/EmbeddedSchemas.h').read_text()
entry = header.index('EmbeddedSchema{"' + SCHEMA_NAME + '"')
start = header.index('R"' + HEADER_DELIMITER + '(', entry) + len('R"' + HEADER_DELIMITER + '(')
end = header.index(')' + HEADER_DELIMITER + '"', start)
# This is a private backport into the old binary, leaving its checkout and generated header intact.
(source / 'EmbeddedSchemas.h').write_text(header[:start] + json.dumps(schema, indent=2) + header[end:])
shutil.copyfile('/work/development/config-validator/SchemaBundle.cpp', source / 'SchemaBundle.cpp')
commands = json.loads((BUILD / 'compile_commands.json').read_text())
entry = next(row for row in commands if row['file'].endswith('/config-validator/SchemaBundle.cpp'))
args = shlex.split(entry['command'])
original_object = args[args.index('-o') + 1]
output = str(ROOT / 'lib' / Path(original_object).name)
for option in ('-o', '-MQ', '-MF'):
    args[args.index(option) + 1] = output + '.d' if option == '-MF' else output
args[args.index('-c') + 1] = str(source / 'SchemaBundle.cpp')
subprocess.run(args, cwd=BUILD, check=True)
archive = ROOT / 'lib/libopk-config-validator.a'
members = subprocess.check_output(['ar', 't', 'meson-out/libopk-config-validator.a'], cwd=BUILD, text=True).splitlines()
objects = [output if Path(member).name == Path(output).name else member for member in members]
archive.unlink(missing_ok=True)
subprocess.run(['ar', 'rcs', str(archive), *objects], cwd=BUILD, check=True)
link = subprocess.check_output(['ninja','-t','commands','meson-out/libopk-common.so'],cwd=BUILD,text=True).splitlines()[-1]
args = [str(archive) if arg == 'meson-out/libopk-config-validator.a' else arg for arg in shlex.split(link)]
common = ROOT / 'lib/libopk-common.so'
if common.is_symlink():
    common.unlink()
args[args.index('-o') + 1] = str(common)
subprocess.run(args,cwd=BUILD,check=True)
