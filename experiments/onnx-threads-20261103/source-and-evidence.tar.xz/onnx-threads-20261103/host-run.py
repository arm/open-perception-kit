#!/usr/bin/env python3
"""Serialize this task's RPi commands and restore the CPU governor afterward."""
import fcntl
import json
import pathlib
import subprocess
import sys
import threading
import time

BENCH_ROOT = pathlib.Path(__file__).resolve().parent
HARDWARE_SAMPLE_INTERVAL_SECONDS = 5
COOLDOWN_SECONDS = 8
MICROSECONDS_PER_SECOND = 1_000_000
MAXIMUM_OTHER_CONTAINER_CPU_CORES = 0.1
BENCH_CONTAINER_ID = subprocess.check_output(["docker", "inspect", "opk-thread-video-20261103", "--format", "{{.Id}}"], text=True).strip()


def hardware():
    return {
        "time": time.time(),
        "temperature": subprocess.check_output(["vcgencmd", "measure_temp"], text=True).strip(),
        "throttled": subprocess.check_output(["vcgencmd", "get_throttled"], text=True).strip(),
        "frequency": subprocess.check_output(["vcgencmd", "measure_clock", "arm"], text=True).strip(),
        "load": pathlib.Path("/proc/loadavg").read_text().strip(),
        "container_cpu_usage_us": {path.parent.name: int(dict(line.split() for line in path.read_text().splitlines())["usage_usec"]) for path in pathlib.Path("/sys/fs/cgroup/system.slice").glob("docker-*.scope/cpu.stat")},
    }


def set_governor(path, value):
    subprocess.run(["sudo", "-n", "tee", str(path)], input=value + "\n", text=True,
                   stdout=subprocess.DEVNULL, check=True)


def main():
    label, *command = sys.argv[1:]
    assert command and pathlib.Path(label).name == label
    evidence = BENCH_ROOT / "evidence"
    evidence.mkdir(exist_ok=True)
    records = []
    stop = threading.Event()
    monitor_errors = []

    def monitor():
        while not stop.wait(HARDWARE_SAMPLE_INTERVAL_SECONDS):
            try:
                records.append(hardware())
            except Exception as error:
                monitor_errors.append(str(error))
                return

    with (BENCH_ROOT / "host.lock").open("a") as lock:
        print("WAIT LOCK " + label, flush=True)
        fcntl.flock(lock, fcntl.LOCK_EX)
        governors = {path: path.read_text().strip() for path in
                     pathlib.Path("/sys/devices/system/cpu/cpufreq").glob("policy*/scaling_governor")}
        thread = None
        exit_code = None
        try:
            records.append(hardware())
            assert records[-1]["throttled"] == "throttled=0x0", records[-1]
            for path in governors:
                set_governor(path, "performance")
            time.sleep(COOLDOWN_SECONDS)
            thread = threading.Thread(target=monitor)
            thread.start()
            print("RUN " + label, flush=True)
            exit_code = subprocess.run(command, check=False).returncode
        finally:
            stop.set()
            if thread:
                thread.join()
            records.append(hardware())
            for path, governor in governors.items():
                set_governor(path, governor)
            external_cpu_samples = []
            for before, after in zip(records, records[1:]):
                elapsed_seconds = after["time"] - before["time"]
                other_cpu_us = sum(value - before["container_cpu_usage_us"].get(name, value) for name, value in after["container_cpu_usage_us"].items() if BENCH_CONTAINER_ID not in name)
                external_cpu_samples.append(other_cpu_us / MICROSECONDS_PER_SECOND / elapsed_seconds)
            report = {"other_container_cpu_cores": external_cpu_samples, "maximum_allowed_other_container_cpu_cores": MAXIMUM_OTHER_CONTAINER_CPU_CORES, "command": command, "original_governors": {str(k): v for k, v in governors.items()},
                      "restored_governors": {str(k): k.read_text().strip() for k in governors},
                      "samples": records, "monitor_errors": monitor_errors, "exit_code": exit_code}
            (evidence / (label + "-hardware.json")).write_text(json.dumps(report, indent=2) + "\n")
        assert exit_code == 0, exit_code
        assert not monitor_errors, monitor_errors
        assert all(cores <= MAXIMUM_OTHER_CONTAINER_CPU_CORES for cores in external_cpu_samples), "Other container CPU contention invalidates this run"
        assert all(row["throttled"] == "throttled=0x0" for row in records), "Throttled run"
        print("COMPLETE " + label, flush=True)


if __name__ == "__main__":
    main()
