#!/bin/sh
set -eu
# Reuse the repository's built runtime and cached public header dependency.
expected_include=$(find /work/development/subprojects -path '*/include/tl/expected.hpp' -print -quit)
expected_include=${expected_include%/tl/expected.hpp}
g++ -std=c++20 -O3 -DNDEBUG -I/work/development -I"$expected_include" /bench/scripts/opchain-bench.cpp /work/development/build/meson-out/opk-runtime.so -Wl,-rpath,/work/development/build/meson-out -o /bench/opchain-bench
g++ -std=c++20 -O3 -shared -fPIC -I/work/development /bench/scripts/perf-bridge.cpp /work/development/build/meson-out/opk-runtime.so -Wl,-rpath,/work/development/build/meson-out -o /bench/libperfbridge.so
