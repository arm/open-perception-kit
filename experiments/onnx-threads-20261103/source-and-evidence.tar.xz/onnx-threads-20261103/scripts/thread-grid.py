"""EXPKITS-1360: screen all Pi CPU counts, then confirm finalists on real video."""
import argparse
import base64
import itertools
import json
import os
from pathlib import Path
import statistics
import subprocess
import time
import sweep

ROOT = Path('/work')
BENCH = Path('/bench')
COUNTS = (0, 1, 2, 3, 4)
REPEATS = 3
FINALISTS_PER_MODE = 2
COOLDOWN_SECONDS = 2
VIDEO_FRAMES = 417
TIMEOUT_SECONDS = 900
AUDIO_MODELS = {"silero-vad", "smart-turn"}
AUDIO_SCREEN_WINDOWS = {"silero-vad": 300, "smart-turn": 60}
AUDIO_CONFIRM_WINDOWS = {"silero-vad": 10000, "smart-turn": 120}


def make_chain(model, pair, destination, detector_pair=None):
    source = ROOT / 'config/models' / model
    result = json.loads((source / 'opchain.json').read_text())
    result['version'] = '1.1.0'
    for op in result['ops']:
        if op['id'] == 'opk-onnx-ops/Inference':
            attrs = op['attributes']
            attrs['modelDescriptor'] = str(source / 'model.json')
            if pair is not None:
                attrs.update(intraOpNumThreads=pair[0], interOpNumThreads=pair[1])
    if model in sweep.SECONDARY_MODELS:
        detector = json.loads((ROOT / 'config/models/ultraface-rfb-320/opchain.json').read_text())
        for op in detector['ops']:
            if op['id'] == 'opk-onnx-ops/Inference':
                op['attributes']['modelDescriptor'] = str(ROOT / 'config/models/ultraface-rfb-320/model.json')
                if detector_pair is not None:
                    op['attributes'].update(intraOpNumThreads=detector_pair[0], interOpNumThreads=detector_pair[1])
        result['ops'] = detector['ops'] + result['ops']
    destination.write_text(json.dumps(result, indent=2) + '\n')


def label(pair):
    return 'baseline' if pair is None else f'intra-{pair[0]}-inter-{pair[1]}'


def run(model, pair, stage, repeat, output, baseline, detector_pair, chain_override=None):
    name = label(pair)
    chain = Path(chain_override) if chain_override else output / f'opchain-{name}.json'
    if chain_override is None:
        make_chain(model, pair, chain, detector_pair)
    prefix = output / f'{stage}-{name}-r{repeat}'
    result_file = prefix.with_suffix('.result.json')
    if result_file.exists():
        cached = json.loads(result_file.read_text())
        cached['pair'] = tuple(cached['pair']) if cached['pair'] is not None else None
        return cached
    time.sleep(COOLDOWN_SECONDS)
    started_at = time.time()
    audio = model in AUDIO_MODELS
    command = ([str(BENCH / 'opchain-bench'), str(chain), str(sweep.IMAGE), str(prefix)]
               if stage == 'screen' else ['/usr/bin/python3', '/bench/scripts/video-confirm.py', model, str(chain), str(prefix)])
    environment = sweep.runtime_env(output / 'registry')
    if audio:
        command = ['/usr/bin/python3', '/bench/scripts/audio-confirm.py', model, str(chain), str(prefix)]
        audio_windows = (AUDIO_SCREEN_WINDOWS if stage == 'screen' else AUDIO_CONFIRM_WINDOWS)[model]
        environment['BENCH_AUDIO_WINDOWS'] = str(audio_windows)
    with prefix.with_suffix('.log').open('w') as log:
        subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT,
                       check=True, timeout=TIMEOUT_SECONDS)
    descriptor = json.loads((ROOT / 'config/models' / model / 'model.json').read_text())
    if stage == 'screen' and not audio:
        result = json.loads(prefix.with_suffix('.runtime.json').read_text())
        result.update(sweep.inference_stats(prefix.with_suffix('.csv'), descriptor['name']))
        assert result['inference_calls'] >= result['calls'], result
        result['fps'] = result['calls'] / result['wall_seconds']
        result['cpu_ms_per_frame'] = result['cpu_seconds'] * sweep.MILLISECONDS_PER_SECOND / result['calls']
        semantic = sweep.semantic_packet(prefix.with_suffix('.packet').read_bytes())
    else:
        result = json.loads(prefix.with_suffix('.json').read_text())
        assert result['frames'] == (audio_windows if audio else VIDEO_FRAMES) and result['ordered_pts_match']
        result.update(sweep.inference_stats(prefix.with_suffix('.csv'), descriptor['name'], result['warmup_frames']))
        assert result['all_inference_calls'] >= result['frames'], result
        packets = [json.loads(line) for line in prefix.with_suffix('.ndjson').read_text().splitlines()]
        assert len(packets) == result['frames']
        assert [packet['frame_counter'] for packet in packets] == list(range(result['frames']))
        if audio:
            assert [packet['pts_ns'] for packet in packets] == result['pts']
        semantic = [sweep.semantic_packet(base64.b64decode(packet['frame_results_packet_b64'])) for packet in packets]
    baseline_file = output / f'{stage}-baseline-r1.semantic.json'
    reference = json.loads(baseline_file.read_text()) if baseline_file.exists() else semantic
    result.update(sweep.semantic_status(semantic, reference, True, video=audio or stage != 'screen'))
    result.update(model=model, pair=pair, stage=stage, repeat=repeat, detector_pair=detector_pair, started_at=started_at, completed_at=time.time())
    prefix.with_suffix('.semantic.json').write_text(json.dumps(semantic))
    result_file.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('model', 'pair', 'stage', 'repeat', 'fps', 'semantic_output_matches')}), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('model')
    parser.add_argument('--detector-pair')
    parser.add_argument('--output-suffix', default='')
    parser.add_argument('--pairs', help='Semicolon-separated intra,inter confirmation pairs')
    parser.add_argument('--repeats', type=int, default=REPEATS)
    args = parser.parse_args()
    detector_pair = tuple(map(int, args.detector_pair.split(','))) if args.detector_pair else None
    output = BENCH / 'results' / (args.model + args.output_suffix)
    output.mkdir(parents=True, exist_ok=True)
    descriptor = ROOT / 'config/models' / args.model / 'model.json'
    model = json.loads(descriptor.read_text())
    manifest = {'model': args.model, 'model_sha256': sweep.sha256(descriptor.parent / model['modelFile']),
                'video_sha256': sweep.sha256(sweep.VIDEO), 'image_sha256': sweep.sha256(sweep.IMAGE),
                'audio_sha256': sweep.sha256(BENCH / 'speech.f32') if args.model in AUDIO_MODELS else None,
                'video_grid_counts': None if args.pairs else COUNTS, 'confirmation_pairs': args.pairs, 'confirmation_repeats': args.repeats, 'detector_pair': detector_pair}
    expected_hash = model.get('hfDownload', {}).get('sha256')
    if expected_hash:
        assert manifest['model_sha256'] == expected_hash, 'Model cache differs from pinned artifact'
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    requested_pairs = [tuple(map(int, pair.split(','))) for pair in args.pairs.split(';')] if args.pairs else None
    pairs = [None] + (requested_pairs or list(itertools.product(COUNTS, repeat=2)))
    video = [run(args.model, pair, 'video', 1, output, None, detector_pair) for pair in pairs]
    eligible = [r for r in video if r['pair'] is not None and r['semantic_output_matches']]
    sequential = sorted((r for r in eligible if r['pair'][1] == 1), key=lambda r: -r['fps'])
    parallel = sorted((r for r in eligible if r['pair'][1] != 1), key=lambda r: -r['fps'])
    finalists = [None] + (requested_pairs or [r['pair'] for r in sequential[:FINALISTS_PER_MODE] + parallel[:FINALISTS_PER_MODE]])
    for repeat in range(2, args.repeats + 1):
        for pair in finalists if repeat % 2 else list(reversed(finalists)):
            video.append(run(args.model, pair, 'video', repeat, output, None, detector_pair))
    ranking = []
    for pair in finalists:
        trials = [r for r in video if label(r['pair']) == label(pair)]
        ranking.append({'pair': pair, 'median_fps': statistics.median(r['fps'] for r in trials),
                        'min_fps': min(r['fps'] for r in trials), 'max_fps': max(r['fps'] for r in trials),
                        'semantic_output_matches': all(r['semantic_output_matches'] for r in trials),
                        'median_inference_ms': statistics.median(r['inference_mean_ms'] for r in trials),
                        'median_cpu_ms_per_frame': statistics.median(r['cpu_ms_per_frame'] for r in trials)})
    ranking.sort(key=lambda r: -r['median_fps'])
    (output / 'ranking.json').write_text(json.dumps(ranking, indent=2))
    print('RANKING ' + args.model + ' ' + json.dumps(ranking), flush=True)


if __name__ == '__main__':
    main()
