"""Adapted from the saved OPK real-video benchmark; first 120 complete frames."""
import ctypes
import json
from pathlib import Path
import statistics
import sys
import threading
import time
import gi

gi.require_version('Gst', '1.0')
from gi.repository import Gst
Gst.init(None)
FRAME_COUNT = 417
WARMUP_FRAMES = 30
PIPELINE_TIMEOUT_SECONDS = 300
DRAIN_TIMEOUT_SECONDS = 30
PUBLICATION_POLL_SECONDS = 0.02
NANOSECONDS_PER_SECOND = 1_000_000_000
NANOSECONDS_PER_MILLISECOND = 1_000_000
P95_FRACTION = .95
model, chain, output_prefix = sys.argv[1:]
prefix = Path(output_prefix)
assert not prefix.with_suffix('.ndjson').exists(), 'Preserve previous trial output before rerunning this prefix'
perf = ctypes.CDLL('/bench/libperfbridge.so')
perf.bench_history_write.argtypes = [ctypes.c_char_p]
perf.bench_history_write.restype = ctypes.c_bool
plugin_file = Gst.ElementFactory.find('opkinfer').get_plugin().get_filename()
assert plugin_file == '/bench/lib/libopkinfer.so', plugin_file
config = json.loads((Path('/work/config/pipelines') / (model + '.json')).read_text())
parts = []
for part in config['pipeline']:
    if part.startswith('filesrc '):
        part = 'filesrc location="/work/data/videos/GettyImages-1140581459.mov" !'
    elif part.startswith('opkinfer '):
        part = f'opkinfer name=infer opchain-path="{chain}" active=true !'
    elif part.startswith('opkcomm '):
        part = f'opkcomm method=file file-name="{prefix}.ndjson" !'
    elif part == 'opksink name=sink':
        part = 'fakesink name=sink sync=false'
    elif part == 'video/x-raw,format=BGRA !':
        part += ' identity name=limit !'
    parts.append(part)
launch = ' '.join(parts).replace('${OPK_PROJECT_ROOT:-/work}', '/work')
pipe = Gst.parse_launch(launch)
infer = pipe.get_by_name('infer')
sink = pipe.get_by_name('sink')
source_frames_seen = 0

def limit_frames(pad, info):
    global source_frames_seen
    source_frames_seen += 1
    return Gst.PadProbeReturn.OK if source_frames_seen <= FRAME_COUNT else Gst.PadProbeReturn.DROP

# Let the decoder drain naturally; only the measured prefix reaches inference.
pipe.get_by_name('limit').get_static_pad('src').add_probe(Gst.PadProbeType.BUFFER, limit_frames)
entered, exited, completed = [], [], []

def record(pad, info, target):
    buffer = info.get_buffer()
    target.append((buffer.pts, time.monotonic_ns(), time.process_time_ns()))
    return Gst.PadProbeReturn.OK

for pad, target in ((infer.get_static_pad('sink'), entered), (infer.get_static_pad('src'), exited), (sink.get_static_pad('sink'), completed)):
    pad.add_probe(Gst.PadProbeType.BUFFER, record, target)
drained = threading.Event()

def on_event(pad, info):
    if info.get_event().type == Gst.EventType.EOS:
        drained.set()
    return Gst.PadProbeReturn.OK

sink.get_static_pad('sink').add_probe(Gst.PadProbeType.EVENT_DOWNSTREAM, on_event)
perf.bench_history_enable()
started = time.monotonic()
try:
    assert pipe.set_state(Gst.State.PLAYING) != Gst.StateChangeReturn.FAILURE
    message = pipe.get_bus().timed_pop_filtered(PIPELINE_TIMEOUT_SECONDS * Gst.SECOND, Gst.MessageType.ERROR | Gst.MessageType.EOS)
    assert message is not None, 'Pipeline timed out'
    if message.type == Gst.MessageType.ERROR:
        raise RuntimeError(str(message.parse_error()))
    assert drained.wait(DRAIN_TIMEOUT_SECONDS), 'Final output did not drain'
    publication_deadline = time.monotonic() + DRAIN_TIMEOUT_SECONDS
    while prefix.with_suffix('.ndjson').read_bytes().count(b'\n') < FRAME_COUNT:
        assert time.monotonic() < publication_deadline, 'Metadata publisher did not drain'
        time.sleep(PUBLICATION_POLL_SECONDS)
    caps = infer.get_static_pad('sink').get_current_caps().to_string()
finally:
    pipe.set_state(Gst.State.NULL)
assert perf.bench_history_write(str(prefix.with_suffix('.csv')).encode()), 'Performance CSV invalid'
assert len(entered) == len(exited) == len(completed) == FRAME_COUNT, (len(entered), len(exited), len(completed))
assert [frame[0] for frame in entered] == [frame[0] for frame in exited] == [frame[0] for frame in completed]
assert len({frame[0] for frame in completed}) == FRAME_COUNT, 'Duplicate PTS'
steady = completed[WARMUP_FRAMES:]
latencies = [(end[1] - start[1]) / NANOSECONDS_PER_MILLISECOND for start, end in zip(entered[WARMUP_FRAMES:], exited[WARMUP_FRAMES:])]
summary = {'model': model, 'pipeline': launch, 'plugin_file': plugin_file, 'frames': FRAME_COUNT, 'source_frames_seen': source_frames_seen, 'controlled_subset_frames_discarded': source_frames_seen - FRAME_COUNT, 'warmup_frames': WARMUP_FRAMES, 'ordered_pts_match': True, 'pts': [frame[0] for frame in completed], 'caps': caps, 'wall_seconds': time.monotonic() - started, 'fps': (len(steady) - 1) * NANOSECONDS_PER_SECOND / (steady[-1][1] - steady[0][1]), 'opchain_p50_ms': statistics.median(latencies), 'opchain_p95_ms': sorted(latencies)[int(len(latencies) * P95_FRACTION)], 'cpu_ms_per_frame': (steady[-1][2] - steady[0][2]) / NANOSECONDS_PER_MILLISECOND / (len(steady) - 1)}
prefix.with_suffix('.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
