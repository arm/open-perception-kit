# Chronological ONNX thread benchmark on lecso

This comparison isolates the IntraOp and InterOp merges on the baseline immediately before IntraOp. The source stages are built sequentially through the repository release wrapper, using the same cross compiler, sysroot and ONNX Runtime 1.31.1. Exact commits, library hashes, source patches, build logs and conflict resolutions are saved alongside the results.

The board is lecso, Raspberry Pi 5 with four Cortex-A76 cores and 8 GB RAM. All processing runs on the CPU in the same unprivileged Linux container; no GPU devices are mounted. CPU frequency uses the performance governor during the batch, with temperature, clock, throttling, swap counters and other-container CPU activity sampled. The original governor is restored even when a trial fails.

Models are the repository's optimized INT8 YOLO26n and YOLO26s at 320, 480 and 640. Every stage loads the same model file, verified against the publisher SHA-256 in its descriptor. The source is GettyImages-1140581459.mov, used by the full ONNX examples. Every pass processes all 417 frames; the first 30 are excluded from steady-state statistics.

The common pipeline is the corresponding YOLO preset from the InterOp merge: decode, BGRA conversion, CPU preprocessing, ONNX inference, detection parsing, tracking, performance metadata, result serialization and 960×540 scaling. Playback rate limiting is removed and the final sink is unpaced. Results are written to a file instead of a WebSocket. These are pipeline-processing FPS, excluding encoding, browser display and network transport.

The three source stages retain their own committed model settings. Baseline uses the legacy three-thread intra-op policy and sequential execution. IntraOp introduces explicit per-model counts. InterOp introduces parallel graph execution and retunes presets. Runs alternate stage and model order across three repetitions. A separate control runs the final InterOp source with YOLO26s/320 at two intra-op threads, compared with its normal three-thread preset; inter-op remains one in both. This separates the 2→3 configuration effect from the source-stage comparison.

Each trial requires 417 unique ordered timestamps, 417 inference scopes, 417 result packets and matching decoded detection payloads. Timing, runtime identities and tracker state are excluded from the numerical comparison. Floating values use absolute tolerance 0.0001 and relative tolerance 0.00001; structural and non-floating fields must match exactly. The complete CPU-only trial matrix and control are kept in the raw archive.

EXPKITS-1360's attachment measured csalamade (Pi 5 with 16 GB), ONNX Runtime 1.31.1, the first 120 video frames and three repeats. This run uses lecso with 8 GB and all 417 frames. It holds the runtime fixed to separate source changes; it does not recreate IntraOp's original ONNX Runtime 1.24.4 environment. Differences from the ticket must be interpreted with those conditions in mind.

IntraOp divides one operator across threads. InterOp schedules independent operators from the same inference graph concurrently when OPK selects parallel execution. Data dependencies still serialize dependent operators. Neither setting is a video-frame concurrency control. More threads can increase synchronization and compete with decode, preprocessing and postprocessing.
