# Chronological source isolation

Baseline: 1a51b4f327436077f3daa32636ab000591732bf8.
IntraOp: cherry-pick 13243a122ce7ec87337cc5c1f60e63bb75a408c4, producing 0d316dee037704171c5ccdc66a4321f737d3dc46. Trees are identical to the original merge.
InterOp: cherry-pick c50ef33f3316f82d3b2c670bf5c0f3b8ec8888c3, producing 1687cba0b91502749e29b75478e50947ee8237b7.

InterOp required conflict resolution because the historical base predates audio and Vulkan preprocessing. Kept the merge's reader version 1.6.0 and thread attributes. Kept absent silero-vad/smart-turn configurations absent; their models are outside this benchmark. Removed incoming conflict context for absent audio and MLWL tests; retained the InterOp thread tests and supported-version assertion. Kept only the newly added InterOp paragraph from the conflicting documentation section, excluding intervening Vulkan-preprocessing documentation. All ONNX runtime implementation hunks applied without conflict. See inter-cherry-pick-range-diff.txt for the exact differences.

Every stage uses ONNX Runtime 1.31.1, the same release build wrapper, compiler/sysroot and video harness. No intervening source commits were imported. This isolates these merges on a fixed runtime; it does not reconstruct the original IntraOp release's ONNX Runtime 1.24.4 environment.

The InterOp snapshot was subsequently signed as ed66d5b6e0bd18d73ad4c167287f6deb78648ce2. Its source tree is identical (9dfb0375f29c88b556e43e5093585ba7e075fa6e). The raw build and trial manifests retain the pre-signing commit, 1687cba0b91502749e29b75478e50947ee8237b7. Both published snapshot commits have verified SSH signatures and DCO trailers.
