#!/bin/sh
BUILD_JOBS=6
exec /usr/bin/ninja -j "$BUILD_JOBS" "$@"
