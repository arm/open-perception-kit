"""Compare the three isolated source revisions on complete real-video input."""
import base64
import json
import os
from pathlib import Path
import statistics
import subprocess
import time
import sweep

ROOT = Path('/bench')
STAGES = ('baseline', 'intra', 'inter')
MODELS = tuple(f'yolo26{variant}-{size}' for variant in ('n', 's') for size in (320, 480, 640))
REPETITIONS = 3
FRAME_COUNT = 417
WARMUP_FRAMES = 30
COOLDOWN_SECONDS = 8
TRIAL_TIMEOUT_SECONDS = 600
VIDEO = Path('/source/data/videos/GettyImages-1140581459.mov')


def run(model, stage, repetition, intra_override=None):
    stage_root = ROOT / 'stages' / stage
    model_root = stage_root / 'config/models' / model
    output = ROOT / 'results' / model
    output.mkdir(parents=True, exist_ok=True)
    case = stage if intra_override is None else f'{stage}-intra{intra_override}'
    prefix = output / f'{case}-r{repetition}'
    result_path = prefix.with_suffix('.result.json')
    descriptor = json.loads((model_root / 'model.json').read_text())
    chain = json.loads((model_root / 'opchain.json').read_text())
    settings = []
    for op in chain['ops']:
        if op['id'] == 'opk-onnx-ops/Inference':
            attrs = op['attributes']
            attrs['modelDescriptor'] = str(model_root / 'model.json')
            if intra_override is not None:
                attrs['intraOpNumThreads'] = intra_override
            settings.append([attrs.get('intraOpNumThreads', 3), attrs.get('interOpNumThreads', 1)])
    assert len(settings) == 1, settings
    if result_path.exists():
        result = json.loads(result_path.read_text())
        assert result['source'] == json.loads((stage_root / 'provenance.json').read_text())
        assert result['threads'] == settings[0] and result['semantic_output_matches']
        assert result['frames'] == result['all_inference_calls'] == FRAME_COUNT
        print(f'REUSE {model} {case} r{repetition}', flush=True)
        return result
    chain_path = output / f'opchain-{case}.json'
    chain_path.write_text(json.dumps(chain, indent=2) + '\n')
    lib = stage_root / 'lib'
    environment = dict(os.environ, OPK_PROJECT_ROOT=str(stage_root), OPK_PLUGIN_PATH=str(lib),
                       GST_PLUGIN_PATH=str(lib), GST_REGISTRY=str(ROOT / f'registry-{stage}.bin'),
                       LD_LIBRARY_PATH=str(lib) + ':/bench/ort', GST_DEBUG='1')
    time.sleep(COOLDOWN_SECONDS)
    print(f'START {model} {stage} r{repetition} {settings[0]}', flush=True)
    with prefix.with_suffix('.log').open('w') as log:
        subprocess.run(['/usr/bin/python3', '/bench/scripts/video-stage.py', stage, model,
                        str(chain_path), str(prefix)], env=environment, stdout=log,
                       stderr=subprocess.STDOUT, timeout=TRIAL_TIMEOUT_SECONDS, check=True)
    result = json.loads(prefix.with_suffix('.json').read_text())
    assert result['frames'] == result['source_frames_seen'] == FRAME_COUNT and result['ordered_pts_match']
    result.update(sweep.inference_stats(prefix.with_suffix('.csv'), descriptor['name'], WARMUP_FRAMES))
    assert result['all_inference_calls'] == FRAME_COUNT
    assert result['inference_calls'] == FRAME_COUNT - WARMUP_FRAMES
    packets = [json.loads(line) for line in prefix.with_suffix('.ndjson').read_text().splitlines()]
    assert len(packets) == FRAME_COUNT
    assert [packet['frame_counter'] for packet in packets] == list(range(FRAME_COUNT))
    semantic = [sweep.semantic_packet(base64.b64decode(packet['frame_results_packet_b64'])) for packet in packets]
    reference_path = output / 'baseline-r1.semantic.json'
    reference = json.loads(reference_path.read_text()) if reference_path.exists() else semantic
    result.update(sweep.semantic_status(semantic, reference, True, video=True))
    result.update(stage=stage, case=case, repeat=repetition, threads=settings[0],
                  source=json.loads((stage_root / 'provenance.json').read_text()))
    result_path.write_text(json.dumps(result, indent=2) + '\n')
    prefix.with_suffix('.semantic.json').write_text(json.dumps(semantic))
    print(json.dumps({key: result[key] for key in ('model','stage','repeat','threads','fps','inference_mean_ms','semantic_output_matches')}), flush=True)
    assert result['semantic_output_matches'], result.get('semantic_comparison_error')
    return result


def main():
    manifest = {'video_sha256': sweep.sha256(VIDEO), 'models': {}, 'stages': STAGES,
                'repetitions': REPETITIONS, 'frame_count': FRAME_COUNT, 'warmup_frames': WARMUP_FRAMES}
    for model in MODELS:
        hashes = []
        for stage in STAGES:
            root = ROOT / 'stages' / stage / 'config/models' / model
            descriptor = json.loads((root / 'model.json').read_text())
            digest = sweep.sha256(root / descriptor['modelFile'])
            assert digest == descriptor['hfDownload']['sha256'], (stage,model,digest)
            hashes.append(digest)
        assert len(set(hashes)) == 1, model
        manifest['models'][model] = hashes[0]
    manifest_path = ROOT / 'manifest.json'
    manifest = json.loads(json.dumps(manifest))
    if manifest_path.exists():
        assert json.loads(manifest_path.read_text()) == manifest, 'Input manifest changed'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    rows = []
    for repetition in range(1, REPETITIONS + 1):
        models = MODELS if repetition % 2 else tuple(reversed(MODELS))
        stages = STAGES if repetition % 2 else tuple(reversed(STAGES))
        for model in models:
            for stage in stages:
                rows.append(run(model, stage, repetition))
    control_rows = [run('yolo26s-320', 'inter', repetition, intra_override=2)
                    for repetition in range(1, REPETITIONS + 1)]
    (ROOT / 's320-control.json').write_text(json.dumps(control_rows, indent=2) + '\n')
    summary = {}
    for model in MODELS:
        summary[model] = {}
        for stage in STAGES:
            trials = [row for row in rows if row['model'] == model and row['stage'] == stage]
            assert len(trials) == REPETITIONS
            summary[model][stage] = {'threads': trials[0]['threads'],
                'fps_median': statistics.median(row['fps'] for row in trials),
                'fps_min': min(row['fps'] for row in trials), 'fps_max': max(row['fps'] for row in trials),
                'inference_mean_ms': statistics.median(row['inference_mean_ms'] for row in trials),
                'inference_p95_ms': statistics.median(row['inference_p95_ms'] for row in trials),
                'cpu_ms_per_frame': statistics.median(row['cpu_ms_per_frame'] for row in trials)}
    (ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print('SUMMARY ' + json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
