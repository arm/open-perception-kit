"""External EXPKITS-925 harness; caller must hold /bench/host.lock."""
import argparse
import base64
import csv
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys

ROOT = Path('/work')
BENCH = Path('/bench')
IMAGE = ROOT / 'data/images/GettyImages-1140581459-thumbnail.jpg'
VIDEO = ROOT / 'data/videos/GettyImages-1140581459.mov'
BUILD = BENCH / 'lib'
REPEATS = 3
NANOSECONDS_PER_MILLISECOND = 1_000_000
MILLISECONDS_PER_SECOND = 1_000
TRIAL_TIMEOUT_SECONDS = 300
RELATIVE_CORRECTNESS_TOLERANCE = 1e-5
# ORT thread reduction order produced score drift below5e-5 in the480video probe.
ABSOLUTE_CORRECTNESS_TOLERANCE = 1e-4
NEAR_BEST_FACTOR = 1.05
VIDEO_FRAME_COUNT = 120
SECONDARY_MODELS = {'nitec-resnet-18', 'mobilegaze-mobilenet-v2'}
sys.path.insert(0, str(ROOT / 'generated/open_perception_kit/python/src'))
from open_perception_kit.packet import decode
from open_perception_kit import ProducerIdentityStatus
from open_perception_kit.registry import _TYPE_REGISTRY


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    if isinstance(value, bytes):
        return value.decode()
    if isinstance(value, (list, tuple)):
        return [canonical(item) for item in value]
    if hasattr(value, 'tolist'):
        return canonical(value.tolist())
    if hasattr(value, '__dict__'):
        return {key: canonical(item) for key, item in vars(value).items()
                if key not in {'object', 'producer', 'inferElementId'}}
    return value


def semantic_packet(packet):
    envelope = decode(packet)
    assert envelope.valid(), envelope.error()
    assert envelope.producer_identity() == ProducerIdentityStatus.EXACT_MATCH
    payloads = []
    for entry in _TYPE_REGISTRY.values():
        if entry['root_type'] in {'FrameContext', 'PerformanceOverlay', 'ObjectTracks', 'TrackTraces'}:
            continue
        native = getattr(importlib.import_module(entry['module']), entry['native_type'])
        payloads.extend({'type': entry['root_type'], 'value': canonical(value)}
                        for value in envelope.for_each(native))
    assert payloads, 'No recognized model payloads'
    return payloads


def compare(actual, expected, path="$"):
    if isinstance(expected, float):
        assert math.isfinite(actual) and math.isclose(actual, expected, rel_tol=RELATIVE_CORRECTNESS_TOLERANCE, abs_tol=ABSOLUTE_CORRECTNESS_TOLERANCE), (path, actual, expected)
    elif isinstance(expected, dict):
        assert actual.keys() == expected.keys(), (path, "keys", list(actual), list(expected))
        for key in expected:
            compare(actual[key], expected[key], f"{path}.{key}")
    elif isinstance(expected, list):
        assert len(actual) == len(expected), (path, "length", len(actual), len(expected))
        for index, (a, b) in enumerate(zip(actual, expected)):
            compare(a, b, f"{path}[{index}]")
    else:
        assert actual == expected, (path, actual, expected)


def semantic_status(actual, expected, record_differences, video=False):
    try:
        compare(actual, expected)
        return {'semantic_output_matches': True}
    except AssertionError as error:
        if not record_differences:
            raise
        status = {'semantic_output_matches': False, 'semantic_comparison_error': str(error),
                  'semantic_differences_recorded_explicitly': True}
        if video:
            failures = []
            for index, (actual_frame, expected_frame) in enumerate(zip(actual, expected)):
                try:
                    compare(actual_frame, expected_frame, f'$[{index}]')
                except AssertionError as frame_error:
                    failures.append({'frame_index': index, 'first_mismatch': str(frame_error)})
            status['semantic_mismatching_frames'] = failures
        return status


def chain_for(model, count, destination):
    source = ROOT / 'config/models' / model
    result = json.loads((source / 'opchain.json').read_text())
    result['version'] = '1.1.0'
    for op in result['ops']:
        attributes = op.get('attributes', {})
        if op['id'] == 'opk-onnx-ops/Inference':
            attributes['modelDescriptor'] = str(source / 'model.json')
            attributes.pop('intraOpNumThreads', None)
            if count != 'omitted':
                attributes['intraOpNumThreads'] = int(count)
    if model in SECONDARY_MODELS:
        detector = json.loads((ROOT / 'config/models/ultraface-rfb-320/opchain.json').read_text())
        for op in detector['ops']:
            if op['id'] == 'opk-onnx-ops/Inference':
                op['attributes']['modelDescriptor'] = str(ROOT / 'config/models/ultraface-rfb-320/model.json')
                op['attributes']['intraOpNumThreads'] = 1
        result['ops'] = detector['ops'] + result['ops']
    destination.write_text(json.dumps(result, indent=2) + '\n')


def inference_stats(csv_path, model_name, warmup_frames=0):
    rows = list(csv.DictReader(csv_path.open()))
    all_target_count = sum(row["name"] == "onnx/Infer/" + model_name for row in rows)
    if warmup_frames:
        frames = [row for row in rows if row["name"].startswith("opchain/") and int(row["depth"]) == 0]
        cutoff = int(frames[warmup_frames]["start_ns"])
        rows = [row for row in rows if int(row["start_ns"]) >= cutoff]
    scopes = {}
    for row in rows:
        if row['name'].startswith('onnx/Infer/'):
            scopes.setdefault(row['name'], []).append(int(row['duration_ns']) / NANOSECONDS_PER_MILLISECOND)
    target = scopes['onnx/Infer/' + model_name]
    ordered = sorted(target)
    tail_fraction = .95
    return {'inference_calls': len(target), 'all_inference_calls': all_target_count, 'inference_p50_ms': statistics.median(target),
            'inference_p95_ms': ordered[math.ceil(len(ordered) * tail_fraction) - 1],
            'inference_mean_ms': statistics.mean(target),
            'invocations_by_scope': {key: len(values) for key, values in scopes.items()}}


def runtime_env(output):
    return {**os.environ, 'OPK_PROJECT_ROOT': str(ROOT), 'OPK_PLUGIN_PATH': str(BUILD),
            'GST_PLUGIN_PATH': str(BUILD), 'GST_REGISTRY': str(output.parent / 'registry.bin'),
            'LD_LIBRARY_PATH': str(BUILD) + ':/opt/opk-deps/onnxruntime/lib', 'GST_DEBUG': '1'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('host')
    parser.add_argument('model')
    parser.add_argument('--counts', default='omitted,0,1,2,3,4,5,6,7,8')
    parser.add_argument('--skip-video', action='store_true')
    parser.add_argument('--video-only', action='store_true')
    parser.add_argument('--video-counts', help='Comma-separated counts for targeted video confirmation')
    parser.add_argument('--record-semantic-differences', action='store_true', help='Explicit diagnostic mode: record false semantic comparison results and continue; never changes tolerance')
    args = parser.parse_args()
    output = BENCH / args.host / args.model
    output.mkdir(parents=True, exist_ok=True)
    descriptor_path = ROOT / 'config/models' / args.model / 'model.json'
    descriptor = json.loads(descriptor_path.read_text())
    source_manifest_path = BENCH / 'source-manifest.json'
    if source_manifest_path.exists():
        source_manifest = json.loads(source_manifest_path.read_text())
        source_revision = source_manifest['revision']
        patch_sha256 = source_manifest['tracked_diff_sha256']
    else:
        source_revision = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
        patch_sha256 = hashlib.sha256(subprocess.check_output(['git', '-C', str(ROOT), 'diff', 'HEAD'])).hexdigest()
    manifest = {'model': args.model, 'model_name': descriptor['name'], 'model_sha256': sha256(descriptor_path.parent / descriptor['modelFile']), 'image_sha256': sha256(IMAGE), 'video_sha256': sha256(VIDEO), 'counts': args.counts.split(','), 'repeats': REPEATS, 'mode': 'public OpChain repeated GettyImages thumbnail; 30 warmup, >=20 measured calls and >=2sec; CPU-only C++ ORT used by OPK', 'source_revision': source_revision, 'tracked_diff_sha256': patch_sha256, 'secondary_detector_threads': 1 if args.model in SECONDARY_MODELS else None}
    if args.video_only:
        manifest = json.loads((output / 'manifest.json').read_text())
    else:
        (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    results = json.loads((output / 'results.json').read_text()) if args.video_only else []
    baseline = None
    counts = manifest['counts']
    for repeat in ([] if args.video_only else range(1, REPEATS + 1)):
        ordered_counts = counts if repeat % 2 else list(reversed(counts))
        for count in ordered_counts:
            prefix = output / f'threads-{count}-r{repeat}'
            chain = output / f'opchain-threads-{count}.json'
            chain_for(args.model, count, chain)
            with prefix.with_suffix('.log').open('w') as log:
                subprocess.run([str(BENCH / 'opchain-bench'), str(chain), str(IMAGE), str(prefix)], env=runtime_env(output), stdout=log, stderr=subprocess.STDOUT, check=True, timeout=TRIAL_TIMEOUT_SECONDS)
            current = semantic_packet(prefix.with_suffix('.packet').read_bytes())
            prefix.with_suffix('.semantic.json').write_text(json.dumps(current, indent=2) + '\n')
            if baseline is None:
                baseline = current
            semantic_check = semantic_status(current, baseline, args.record_semantic_differences)
            runtime = json.loads(prefix.with_suffix('.runtime.json').read_text())
            result = {'threads': count, 'repeat': repeat, **runtime, **inference_stats(prefix.with_suffix('.csv'), descriptor['name']), **semantic_check, 'semantic_tolerance': {'absolute': ABSOLUTE_CORRECTNESS_TOLERANCE, 'relative': RELATIVE_CORRECTNESS_TOLERANCE}}
            assert result['inference_calls'] >= runtime['calls'], result
            result['opchain_fps'] = runtime['calls'] / runtime['wall_seconds']
            result['cpu_ms_per_opchain'] = runtime['cpu_seconds'] * MILLISECONDS_PER_SECOND / runtime['calls']
            results.append(result)
            print(json.dumps(result), flush=True)
            (output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    ranked = []
    for count in counts:
        trials = [item for item in results if item['threads'] == count]
        ranked.append({'threads': count, 'median_inference_p50_ms': statistics.median(item['inference_p50_ms'] for item in trials), 'median_inference_p95_ms': statistics.median(item['inference_p95_ms'] for item in trials), 'median_opchain_fps': statistics.median(item['opchain_fps'] for item in trials), 'min_inference_p50_ms': min(item['inference_p50_ms'] for item in trials), 'max_inference_p50_ms': max(item['inference_p50_ms'] for item in trials), 'median_cpu_ms_per_opchain': statistics.median(item['cpu_ms_per_opchain'] for item in trials)})
    ranked.sort(key=lambda item: item['median_inference_p50_ms'])
    (output / 'ranking.json').write_text(json.dumps(ranked, indent=2) + '\n')
    print('RANKING ' + json.dumps(ranked), flush=True)
    explicit_ranked = [item for item in ranked if item['threads'] != 'omitted']
    best = explicit_ranked[0]
    near_best = [item for item in explicit_ranked if item['median_inference_p50_ms'] <= best['median_inference_p50_ms'] * NEAR_BEST_FACTOR and item['median_inference_p95_ms'] <= best['median_inference_p95_ms'] * NEAR_BEST_FACTOR]
    practical = min(near_best, key=lambda item: (item['median_cpu_ms_per_opchain'], int(item['threads']) if item['threads'] != '0' else len(os.sched_getaffinity(0))))
    (output / 'recommendation.json').write_text(json.dumps({'fastest_inference': best, 'practical_inference': practical, 'near_best_candidates': near_best, 'rule': 'p50 and p95 within 5% of fastest p50 candidate; then lowest CPU time, then fewer explicit threads; validate against real video'}, indent=2) + '\n')
    if not args.skip_video:
        saved_baseline = output / 'video-threads-omitted-r1.semantic.json'
        video_baseline = json.loads(saved_baseline.read_text()) if saved_baseline.exists() else None
        explicit = [practical['threads']] + [item['threads'] for item in explicit_ranked if item['threads'] != practical['threads']]
        finalist_count = 2
        for repeat in range(1, REPEATS + 1):
            finalists = args.video_counts.split(',') if args.video_counts else explicit[:finalist_count] + ['omitted']
            if not repeat % 2:
                finalists.reverse()
            for count in finalists:
                prefix = output / f'video-threads-{count}-r{repeat}'
                completed_capture = prefix.with_suffix('.json').exists()
                if not completed_capture:
                    with prefix.with_suffix('.log').open('w') as log:
                        subprocess.run(['/usr/bin/python3', '/bench/scripts/video-confirm.py', args.model, str(output / f'opchain-threads-{count}.json'), str(prefix)], env=runtime_env(output), stdout=log, stderr=subprocess.STDOUT, check=True, timeout=TRIAL_TIMEOUT_SECONDS)
                result = json.loads(prefix.with_suffix('.json').read_text())
                assert result['frames'] == VIDEO_FRAME_COUNT and result['ordered_pts_match']
                result['revalidated_existing_capture'] = completed_capture
                result.update(threads=count, repeat=repeat)
                result.update(inference_stats(prefix.with_suffix('.csv'), descriptor['name'], result['warmup_frames']))
                packets = [json.loads(line) for line in prefix.with_suffix('.ndjson').read_text().splitlines()]
                assert len(packets) == result['frames'], len(packets)
                semantic = [semantic_packet(base64.b64decode(packet['frame_results_packet_b64'])) for packet in packets]
                if video_baseline is None:
                    video_baseline = semantic
                result.update(semantic_status(semantic, video_baseline, args.record_semantic_differences, video=True))
                result['semantic_tolerance'] = {'absolute': ABSOLUTE_CORRECTNESS_TOLERANCE, 'relative': RELATIVE_CORRECTNESS_TOLERANCE}
                prefix.with_suffix('.semantic.json').write_text(json.dumps(semantic, indent=2) + '\n')
                prefix.with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n')
                print('VIDEO ' + json.dumps(result), flush=True)

if __name__ == '__main__':
    main()
