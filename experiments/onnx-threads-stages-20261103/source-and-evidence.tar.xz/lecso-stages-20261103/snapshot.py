"""Preserve a built source stage before applying the next requested merge."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'EXPKITS-1360-staged-lecso-20261103'
stage = sys.argv[1]
output = ROOT / 'stages' / stage
assert not output.exists(), output
output.mkdir(parents=True)
shutil.copytree(SOURCE / 'config', output / 'config')
shutil.copytree(SOURCE / 'generated', output / 'generated')
lib = output / 'lib'
lib.mkdir()
for path in (SOURCE / 'development/build-native/meson-out').glob('*.so'):
    shutil.copy2(path, lib / path.name)
shutil.copy2(ROOT / 'libperfbridge.so', lib / 'libperfbridge.so')
def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()
provenance = {'stage': stage, 'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
              'tracked_diff': git('diff', 'HEAD', '--stat'), 'ort_version': '1.31.1',
              'libraries': {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in lib.iterdir()}}
assert not provenance['tracked_diff'], provenance
(output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
print(json.dumps(provenance))
