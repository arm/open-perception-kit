# SPDX-FileCopyrightText: Copyright 2026 Arm Limited and/or its affiliates
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Generated file. Do not edit.
# SDK users: change schemas or generator inputs, then regenerate this file.
_TYPE_REGISTRY = {
    556103652012567315: {
        'name': 'open_perception_kit::metadata::BoxDetections',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.BoxDetections',
        'root_type': 'BoxDetections',
        'native_type': 'BoxDetectionsT',
        'qualified_root_type': 'open_perception_kit.metadata.BoxDetections',
        'file_identifier': 'BDET',
    },
    2852697023809600655: {
        'name': 'open_perception_kit::metadata::Classifications',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.Classifications',
        'root_type': 'Classifications',
        'native_type': 'ClassificationsT',
        'qualified_root_type': 'open_perception_kit.metadata.Classifications',
        'file_identifier': 'CLSF',
    },
    2065478860695108412: {
        'name': 'open_perception_kit::metadata::FrameContext',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.FrameContext',
        'root_type': 'FrameContext',
        'native_type': 'FrameContextT',
        'qualified_root_type': 'open_perception_kit.metadata.FrameContext',
        'file_identifier': 'FCTX',
    },
    3149752457626985059: {
        'name': 'open_perception_kit::metadata::InstanceSegmentationMasks',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.InstanceSegmentationMasks',
        'root_type': 'InstanceSegmentationMasks',
        'native_type': 'InstanceSegmentationMasksT',
        'qualified_root_type': 'open_perception_kit.metadata.InstanceSegmentationMasks',
        'file_identifier': 'ISGM',
    },
    5972661533224817501: {
        'name': 'open_perception_kit::metadata::ObjectEmbeddings',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.ObjectEmbeddings',
        'root_type': 'ObjectEmbeddings',
        'native_type': 'ObjectEmbeddingsT',
        'qualified_root_type': 'open_perception_kit.metadata.ObjectEmbeddings',
        'file_identifier': 'EMBE',
    },
    2960585987463094496: {
        'name': 'open_perception_kit::metadata::ObjectTracks',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.ObjectTracks',
        'root_type': 'ObjectTracks',
        'native_type': 'ObjectTracksT',
        'qualified_root_type': 'open_perception_kit.metadata.ObjectTracks',
        'file_identifier': 'TRKS',
    },
    7749401259036278028: {
        'name': 'open_perception_kit::metadata::PerformanceOverlay',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.PerformanceOverlay',
        'root_type': 'PerformanceOverlay',
        'native_type': 'PerformanceOverlayT',
        'qualified_root_type': 'open_perception_kit.metadata.PerformanceOverlay',
        'file_identifier': 'PERF',
    },
    9114952555105892553: {
        'name': 'open_perception_kit::metadata::PoseEstimations',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.PoseEstimations',
        'root_type': 'PoseEstimations',
        'native_type': 'PoseEstimationsT',
        'qualified_root_type': 'open_perception_kit.metadata.PoseEstimations',
        'file_identifier': 'POSE',
    },
    1998909987238011535: {
        'name': 'open_perception_kit::metadata::SegmentationMasks',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.SegmentationMasks',
        'root_type': 'SegmentationMasks',
        'native_type': 'SegmentationMasksT',
        'qualified_root_type': 'open_perception_kit.metadata.SegmentationMasks',
        'file_identifier': 'SGMS',
    },
    1602571589628393389: {
        'name': 'open_perception_kit::metadata::SemanticSegmentationMasks',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.SemanticSegmentationMasks',
        'root_type': 'SemanticSegmentationMasks',
        'native_type': 'SemanticSegmentationMasksT',
        'qualified_root_type': 'open_perception_kit.metadata.SemanticSegmentationMasks',
        'file_identifier': 'SSGM',
    },
    238211229389337861: {
        'name': 'open_perception_kit::metadata::TrackTraces',
        'module': 'open_perception_kit.fb.open_perception_kit.metadata.TrackTraces',
        'root_type': 'TrackTraces',
        'native_type': 'TrackTracesT',
        'qualified_root_type': 'open_perception_kit.metadata.TrackTraces',
        'file_identifier': 'TRCE',
    },
}
