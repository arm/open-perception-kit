"""Check saved chronological trials and summarize the recorded board conditions."""
import json
import math
from pathlib import Path
import re
import statistics

ROOT = Path(__file__).resolve().parent
MODEL_COUNT = 6
STAGES = ('baseline', 'intra', 'inter')
REPETITIONS = 3
FRAME_COUNT = 417
WARMUP_FRAMES = 30


def main():
    paths = [path for path in (ROOT / 'results').glob('*/*.result.json')
             if not path.name.endswith('-r0.result.json')]
    assert len(paths) == MODEL_COUNT * len(STAGES) * REPETITIONS + REPETITIONS
    rows = []
    for path in paths:
        row = json.loads(path.read_text())
        assert row['frames'] == row['source_frames_seen'] == row['all_inference_calls'] == FRAME_COUNT
        assert row['inference_calls'] == FRAME_COUNT - WARMUP_FRAMES
        assert row['semantic_output_matches'] and row['ordered_pts_match']
        assert len(row['pts']) == len(set(row['pts'])) == FRAME_COUNT
        assert row['pts'] == sorted(row['pts'])
        assert all(math.isfinite(row[key]) and row[key] > 0 for key in ('fps', 'inference_mean_ms', 'cpu_ms_per_frame'))
        prefix = path.with_name(path.name.removesuffix('.result.json'))
        packets = [json.loads(line) for line in prefix.with_suffix('.ndjson').read_text().splitlines()]
        assert [packet['frame_counter'] for packet in packets] == list(range(FRAME_COUNT))
        maps = prefix.with_suffix('.maps').read_text()
        assert '/bench/ort/libonnxruntime.so.1.31.1' in maps and 'libonnxruntime.so.1.24' not in maps
        assert 'libonnxruntime_providers_webgpu' not in maps
        assert '/bench/stages/' + row['stage'] + '/lib/opk-onnx-ops.so' in maps
        assert row['source'] == json.loads((ROOT / 'stages' / row['stage'] / 'provenance.json').read_text())
        rows.append(row)
    summary = json.loads((ROOT / 'summary.json').read_text())
    for model, values in summary.items():
        for stage in STAGES:
            trials = [row for row in rows if row['model'] == model and row['case'] == stage]
            assert len(trials) == REPETITIONS
            assert values[stage]['fps_median'] == statistics.median(row['fps'] for row in trials)
    hardware = json.loads((ROOT / 'evidence/chronological-matrix-hardware.json').read_text())
    assert hardware['exit_code'] == 0 and not hardware['monitor_errors']
    assert hardware['original_governors'] == hardware['restored_governors']
    assert all(row['throttled'] == 'throttled=0x0' for row in hardware['samples'])
    assert max(hardware['other_container_cpu_cores']) <= hardware['maximum_allowed_other_container_cpu_cores']
    temperatures = [float(re.search(r'temp=([0-9.]+)', row['temperature']).group(1)) for row in hardware['samples']]
    frequencies = [int(row['frequency'].split('=')[1]) for row in hardware['samples']]
    report = {
        'validated_trials': len(rows), 'total_video_frames': len(rows) * FRAME_COUNT,
        'all_detection_comparisons_passed': True, 'all_packet_counts_and_timestamps_passed': True,
        'all_source_and_runtime_maps_passed': True, 'summary_matches_trials': True,
        'hardware_samples': len(hardware['samples']),
        'temperature_celsius_min': min(temperatures), 'temperature_celsius_max': max(temperatures),
        'arm_clock_hz_min': min(frequencies), 'arm_clock_hz_max': max(frequencies),
        'maximum_other_container_cpu_cores': max(hardware['other_container_cpu_cores']),
        'swap_counter_delta': {key: hardware['samples'][-1]['swap_counters'][key] - hardware['samples'][0]['swap_counters'][key]
                               for key in hardware['samples'][0]['swap_counters']},
        'throttled_samples': 0, 'monitor_errors': [],
        'original_governors': hardware['original_governors'],
        'restored_governors': hardware['restored_governors'],
    }
    (ROOT / 'validation-summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
