"""Archive benchmark source and complete evidence without downloaded assets or plans."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

CACHE = Path('/home/sanmeg01/.cache/opk-benchmarks/opi6-four-stage-20261102')
REPOSITORY = Path('/home/sanmeg01/git/opk-dev-1')
GPU = CACHE / 'webgpu-yolo26-20261103/fix-20261103'
THREADS = CACHE / 'lecso-stages-20261103'
EXCLUDED_SUFFIXES = {'.so', '.onnx', '.raw', '.bin', '.pyc', '.o', '.d', '.mov'}
COMPRESSION_PRESET = 6
MODEL_COUNT = 6
STAGED_TRIALS = 54
CONTROL_TRIALS = 3
FRAME_COUNT = 417


def source_files(root, prefix, include=lambda path: True):
    return [(path, str(Path(prefix) / path.relative_to(root))) for path in sorted(root.rglob('*'))
            if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts
            and path.suffix not in EXCLUDED_SUFFIXES and path.name.upper() != 'PLAN.MD'
            and include(path.relative_to(root))]


def archive(path, files):
    names = [name for _, name in files]
    assert len(names) == len(set(names)), 'Duplicate archive members'
    manifest = {name: hashlib.sha256(source.read_bytes()).hexdigest() for source, name in files}
    metadata = json.dumps(manifest, indent=2).encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(path, 'w:xz', preset=COMPRESSION_PRESET) as output:
        for source, name in files:
            output.add(source, arcname=name, recursive=False)
        member = tarfile.TarInfo('manifest.json')
        member.size = len(metadata)
        output.addfile(member, io.BytesIO(metadata))
    with tarfile.open(path, 'r:xz') as saved:
        for name, digest in manifest.items():
            assert hashlib.sha256(saved.extractfile(name).read()).hexdigest() == digest, name
    print(path, path.stat().st_size, 'bytes;', len(files), 'verified files')


if __name__ == '__main__':
    assert len(json.loads((GPU / 'summary.json').read_text())) == MODEL_COUNT
    rows = [json.loads(path.read_text()) for path in (THREADS / 'results').glob('*/*.result.json')
            if not path.name.endswith('-r0.result.json')]
    assert len(rows) == STAGED_TRIALS + CONTROL_TRIALS and all(row['semantic_output_matches'] and row['frames'] == FRAME_COUNT for row in rows)
    gpu_files = source_files(GPU, 'fix-20261103')
    diagnostics = Path('/home/sanmeg01/.cache/opk-benchmarks/opi6-fix-20261103')
    gpu_files += source_files(diagnostics, 'diagnostics', lambda path: path.suffix in {'.log', '.cc', '.patch', '.py'})
    gpu_files.append((REPOSITORY / 'LICENSE', 'licenses/OPK-LICENSE'))
    archive(REPOSITORY / 'experiments/opi6-vulkan-20261103/optimized-source-and-evidence.tar.xz', gpu_files)
    def selected(path):
        return path.parts[0] != 'stages' or path.name == 'provenance.json' or 'config' in path.parts or ('python' in path.parts and 'src' in path.parts)
    thread_files = source_files(THREADS, 'lecso-stages-20261103', selected)
    thread_files.append((REPOSITORY / 'LICENSE', 'licenses/OPK-LICENSE'))
    archive(REPOSITORY / 'experiments/onnx-threads-stages-20261103/source-and-evidence.tar.xz', thread_files)
