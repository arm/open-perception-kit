
=== WebGPU Shader code [Transpose, Key="Transpose[2-3-1-0]:32,8,1:1:0;2:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 32;
const workgroup_size_y: u32 = 8;
const workgroup_size_z: u32 = 1;
const tile_size: u32 = 32;
const tile_rows: u32 = 8;
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<f32>;
struct Uniforms {
  a_shape: vec2<u32>,
  a_stride: u32,
  output_shape: vec2<u32>,
  output_stride: u32,
  output_size: u32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias a_indices_t = vec2<u32>;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride + indices[1];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->f32 {
  return a[i2o_a(indices_fnarg)];
}
alias output_value_t = f32;
alias output_indices_t = vec2<u32>;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride + indices[1];
}
fn set_output_by_indices(indices: output_indices_t, value: output_value_t) {
  output[i2o_output(indices)]=value;
}

var<workgroup> tile : array<array<output_value_t, tile_size + 1>, tile_size>;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let stride = (uniforms.output_shape[1] - 1) / tile_size + 1;
  let workgroup_id_x = workgroup_idx % stride;
  let workgroup_id_y = workgroup_idx / stride;
  let input_col = workgroup_id_y * tile_size + local_id.x;
  for (var j: u32 = 0u; j < tile_size; j += tile_rows) {
    let input_row = workgroup_id_x * tile_size + local_id.y + j;
    if (input_row < uniforms.a_shape[0] && input_col < uniforms.a_shape[1]) {
      tile[local_id.y + j][local_id.x] = get_a_by_indices(a_indices_t(input_row, input_col));
    }
  }
  workgroupBarrier();
  let output_col = workgroup_id_x * tile_size + local_id.x;
  for (var j: u32 = 0u; j < tile_size; j += tile_rows) {
    let output_row = workgroup_id_y * tile_size + local_id.y + j;
    if (output_row < uniforms.output_shape[0] && output_col < uniforms.output_shape[1]) {
      set_output_by_indices(output_indices_t(output_row, output_col), tile[local_id.x][local_id.y + j]);
    }
  }
}

=== WebGPU Shader code [Transpose, Key="Transpose[2-3-1-0]:32,8,1:1:0;2:"] End ===


=== WebGPU Shader code [Transpose, Key="Transpose[2-3-1-0]:64,1,1:1:0;4:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
const tile_size: u32 = 32;
const tile_rows: u32 = 8;
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<f32>;
struct Uniforms {
  a_shape: vec4<u32>,
  a_stride: vec3<u32>,
  output_shape: vec4<u32>,
  output_stride: vec3<u32>,
  output_size: u32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias a_indices_t = vec4<u32>;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride[0] + indices[1] * uniforms.a_stride[1] + indices[2] * uniforms.a_stride[2] + indices[3];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->f32 {
  return a[i2o_a(indices_fnarg)];
}
alias output_value_t = f32;
alias output_indices_t = vec4<u32>;
fn o2i_output(offset : u32)->output_indices_t {
  var indices: output_indices_t;
  var current = offset;
  indices[0] = current / uniforms.output_stride[0];
  current = current % uniforms.output_stride[0];
  indices[1] = current / uniforms.output_stride[1];
  current = current % uniforms.output_stride[1];
  indices[2] = current / uniforms.output_stride[2];
  current = current % uniforms.output_stride[2];
  indices[3] = current;
  return indices;
}

fn perm(i: output_indices_t)->a_indices_t {
  var a: a_indices_t;
  a[2] = i[0];
  a[3] = i[1];
  a[1] = i[2];
  a[0] = i[3];
  return a;
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
  let indices = o2i_output(global_idx);
  let x_indices = perm(indices);
  output[global_idx]=get_a_by_indices(x_indices);
}

=== WebGPU Shader code [Transpose, Key="Transpose[2-3-1-0]:64,1,1:1:0;4:"] End ===


=== WebGPU Shader code [Transpose, Key="Transpose[0-2-3-1]:32,8,1:1:0;2:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 32;
const workgroup_size_y: u32 = 8;
const workgroup_size_z: u32 = 1;
const tile_size: u32 = 32;
const tile_rows: u32 = 8;
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<f32>;
struct Uniforms {
  a_shape: vec2<u32>,
  a_stride: u32,
  output_shape: vec2<u32>,
  output_stride: u32,
  output_size: u32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias a_indices_t = vec2<u32>;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride + indices[1];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->f32 {
  return a[i2o_a(indices_fnarg)];
}
alias output_value_t = f32;
alias output_indices_t = vec2<u32>;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride + indices[1];
}
fn set_output_by_indices(indices: output_indices_t, value: output_value_t) {
  output[i2o_output(indices)]=value;
}

var<workgroup> tile : array<array<output_value_t, tile_size + 1>, tile_size>;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let stride = (uniforms.output_shape[1] - 1) / tile_size + 1;
  let workgroup_id_x = workgroup_idx % stride;
  let workgroup_id_y = workgroup_idx / stride;
  let input_col = workgroup_id_y * tile_size + local_id.x;
  for (var j: u32 = 0u; j < tile_size; j += tile_rows) {
    let input_row = workgroup_id_x * tile_size + local_id.y + j;
    if (input_row < uniforms.a_shape[0] && input_col < uniforms.a_shape[1]) {
      tile[local_id.y + j][local_id.x] = get_a_by_indices(a_indices_t(input_row, input_col));
    }
  }
  workgroupBarrier();
  let output_col = workgroup_id_x * tile_size + local_id.x;
  for (var j: u32 = 0u; j < tile_size; j += tile_rows) {
    let output_row = workgroup_id_y * tile_size + local_id.y + j;
    if (output_row < uniforms.output_shape[0] && output_col < uniforms.output_shape[1]) {
      set_output_by_indices(output_indices_t(output_row, output_col), tile[local_id.x][local_id.y + j]);
    }
  }
}

=== WebGPU Shader code [Transpose, Key="Transpose[0-2-3-1]:32,8,1:1:0;2:"] End ===


=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|8|3,1,1,0,0,32,32,24,4,]:8,8,1:1|1|1|4|2|2|1|1|1||:0;4|2;4|2;1:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 8;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<f32>;
@group(0) @binding(1) var<storage, read> w: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> result: array<vec4<f32>>;
struct Uniforms {
  x_shape: vec4<u32>,
  x_stride: vec3<u32>,
  w_shape: vec4<u32>,
  w_stride: vec3<u32>,
  result_shape: vec4<u32>,
  result_stride: vec3<u32>,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  pads: vec4<u32>,
  strides: vec2<u32>,
  dilations: vec2<u32>,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias x_value_t = f32;
alias x_indices_t = vec4<u32>;
alias x_element_t = f32;
alias w_value_t = vec4<f32>;
alias w_indices_t = vec4<u32>;
alias bias_value_t = vec4<f32>;
alias bias_indices_t = u32;
alias bias_element_t = f32;
alias result_indices_t = vec4<u32>;

fn getIndexFromCoords3D(coords : vec3<i32>, shape : vec3<i32>) -> i32 {
  return dot(coords, vec3<i32>(shape.y * shape.z, shape.z, 1));
}
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(i32(uniforms.result_stride.x), i32(uniforms.result_stride.y), i32(uniforms.result_stride.z), 1));
}
fn setOutputAtIndex(flatIndex : i32, value : vec4<x_element_t>) {
  result[u32(flatIndex)]=vec4<x_element_t>(value);
}
fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : vec4<x_element_t>){
  let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
  setOutputAtIndex(flatIndex, value);
}
fn getBiasByOutputCoords(coords : vec4<i32>) -> bias_value_t {
  return bias[u32(coords.w)];
}fn mm_readA(batch : i32, row : i32, colIn : i32) -> vec3<x_element_t> {
let col = colIn * 3;
if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_inner)) {
  let inChannels = i32(uniforms.w_shape[2]);
let outWidth = i32(uniforms.result_shape[2]);
let outRow = row / outWidth;
 let outCol = row % outWidth;
let WRow = col / (i32(uniforms.w_shape[1]) * inChannels);
let WCol = col / inChannels % i32(uniforms.w_shape[1]);
let xRow = outRow * i32(uniforms.strides[0]) + i32(uniforms.dilations[0]) * WRow - i32(uniforms.pads[0]);
let xCol = outCol * i32(uniforms.strides[1]) + i32(uniforms.dilations[1]) * WCol - i32(uniforms.pads[1]);
let xCh = col % inChannels;
var resData = vec3<x_element_t>(0.0);
 // The bounds checking is always needed since we use it to pad zero for
// the " same " padding type.
if (xRow >= 0 && xRow < i32(uniforms.x_shape[1]) && xCol >= 0 && xCol < i32(uniforms.x_shape[2])) {
  let coord = vec4<i32>(batch, xRow, xCol, xCh / 4);
  let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
  resData = vec3<x_element_t>(x[xIndex], x[xIndex + 1], x[xIndex + 2]);}
return resData;
}
return vec3<x_element_t>(0.0);
}

fn mm_readB(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_inner) && col < i32(uniforms.dim_b_outer)) {
  return w[row * i32(uniforms.w_shape[3])  + colIn];

}
return vec4<x_element_t>(0.0);
}

fn mm_write(batch : i32, row : i32, colIn : i32, valueIn : vec4<x_element_t>) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let outWidth =  i32(uniforms.result_shape[2]) ;
    let coords = vec4<i32>(batch, row / outWidth, row % outWidth, col / 4);
    value = value + getBiasByOutputCoords(coords);
    value = value * (vec4<x_element_t>(x_element_t(1)) / (vec4<x_element_t>(x_element_t(1)) + exp(-value)));
    setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
  }
}
var<workgroup> mm_Asub: array<array<vec3<x_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<x_element_t>, 8>, 24>;
const rowPerThread = 4;
const colPerThread = 4;
const innerElementSize = 3;
const tileInner = 24;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<x_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let tileRowB = localRow * 3;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol);
    }
    for (var innerRow = 0; innerRow < 3; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|8|3,1,1,0,0,32,32,24,4,]:8,8,1:1|1|1|4|2|2|1|1|1||:0;4|2;4|2;1:2;4"] End ===


=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,1,1,0,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> w: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> result: array<vec4<f32>>;
struct Uniforms {
  x_shape: vec4<u32>,
  x_stride: vec3<u32>,
  w_shape: vec4<u32>,
  w_stride: vec3<u32>,
  result_shape: vec4<u32>,
  result_stride: vec3<u32>,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  pads: vec4<u32>,
  strides: vec2<u32>,
  dilations: vec2<u32>,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias x_value_t = vec4<f32>;
alias x_indices_t = vec4<u32>;
alias x_element_t = f32;
alias w_value_t = vec4<f32>;
alias w_indices_t = vec4<u32>;
alias bias_value_t = vec4<f32>;
alias bias_indices_t = u32;
alias bias_element_t = f32;
alias result_indices_t = vec4<u32>;

fn getIndexFromCoords3D(coords : vec3<i32>, shape : vec3<i32>) -> i32 {
  return dot(coords, vec3<i32>(shape.y * shape.z, shape.z, 1));
}
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(i32(uniforms.result_stride.x), i32(uniforms.result_stride.y), i32(uniforms.result_stride.z), 1));
}
fn setOutputAtIndex(flatIndex : i32, value : vec4<x_element_t>) {
  result[u32(flatIndex)]=vec4<x_element_t>(value);
}
fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : vec4<x_element_t>){
  let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
  setOutputAtIndex(flatIndex, value);
}
fn getBiasByOutputCoords(coords : vec4<i32>) -> bias_value_t {
  return bias[u32(coords.w)];
}fn mm_readA(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_inner)) {
  let inChannels = i32(uniforms.w_shape[2]);
let outWidth = i32(uniforms.result_shape[2]);
let outRow = row / outWidth;
 let outCol = row % outWidth;
let WRow = col / (i32(uniforms.w_shape[1]) * inChannels);
let WCol = col / inChannels % i32(uniforms.w_shape[1]);
let xRow = outRow * i32(uniforms.strides[0]) + i32(uniforms.dilations[0]) * WRow - i32(uniforms.pads[0]);
let xCol = outCol * i32(uniforms.strides[1]) + i32(uniforms.dilations[1]) * WCol - i32(uniforms.pads[1]);
let xCh = col % inChannels;
var resData = vec4<x_element_t>(0.0);
 // The bounds checking is always needed since we use it to pad zero for
// the " same " padding type.
if (xRow >= 0 && xRow < i32(uniforms.x_shape[1]) && xCol >= 0 && xCol < i32(uniforms.x_shape[2])) {
  let coord = vec4<i32>(batch, xRow, xCol, xCh / 4);
  let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
  resData = x[xIndex];
 }
return resData;
}
return vec4<x_element_t>(0.0);
}

fn mm_readB(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_inner) && col < i32(uniforms.dim_b_outer)) {
  return w[row * i32(uniforms.w_shape[3])  + colIn];

}
return vec4<x_element_t>(0.0);
}

fn mm_write(batch : i32, row : i32, colIn : i32, valueIn : vec4<x_element_t>) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let outWidth =  i32(uniforms.result_shape[2]) ;
    let coords = vec4<i32>(batch, row / outWidth, row % outWidth, col / 4);
    value = value + getBiasByOutputCoords(coords);
    value = value * (vec4<x_element_t>(x_element_t(1)) / (vec4<x_element_t>(x_element_t(1)) + exp(-value)));
    setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
  }
}
var<workgroup> mm_Asub: array<array<vec4<x_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<x_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<x_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,1,1,0,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] End ===


=== WebGPU Shader code [MatMul, Key="MatMul[ActivationKind: 7;QuickGeluUnitAlpha: 1;|4-1-1|1|4|1|1|32]:8,32,1:1|1|1|1|1|1|1||:2;3|2;2|1:3:1"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> a: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> b: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  a_shape: vec3<u32>,
  a_stride: vec2<u32>,
  b_shape: vec2<u32>,
  b_stride: u32,
  output_shape: vec3<u32>,
  output_stride: vec2<u32>,
  batch_dims_shape: u32,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32,
  splits_per_batch: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias a_value_t = vec4<f32>;
alias a_indices_t = vec3<u32>;
alias a_element_t = f32;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride[0] + indices[1] * uniforms.a_stride[1] + indices[2];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->a_value_t {
  return a[i2o_a(indices_fnarg)];
}
alias b_value_t = vec4<f32>;
alias b_indices_t = vec2<u32>;
fn i2o_b(indices : b_indices_t)->u32 {
  return indices[0] * uniforms.b_stride + indices[1];
}
fn get_b_by_indices(indices_fnarg: b_indices_t)->b_value_t {
  return b[i2o_b(indices_fnarg)];
}
alias output_value_t = vec4<f32>;
alias output_indices_t = vec3<u32>;
alias output_element_t = f32;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride[0] + indices[1] * uniforms.output_stride[1] + indices[2];
}
fn set_output_by_indices(indices: output_indices_t, value: output_value_t) {
  output[i2o_output(indices)]=value;
}
alias batch_dims_indices_t = u32;

fn mm_readA(batch: i32, row: i32, colIn: i32 , batch_indices: batch_dims_indices_t) -> vec4<output_element_t> {
     var value = vec4<output_element_t>(0);
    let col = colIn * 4;
    if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_inner)) {
        var a_indices: a_indices_t;
if (uniforms.a_shape[0] != 1) {
a_indices[0]= batch_indices ;
} else {
a_indices[0]=0;
}

a_indices[1]=u32(row);
a_indices[2]=u32(colIn);
        value = get_a_by_indices(a_indices);
    }
    return value;
}

fn mm_readB(batch: i32, row: i32, colIn: i32 , batch_indices: batch_dims_indices_t) -> vec4<output_element_t> {
     var value = vec4<output_element_t>(0);
    let col = colIn * 4;
    if(row < i32(uniforms.dim_inner) && col < i32(uniforms.dim_b_outer)) {
        var b_indices: b_indices_t;

b_indices[0]=u32(row);
b_indices[1]=u32(colIn);
        value = get_b_by_indices(b_indices);
    }
    return value;
}

fn mm_write(batch: i32, row: i32, colIn: i32, valueIn: output_value_t) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let coords = vec3(u32(batch), u32(row), u32(colIn));
    value = value + output_value_t(bias[colIn]);
    value = value * (output_value_t(output_element_t(1)) / (output_value_t(output_element_t(1)) + exp(-value)));
    set_output_by_indices(coords, value);
  }
}

var<workgroup> mm_Asub: array<array<vec4<a_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<a_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<a_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let batchIndices = u32(batch);
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol, batchIndices);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol, batchIndices);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [MatMul, Key="MatMul[ActivationKind: 7;QuickGeluUnitAlpha: 1;|4-1-1|1|4|1|1|32]:8,32,1:1|1|1|1|1|1|1||:2;3|2;2|1:3:1"] End ===


=== WebGPU Shader code [Slice, Key="Slice:1|4|4|4:2;4:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  input_shape: vec4<u32>,
  input_stride: vec3<u32>,
  output_shape: vec4<u32>,
  output_stride: vec3<u32>,
  output_size: u32,
  starts: vec4<u32>,
  steps: vec4<u32>,
  signs: vec4<i32>
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias input_indices_t = vec4<u32>;
fn i2o_input(indices : input_indices_t)->u32 {
  return indices[0] * uniforms.input_stride[0] + indices[1] * uniforms.input_stride[1] + indices[2] * uniforms.input_stride[2] + indices[3];
}
fn get_input_by_indices(indices_fnarg: input_indices_t)->vec4<f32> {
  return input[i2o_input(indices_fnarg)];
}
alias output_indices_t = vec4<u32>;
fn o2i_output(offset : u32)->output_indices_t {
  var indices: output_indices_t;
  var current = offset;
  indices[0] = current / uniforms.output_stride[0];
  current = current % uniforms.output_stride[0];
  indices[1] = current / uniforms.output_stride[1];
  current = current % uniforms.output_stride[1];
  indices[2] = current / uniforms.output_stride[2];
  current = current % uniforms.output_stride[2];
  indices[3] = current;
  return indices;
}

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
let output_indices = o2i_output(global_idx);
var input_indices: input_indices_t;
var carry = 0u;
let input_shape_3 = uniforms.input_shape[3];
let steps_3 = uniforms.steps[3];
let starts_3 = uniforms.starts[3];
var output_index_3 = output_indices[3];
var input_index_3 = output_index_3 * steps_3 + starts_3 + carry;
carry = input_index_3 / input_shape_3;
input_index_3 = input_index_3 % input_shape_3;
if (uniforms.signs[3] < 0) {
  input_index_3 = input_shape_3 - input_index_3 - 1u + starts_3;
}
input_indices[3]=input_index_3;;
let input_shape_2 = uniforms.input_shape[2];
let steps_2 = uniforms.steps[2];
let starts_2 = uniforms.starts[2];
var output_index_2 = output_indices[2];
var input_index_2 = output_index_2 * steps_2 + starts_2 + carry;
carry = input_index_2 / input_shape_2;
input_index_2 = input_index_2 % input_shape_2;
if (uniforms.signs[2] < 0) {
  input_index_2 = input_shape_2 - input_index_2 - 1u + starts_2;
}
input_indices[2]=input_index_2;;
let input_shape_1 = uniforms.input_shape[1];
let steps_1 = uniforms.steps[1];
let starts_1 = uniforms.starts[1];
var output_index_1 = output_indices[1];
var input_index_1 = output_index_1 * steps_1 + starts_1 + carry;
carry = input_index_1 / input_shape_1;
input_index_1 = input_index_1 % input_shape_1;
if (uniforms.signs[1] < 0) {
  input_index_1 = input_shape_1 - input_index_1 - 1u + starts_1;
}
input_indices[1]=input_index_1;;
let input_shape_0 = uniforms.input_shape[0];
let steps_0 = uniforms.steps[0];
let starts_0 = uniforms.starts[0];
var output_index_0 = output_indices[0];
var input_index_0 = output_index_0 * steps_0 + starts_0 + carry;
carry = input_index_0 / input_shape_0;
input_index_0 = input_index_0 % input_shape_0;
if (uniforms.signs[0] < 0) {
  input_index_0 = input_shape_0 - input_index_0 - 1u + starts_0;
}
input_indices[0]=input_index_0;;
output[global_idx]=get_input_by_indices(input_indices);
}

=== WebGPU Shader code [Slice, Key="Slice:1|4|4|4:2;4:2;4"] End ===


=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,1,0,0,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> w: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> result: array<vec4<f32>>;
struct Uniforms {
  x_shape: vec4<u32>,
  x_stride: vec3<u32>,
  w_shape: vec4<u32>,
  w_stride: vec3<u32>,
  result_shape: vec4<u32>,
  result_stride: vec3<u32>,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  pads: vec4<u32>,
  strides: vec2<u32>,
  dilations: vec2<u32>,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias x_value_t = vec4<f32>;
alias x_indices_t = vec4<u32>;
alias x_element_t = f32;
alias w_value_t = vec4<f32>;
alias w_indices_t = vec4<u32>;
alias bias_value_t = vec4<f32>;
alias bias_indices_t = u32;
alias bias_element_t = f32;
alias result_indices_t = vec4<u32>;

fn getIndexFromCoords3D(coords : vec3<i32>, shape : vec3<i32>) -> i32 {
  return dot(coords, vec3<i32>(shape.y * shape.z, shape.z, 1));
}
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(i32(uniforms.result_stride.x), i32(uniforms.result_stride.y), i32(uniforms.result_stride.z), 1));
}
fn setOutputAtIndex(flatIndex : i32, value : vec4<x_element_t>) {
  result[u32(flatIndex)]=vec4<x_element_t>(value);
}
fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : vec4<x_element_t>){
  let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
  setOutputAtIndex(flatIndex, value);
}
fn getBiasByOutputCoords(coords : vec4<i32>) -> bias_value_t {
  return bias[u32(coords.w)];
}fn mm_readA(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_inner)) {
  let inChannels = i32(uniforms.w_shape[2]);
let outWidth = i32(uniforms.result_shape[2]);
let outRow = row / outWidth;
 let outCol = row % outWidth;
let WRow = col / (i32(uniforms.w_shape[1]) * inChannels);
let WCol = col / inChannels % i32(uniforms.w_shape[1]);
let xRow = outRow * i32(uniforms.strides[0]) + i32(uniforms.dilations[0]) * WRow - i32(uniforms.pads[0]);
let xCol = outCol * i32(uniforms.strides[1]) + i32(uniforms.dilations[1]) * WCol - i32(uniforms.pads[1]);
let xCh = col % inChannels;
var resData = vec4<x_element_t>(0.0);
 // The bounds checking is always needed since we use it to pad zero for
// the " same " padding type.
if (xRow >= 0 && xRow < i32(uniforms.x_shape[1]) && xCol >= 0 && xCol < i32(uniforms.x_shape[2])) {
  let coord = vec4<i32>(batch, xRow, xCol, xCh / 4);
  let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
  resData = x[xIndex];
 }
return resData;
}
return vec4<x_element_t>(0.0);
}

fn mm_readB(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_inner) && col < i32(uniforms.dim_b_outer)) {
  return w[row * i32(uniforms.w_shape[3])  + colIn];

}
return vec4<x_element_t>(0.0);
}

fn mm_write(batch : i32, row : i32, colIn : i32, valueIn : vec4<x_element_t>) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let outWidth =  i32(uniforms.result_shape[2]) ;
    let coords = vec4<i32>(batch, row / outWidth, row % outWidth, col / 4);
    value = value + getBiasByOutputCoords(coords);
    value = value * (vec4<x_element_t>(x_element_t(1)) / (vec4<x_element_t>(x_element_t(1)) + exp(-value)));
    setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
  }
}
var<workgroup> mm_Asub: array<array<vec4<x_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<x_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<x_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,1,0,0,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] End ===


=== WebGPU Shader code [Add, Key="Add[E00]:1|1:2;|2;:2;"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input_a: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> input_b: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  vec_size: u32,
  element_count: u32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias input_a_value_t = vec4<f32>;
alias input_a_element_t = f32;
alias input_b_value_t = vec4<f32>;
alias input_b_element_t = f32;
alias output_value_t = vec4<f32>;

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.vec_size) { return; }
let a = input_a[global_idx];
let b = input_b[global_idx];
output[global_idx]=a + b;
}

=== WebGPU Shader code [Add, Key="Add[E00]:1|1:2;|2;:2;"] End ===


=== WebGPU Shader code [MatMul, Key="MatMul[ActivationKind: 0;|4-1-1|1|4|1|1|32]:8,32,1:1|1|1|1|1|1|1||:2;3|2;2:3:1"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> a: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> b: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  a_shape: vec3<u32>,
  a_stride: vec2<u32>,
  b_shape: vec2<u32>,
  b_stride: u32,
  output_shape: vec3<u32>,
  output_stride: vec2<u32>,
  batch_dims_shape: u32,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32,
  splits_per_batch: u32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias a_value_t = vec4<f32>;
alias a_indices_t = vec3<u32>;
alias a_element_t = f32;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride[0] + indices[1] * uniforms.a_stride[1] + indices[2];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->a_value_t {
  return a[i2o_a(indices_fnarg)];
}
alias b_value_t = vec4<f32>;
alias b_indices_t = vec2<u32>;
fn i2o_b(indices : b_indices_t)->u32 {
  return indices[0] * uniforms.b_stride + indices[1];
}
fn get_b_by_indices(indices_fnarg: b_indices_t)->b_value_t {
  return b[i2o_b(indices_fnarg)];
}
alias output_value_t = vec4<f32>;
alias output_indices_t = vec3<u32>;
alias output_element_t = f32;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride[0] + indices[1] * uniforms.output_stride[1] + indices[2];
}
fn set_output_by_indices(indices: output_indices_t, value: output_value_t) {
  output[i2o_output(indices)]=value;
}
alias batch_dims_indices_t = u32;

fn mm_readA(batch: i32, row: i32, colIn: i32 , batch_indices: batch_dims_indices_t) -> vec4<output_element_t> {
     var value = vec4<output_element_t>(0);
    let col = colIn * 4;
    if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_inner)) {
        var a_indices: a_indices_t;
if (uniforms.a_shape[0] != 1) {
a_indices[0]= batch_indices ;
} else {
a_indices[0]=0;
}

a_indices[1]=u32(row);
a_indices[2]=u32(colIn);
        value = get_a_by_indices(a_indices);
    }
    return value;
}

fn mm_readB(batch: i32, row: i32, colIn: i32 , batch_indices: batch_dims_indices_t) -> vec4<output_element_t> {
     var value = vec4<output_element_t>(0);
    let col = colIn * 4;
    if(row < i32(uniforms.dim_inner) && col < i32(uniforms.dim_b_outer)) {
        var b_indices: b_indices_t;

b_indices[0]=u32(row);
b_indices[1]=u32(colIn);
        value = get_b_by_indices(b_indices);
    }
    return value;
}

fn mm_write(batch: i32, row: i32, colIn: i32, valueIn: output_value_t) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let coords = vec3(u32(batch), u32(row), u32(colIn));
    
    set_output_by_indices(coords, value);
  }
}

var<workgroup> mm_Asub: array<array<vec4<a_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<a_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<a_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let batchIndices = u32(batch);
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol, batchIndices);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol, batchIndices);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [MatMul, Key="MatMul[ActivationKind: 0;|4-1-1|1|4|1|1|32]:8,32,1:1|1|1|1|1|1|1||:2;3|2;2:3:1"] End ===


=== WebGPU Shader code [MatMul, Key="MatMul[ActivationKind: 0;|4-1-1|1|4|1|1|32]:8,32,1:1|1|1|1|1|1|1||:2;3|2;2|1:3:1"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> a: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> b: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  a_shape: vec3<u32>,
  a_stride: vec2<u32>,
  b_shape: vec2<u32>,
  b_stride: u32,
  output_shape: vec3<u32>,
  output_stride: vec2<u32>,
  batch_dims_shape: u32,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32,
  splits_per_batch: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias a_value_t = vec4<f32>;
alias a_indices_t = vec3<u32>;
alias a_element_t = f32;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride[0] + indices[1] * uniforms.a_stride[1] + indices[2];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->a_value_t {
  return a[i2o_a(indices_fnarg)];
}
alias b_value_t = vec4<f32>;
alias b_indices_t = vec2<u32>;
fn i2o_b(indices : b_indices_t)->u32 {
  return indices[0] * uniforms.b_stride + indices[1];
}
fn get_b_by_indices(indices_fnarg: b_indices_t)->b_value_t {
  return b[i2o_b(indices_fnarg)];
}
alias output_value_t = vec4<f32>;
alias output_indices_t = vec3<u32>;
alias output_element_t = f32;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride[0] + indices[1] * uniforms.output_stride[1] + indices[2];
}
fn set_output_by_indices(indices: output_indices_t, value: output_value_t) {
  output[i2o_output(indices)]=value;
}
alias batch_dims_indices_t = u32;

fn mm_readA(batch: i32, row: i32, colIn: i32 , batch_indices: batch_dims_indices_t) -> vec4<output_element_t> {
     var value = vec4<output_element_t>(0);
    let col = colIn * 4;
    if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_inner)) {
        var a_indices: a_indices_t;
if (uniforms.a_shape[0] != 1) {
a_indices[0]= batch_indices ;
} else {
a_indices[0]=0;
}

a_indices[1]=u32(row);
a_indices[2]=u32(colIn);
        value = get_a_by_indices(a_indices);
    }
    return value;
}

fn mm_readB(batch: i32, row: i32, colIn: i32 , batch_indices: batch_dims_indices_t) -> vec4<output_element_t> {
     var value = vec4<output_element_t>(0);
    let col = colIn * 4;
    if(row < i32(uniforms.dim_inner) && col < i32(uniforms.dim_b_outer)) {
        var b_indices: b_indices_t;

b_indices[0]=u32(row);
b_indices[1]=u32(colIn);
        value = get_b_by_indices(b_indices);
    }
    return value;
}

fn mm_write(batch: i32, row: i32, colIn: i32, valueIn: output_value_t) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let coords = vec3(u32(batch), u32(row), u32(colIn));
    value = value + output_value_t(bias[colIn]);
    
    set_output_by_indices(coords, value);
  }
}

var<workgroup> mm_Asub: array<array<vec4<a_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<a_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<a_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let batchIndices = u32(batch);
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol, batchIndices);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol, batchIndices);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [MatMul, Key="MatMul[ActivationKind: 0;|4-1-1|1|4|1|1|32]:8,32,1:1|1|1|1|1|1|1||:2;3|2;2|1:3:1"] End ===


=== WebGPU Shader code [QuickGelu, Key="QuickGelu:1|1:2;:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> y: array<vec4<f32>>;
struct Uniforms {
  vec_size: u32,
  attr: f32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias x_element_t = f32;


fn quick_gelu_v(a: vec4<x_element_t>) -> vec4<x_element_t> {
  let one = x_element_t(1.0);
  let zero = x_element_t(0.0);
  let alpha_vec = vec4<x_element_t>(x_element_t(uniforms.attr));
  let v = a * alpha_vec;
  var x1 : vec4<x_element_t>;
  for (var i = 0; i < 4; i = i + 1) {
    if (v[i] >= zero) {
      x1[i] = one / (one + exp(-v[i]));
    } else {
      x1[i] = one - one / (one + exp(v[i]));
    }
  }
  return a * x1;
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.vec_size) { return; }
  let a = x[global_idx];
  y[global_idx]=quick_gelu_v(a);
}

=== WebGPU Shader code [QuickGelu, Key="QuickGelu:1|1:2;:"] End ===


=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,1,1,1,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> w: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> result: array<vec4<f32>>;
struct Uniforms {
  x_shape: vec4<u32>,
  x_stride: vec3<u32>,
  w_shape: vec4<u32>,
  w_stride: vec3<u32>,
  result_shape: vec4<u32>,
  result_stride: vec3<u32>,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  pads: vec4<u32>,
  strides: vec2<u32>,
  dilations: vec2<u32>,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias x_value_t = vec4<f32>;
alias x_indices_t = vec4<u32>;
alias x_element_t = f32;
alias w_value_t = vec4<f32>;
alias w_indices_t = vec4<u32>;
alias bias_value_t = vec4<f32>;
alias bias_indices_t = u32;
alias bias_element_t = f32;
alias result_indices_t = vec4<u32>;

fn getIndexFromCoords3D(coords : vec3<i32>, shape : vec3<i32>) -> i32 {
  return dot(coords, vec3<i32>(shape.y * shape.z, shape.z, 1));
}
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(i32(uniforms.result_stride.x), i32(uniforms.result_stride.y), i32(uniforms.result_stride.z), 1));
}
fn setOutputAtIndex(flatIndex : i32, value : vec4<x_element_t>) {
  result[u32(flatIndex)]=vec4<x_element_t>(value);
}
fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : vec4<x_element_t>){
  let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
  setOutputAtIndex(flatIndex, value);
}
fn getBiasByOutputCoords(coords : vec4<i32>) -> bias_value_t {
  return bias[u32(coords.w)];
}fn mm_readA(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
let inChannels = i32(uniforms.w_shape[2]);
let outWidth = i32(uniforms.result_shape[2]);
let outRow = row / outWidth;
 let outCol = row % outWidth;
let WRow = col / (i32(uniforms.w_shape[1]) * inChannels);
let WCol = col / inChannels % i32(uniforms.w_shape[1]);
let xRow = outRow * i32(uniforms.strides[0]) + i32(uniforms.dilations[0]) * WRow - i32(uniforms.pads[0]);
let xCol = outCol * i32(uniforms.strides[1]) + i32(uniforms.dilations[1]) * WCol - i32(uniforms.pads[1]);
let xCh = col % inChannels;
var resData = vec4<x_element_t>(0.0);
 // The bounds checking is always needed since we use it to pad zero for
// the " same " padding type.
if (xRow >= 0 && xRow < i32(uniforms.x_shape[1]) && xCol >= 0 && xCol < i32(uniforms.x_shape[2])) {
  let coord = vec4<i32>(batch, xRow, xCol, xCh / 4);
  let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
  resData = x[xIndex];
 }
return resData;}

fn mm_readB(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
return w[row * i32(uniforms.w_shape[3])  + colIn];
}

fn mm_write(batch : i32, row : i32, colIn : i32, valueIn : vec4<x_element_t>) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let outWidth =  i32(uniforms.result_shape[2]) ;
    let coords = vec4<i32>(batch, row / outWidth, row % outWidth, col / 4);
    value = value + getBiasByOutputCoords(coords);
    value = value * (vec4<x_element_t>(x_element_t(1)) / (vec4<x_element_t>(x_element_t(1)) + exp(-value)));
    setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
  }
}
var<workgroup> mm_Asub: array<array<vec4<x_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<x_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<x_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,1,1,1,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] End ===


=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,1,0,1,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> w: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> result: array<vec4<f32>>;
struct Uniforms {
  x_shape: vec4<u32>,
  x_stride: vec3<u32>,
  w_shape: vec4<u32>,
  w_stride: vec3<u32>,
  result_shape: vec4<u32>,
  result_stride: vec3<u32>,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  pads: vec4<u32>,
  strides: vec2<u32>,
  dilations: vec2<u32>,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias x_value_t = vec4<f32>;
alias x_indices_t = vec4<u32>;
alias x_element_t = f32;
alias w_value_t = vec4<f32>;
alias w_indices_t = vec4<u32>;
alias bias_value_t = vec4<f32>;
alias bias_indices_t = u32;
alias bias_element_t = f32;
alias result_indices_t = vec4<u32>;

fn getIndexFromCoords3D(coords : vec3<i32>, shape : vec3<i32>) -> i32 {
  return dot(coords, vec3<i32>(shape.y * shape.z, shape.z, 1));
}
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(i32(uniforms.result_stride.x), i32(uniforms.result_stride.y), i32(uniforms.result_stride.z), 1));
}
fn setOutputAtIndex(flatIndex : i32, value : vec4<x_element_t>) {
  result[u32(flatIndex)]=vec4<x_element_t>(value);
}
fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : vec4<x_element_t>){
  let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
  setOutputAtIndex(flatIndex, value);
}
fn getBiasByOutputCoords(coords : vec4<i32>) -> bias_value_t {
  return bias[u32(coords.w)];
}fn mm_readA(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
let inChannels = i32(uniforms.w_shape[2]);
let outWidth = i32(uniforms.result_shape[2]);
let outRow = row / outWidth;
 let outCol = row % outWidth;
let WRow = col / (i32(uniforms.w_shape[1]) * inChannels);
let WCol = col / inChannels % i32(uniforms.w_shape[1]);
let xRow = outRow * i32(uniforms.strides[0]) + i32(uniforms.dilations[0]) * WRow - i32(uniforms.pads[0]);
let xCol = outCol * i32(uniforms.strides[1]) + i32(uniforms.dilations[1]) * WCol - i32(uniforms.pads[1]);
let xCh = col % inChannels;
var resData = vec4<x_element_t>(0.0);
 // The bounds checking is always needed since we use it to pad zero for
// the " same " padding type.
if (xRow >= 0 && xRow < i32(uniforms.x_shape[1]) && xCol >= 0 && xCol < i32(uniforms.x_shape[2])) {
  let coord = vec4<i32>(batch, xRow, xCol, xCh / 4);
  let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
  resData = x[xIndex];
 }
return resData;}

fn mm_readB(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_inner) && col < i32(uniforms.dim_b_outer)) {
  return w[row * i32(uniforms.w_shape[3])  + colIn];

}
return vec4<x_element_t>(0.0);
}

fn mm_write(batch : i32, row : i32, colIn : i32, valueIn : vec4<x_element_t>) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let outWidth =  i32(uniforms.result_shape[2]) ;
    let coords = vec4<i32>(batch, row / outWidth, row % outWidth, col / 4);
    value = value + getBiasByOutputCoords(coords);
    value = value * (vec4<x_element_t>(x_element_t(1)) / (vec4<x_element_t>(x_element_t(1)) + exp(-value)));
    setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
  }
}
var<workgroup> mm_Asub: array<array<vec4<x_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<x_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<x_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,1,0,1,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] End ===


=== WebGPU Shader code [Transpose, Key="Transpose[0-3-1-2]:32,8,1:1:0;2:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 32;
const workgroup_size_y: u32 = 8;
const workgroup_size_z: u32 = 1;
const tile_size: u32 = 32;
const tile_rows: u32 = 8;
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<f32>;
struct Uniforms {
  a_shape: vec2<u32>,
  a_stride: u32,
  output_shape: vec2<u32>,
  output_stride: u32,
  output_size: u32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias a_indices_t = vec2<u32>;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride + indices[1];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->f32 {
  return a[i2o_a(indices_fnarg)];
}
alias output_value_t = f32;
alias output_indices_t = vec2<u32>;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride + indices[1];
}
fn set_output_by_indices(indices: output_indices_t, value: output_value_t) {
  output[i2o_output(indices)]=value;
}

var<workgroup> tile : array<array<output_value_t, tile_size + 1>, tile_size>;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let stride = (uniforms.output_shape[1] - 1) / tile_size + 1;
  let workgroup_id_x = workgroup_idx % stride;
  let workgroup_id_y = workgroup_idx / stride;
  let input_col = workgroup_id_y * tile_size + local_id.x;
  for (var j: u32 = 0u; j < tile_size; j += tile_rows) {
    let input_row = workgroup_id_x * tile_size + local_id.y + j;
    if (input_row < uniforms.a_shape[0] && input_col < uniforms.a_shape[1]) {
      tile[local_id.y + j][local_id.x] = get_a_by_indices(a_indices_t(input_row, input_col));
    }
  }
  workgroupBarrier();
  let output_col = workgroup_id_x * tile_size + local_id.x;
  for (var j: u32 = 0u; j < tile_size; j += tile_rows) {
    let output_row = workgroup_id_y * tile_size + local_id.y + j;
    if (output_row < uniforms.output_shape[0] && output_col < uniforms.output_shape[1]) {
      set_output_by_indices(output_indices_t(output_row, output_col), tile[local_id.x][local_id.y + j]);
    }
  }
}

=== WebGPU Shader code [Transpose, Key="Transpose[0-3-1-2]:32,8,1:1:0;2:"] End ===


=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,0,1,1,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> w: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> result: array<vec4<f32>>;
struct Uniforms {
  x_shape: vec4<u32>,
  x_stride: vec3<u32>,
  w_shape: vec4<u32>,
  w_stride: vec3<u32>,
  result_shape: vec4<u32>,
  result_stride: vec3<u32>,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  pads: vec4<u32>,
  strides: vec2<u32>,
  dilations: vec2<u32>,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias x_value_t = vec4<f32>;
alias x_indices_t = vec4<u32>;
alias x_element_t = f32;
alias w_value_t = vec4<f32>;
alias w_indices_t = vec4<u32>;
alias bias_value_t = vec4<f32>;
alias bias_indices_t = u32;
alias bias_element_t = f32;
alias result_indices_t = vec4<u32>;

fn getIndexFromCoords3D(coords : vec3<i32>, shape : vec3<i32>) -> i32 {
  return dot(coords, vec3<i32>(shape.y * shape.z, shape.z, 1));
}
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(i32(uniforms.result_stride.x), i32(uniforms.result_stride.y), i32(uniforms.result_stride.z), 1));
}
fn setOutputAtIndex(flatIndex : i32, value : vec4<x_element_t>) {
  result[u32(flatIndex)]=vec4<x_element_t>(value);
}
fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : vec4<x_element_t>){
  let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
  setOutputAtIndex(flatIndex, value);
}
fn getBiasByOutputCoords(coords : vec4<i32>) -> bias_value_t {
  return bias[u32(coords.w)];
}fn mm_readA(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_inner)) {
  let inChannels = i32(uniforms.w_shape[2]);
let outWidth = i32(uniforms.result_shape[2]);
let outRow = row / outWidth;
 let outCol = row % outWidth;
let WRow = col / (i32(uniforms.w_shape[1]) * inChannels);
let WCol = col / inChannels % i32(uniforms.w_shape[1]);
let xRow = outRow * i32(uniforms.strides[0]) + i32(uniforms.dilations[0]) * WRow - i32(uniforms.pads[0]);
let xCol = outCol * i32(uniforms.strides[1]) + i32(uniforms.dilations[1]) * WCol - i32(uniforms.pads[1]);
let xCh = col % inChannels;
var resData = vec4<x_element_t>(0.0);
 // The bounds checking is always needed since we use it to pad zero for
// the " same " padding type.
if (xRow >= 0 && xRow < i32(uniforms.x_shape[1]) && xCol >= 0 && xCol < i32(uniforms.x_shape[2])) {
  let coord = vec4<i32>(batch, xRow, xCol, xCh / 4);
  let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
  resData = x[xIndex];
 }
return resData;
}
return vec4<x_element_t>(0.0);
}

fn mm_readB(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
return w[row * i32(uniforms.w_shape[3])  + colIn];
}

fn mm_write(batch : i32, row : i32, colIn : i32, valueIn : vec4<x_element_t>) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let outWidth =  i32(uniforms.result_shape[2]) ;
    let coords = vec4<i32>(batch, row / outWidth, row % outWidth, col / 4);
    value = value + getBiasByOutputCoords(coords);
    value = value * (vec4<x_element_t>(x_element_t(1)) / (vec4<x_element_t>(x_element_t(1)) + exp(-value)));
    setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
  }
}
var<workgroup> mm_Asub: array<array<vec4<x_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<x_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<x_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,0,1,1,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] End ===


=== WebGPU Shader code [Pool, Key="Pool[2|1|1|0|0|0]:1|1|2|4|2|2:2;4:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  input_shape: vec4<u32>,
  input_stride: vec3<u32>,
  output_shape: vec4<u32>,
  output_stride: vec3<u32>,
  output_size: u32,
  kernel_size: u32,
  kernel_strides: vec2<u32>,
  pads: vec4<u32>,
  strides: vec2<u32>,
  dilations: vec2<u32>
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias input_value_t = vec4<f32>;
fn i2o_input(indices : vec4<u32>)->u32 {
  return indices[0] * uniforms.input_stride[0] + indices[1] * uniforms.input_stride[1] + indices[2] * uniforms.input_stride[2] + indices[3];
}
fn get_input_by_indices(indices_fnarg: vec4<u32>)->input_value_t {
  return input[i2o_input(indices_fnarg)];
}
fn o2i_output(offset : u32)->vec4<u32> {
  var indices: vec4<u32>;
  var current = offset;
  indices[0] = current / uniforms.output_stride[0];
  current = current % uniforms.output_stride[0];
  indices[1] = current / uniforms.output_stride[1];
  current = current % uniforms.output_stride[1];
  indices[2] = current / uniforms.output_stride[2];
  current = current % uniforms.output_stride[2];
  indices[3] = current;
  return indices;
}

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
  let y_indices = o2i_output(global_idx);
  var x_indices = y_indices;
  var k_indices: array<u32, 2>;
  var value = input_value_t(-3.4028234663852886e+38f);
  for (var i: u32 = 0; i < uniforms.kernel_size; i++) {
    var offset = i;
    for (var j = 0; j < 2; j++) {
      k_indices[j] = offset / uniforms.kernel_strides[j];
      offset = offset % uniforms.kernel_strides[j];
    }
    for (var j = 0; j < 2; j++) {
      k_indices[j] *= uniforms.dilations[j];
    }
    var is_pad = false;
    for (var j = 1; j < 3; j++) {
      let d_idx = j - 1;
      x_indices[j] = y_indices[j] * uniforms.strides[d_idx];
      x_indices[j] += k_indices[d_idx];
      x_indices[j] -= uniforms.pads[d_idx];
      let j_dim_len = uniforms.input_shape[j];
      if (x_indices[j] < 0 || x_indices[j] >= j_dim_len) {
        is_pad = true;
        break;
      }
    }
    if (!is_pad) {
      let x_val = get_input_by_indices(x_indices);
      value = max(value, x_val);
    }
  }
  output[global_idx]=value;;

}

=== WebGPU Shader code [Pool, Key="Pool[2|1|1|0|0|0]:1|1|2|4|2|2:2;4:"] End ===


=== WebGPU Shader code [Split, Key="Split[2|4]:1|1|2:2;:2;|2;"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> output_0: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output_1: array<vec4<f32>>;
struct Uniforms {
  input_size: u32,
  total_segment_elements: u32,
  segment_sizes: vec2<u32>
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias input_value_t = vec4<f32>;
alias output_0_value_t = vec4<f32>;
alias output_1_value_t = vec4<f32>;

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.input_size) { return; }
  let outer_index = global_idx / uniforms.total_segment_elements;
  let within_outer = global_idx % uniforms.total_segment_elements;
  var segment_start = 0u;
  {
    let segment_size = uniforms.segment_sizes[0];
    if (within_outer < segment_start + segment_size) {
      output_0[outer_index * segment_size + within_outer - segment_start]=input[global_idx];
      return;
    }
    segment_start += segment_size;
  }
  {
    let segment_size = uniforms.segment_sizes[1];
    if (within_outer < segment_start + segment_size) {
      output_1[outer_index * segment_size + within_outer - segment_start]=input[global_idx];
      return;
    }
    segment_start += segment_size;
  }

}

=== WebGPU Shader code [Split, Key="Split[2|4]:1|1|2:2;:2;|2;"] End ===


=== WebGPU Shader code [Split, Key="Split[3|4]:1|1|3:2;:2;|2;|2;"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> output_0: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output_1: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> output_2: array<vec4<f32>>;
struct Uniforms {
  input_size: u32,
  total_segment_elements: u32,
  segment_sizes: vec3<u32>
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias input_value_t = vec4<f32>;
alias output_0_value_t = vec4<f32>;
alias output_1_value_t = vec4<f32>;
alias output_2_value_t = vec4<f32>;

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.input_size) { return; }
  let outer_index = global_idx / uniforms.total_segment_elements;
  let within_outer = global_idx % uniforms.total_segment_elements;
  var segment_start = 0u;
  {
    let segment_size = uniforms.segment_sizes[0];
    if (within_outer < segment_start + segment_size) {
      output_0[outer_index * segment_size + within_outer - segment_start]=input[global_idx];
      return;
    }
    segment_start += segment_size;
  }
  {
    let segment_size = uniforms.segment_sizes[1];
    if (within_outer < segment_start + segment_size) {
      output_1[outer_index * segment_size + within_outer - segment_start]=input[global_idx];
      return;
    }
    segment_start += segment_size;
  }
  {
    let segment_size = uniforms.segment_sizes[2];
    if (within_outer < segment_start + segment_size) {
      output_2[outer_index * segment_size + within_outer - segment_start]=input[global_idx];
      return;
    }
    segment_start += segment_size;
  }

}

=== WebGPU Shader code [Split, Key="Split[3|4]:1|1|3:2;:2;|2;|2;"] End ===


=== WebGPU Shader code [Transpose, Key="Transpose[0-1-3-2]:64,1,1:1:0;4:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
const tile_size: u32 = 32;
const tile_rows: u32 = 8;
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<f32>;
struct Uniforms {
  a_shape: vec4<u32>,
  a_stride: vec3<u32>,
  output_shape: vec4<u32>,
  output_stride: vec3<u32>,
  output_size: u32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias a_indices_t = vec4<u32>;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride[0] + indices[1] * uniforms.a_stride[1] + indices[2] * uniforms.a_stride[2] + indices[3];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->f32 {
  return a[i2o_a(indices_fnarg)];
}
alias output_value_t = f32;
alias output_indices_t = vec4<u32>;
fn o2i_output(offset : u32)->output_indices_t {
  var indices: output_indices_t;
  var current = offset;
  indices[0] = current / uniforms.output_stride[0];
  current = current % uniforms.output_stride[0];
  indices[1] = current / uniforms.output_stride[1];
  current = current % uniforms.output_stride[1];
  indices[2] = current / uniforms.output_stride[2];
  current = current % uniforms.output_stride[2];
  indices[3] = current;
  return indices;
}

fn perm(i: output_indices_t)->a_indices_t {
  var a: a_indices_t;
  a[0] = i[0];
  a[1] = i[1];
  a[3] = i[2];
  a[2] = i[3];
  return a;
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
  let indices = o2i_output(global_idx);
  let x_indices = perm(indices);
  output[global_idx]=get_a_by_indices(x_indices);
}

=== WebGPU Shader code [Transpose, Key="Transpose[0-1-3-2]:64,1,1:1:0;4:"] End ===


=== WebGPU Shader code [MatMul, Key="MatMul[ActivationKind: 0;|4-1-1|1|4|1|1|32]:8,32,1:1|1|1|1|1|1|1||:2;4|2;4:3:2"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> a: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> b: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  a_shape: vec4<u32>,
  a_stride: vec3<u32>,
  b_shape: vec4<u32>,
  b_stride: vec3<u32>,
  output_shape: vec3<u32>,
  output_stride: vec2<u32>,
  batch_dims_shape: vec2<u32>,
  batch_dims_stride: u32,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32,
  splits_per_batch: u32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias a_value_t = vec4<f32>;
alias a_indices_t = vec4<u32>;
alias a_element_t = f32;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride[0] + indices[1] * uniforms.a_stride[1] + indices[2] * uniforms.a_stride[2] + indices[3];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->a_value_t {
  return a[i2o_a(indices_fnarg)];
}
alias b_value_t = vec4<f32>;
alias b_indices_t = vec4<u32>;
fn i2o_b(indices : b_indices_t)->u32 {
  return indices[0] * uniforms.b_stride[0] + indices[1] * uniforms.b_stride[1] + indices[2] * uniforms.b_stride[2] + indices[3];
}
fn get_b_by_indices(indices_fnarg: b_indices_t)->b_value_t {
  return b[i2o_b(indices_fnarg)];
}
alias output_value_t = vec4<f32>;
alias output_indices_t = vec3<u32>;
alias output_element_t = f32;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride[0] + indices[1] * uniforms.output_stride[1] + indices[2];
}
fn set_output_by_indices(indices: output_indices_t, value: output_value_t) {
  output[i2o_output(indices)]=value;
}
alias batch_dims_indices_t = vec2<u32>;
fn o2i_batch_dims(offset : u32)->batch_dims_indices_t {
  var indices: batch_dims_indices_t;
  var current = offset;
  indices[0] = current / uniforms.batch_dims_stride;
  current = current % uniforms.batch_dims_stride;
  indices[1] = current;
  return indices;
}

fn mm_readA(batch: i32, row: i32, colIn: i32 , batch_indices: batch_dims_indices_t) -> vec4<output_element_t> {
     var value = vec4<output_element_t>(0);
    let col = colIn * 4;
    if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_inner)) {
        var a_indices: a_indices_t;
if (uniforms.a_shape[0] != 1) {
a_indices[0]= batch_indices [0];
} else {
a_indices[0]=0;
}
if (uniforms.a_shape[1] != 1) {
a_indices[1]= batch_indices [1];
} else {
a_indices[1]=0;
}

a_indices[2]=u32(row);
a_indices[3]=u32(colIn);
        value = get_a_by_indices(a_indices);
    }
    return value;
}

fn mm_readB(batch: i32, row: i32, colIn: i32 , batch_indices: batch_dims_indices_t) -> vec4<output_element_t> {
     var value = vec4<output_element_t>(0);
    let col = colIn * 4;
    if(row < i32(uniforms.dim_inner) && col < i32(uniforms.dim_b_outer)) {
        var b_indices: b_indices_t;
if (uniforms.b_shape[0] != 1) {
b_indices[0]= batch_indices [0];
} else {
b_indices[0]=0;
}
if (uniforms.b_shape[1] != 1) {
b_indices[1]= batch_indices [1];
} else {
b_indices[1]=0;
}

b_indices[2]=u32(row);
b_indices[3]=u32(colIn);
        value = get_b_by_indices(b_indices);
    }
    return value;
}

fn mm_write(batch: i32, row: i32, colIn: i32, valueIn: output_value_t) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let coords = vec3(u32(batch), u32(row), u32(colIn));
    
    set_output_by_indices(coords, value);
  }
}

var<workgroup> mm_Asub: array<array<vec4<a_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<a_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<a_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let batchIndices = o2i_batch_dims(u32(batch));
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol, batchIndices);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol, batchIndices);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [MatMul, Key="MatMul[ActivationKind: 0;|4-1-1|1|4|1|1|32]:8,32,1:1|1|1|1|1|1|1||:2;4|2;4:3:2"] End ===


=== WebGPU Shader code [Mul, Key="Mul[E01]:1|1:2;|2;:2;"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input_a: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> input_b: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  vec_size: u32,
  element_count: u32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias input_a_value_t = vec4<f32>;
alias input_a_element_t = f32;
alias input_b_value_t = vec4<f32>;
alias input_b_element_t = f32;
alias output_value_t = vec4<f32>;

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.vec_size) { return; }
let a = input_a[global_idx];
let b = input_b_value_t(input_b[0].x);
output[global_idx]=a * b;
}

=== WebGPU Shader code [Mul, Key="Mul[E01]:1|1:2;|2;:2;"] End ===


=== WebGPU Shader code [Softmax, Key="Softmax[4|64]:64,1,1:1:2;4:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> result: array<vec4<f32>>;
struct Uniforms {
  packedCols: i32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias x_value_t = vec4<f32>;
alias x_indices_t = vec4<u32>;
alias x_element_t = f32;
alias result_indices_t = vec4<u32>;

var<workgroup> row_max_shared : x_value_t;
var<workgroup> row_sum_shared : x_value_t;
var<workgroup> thread_max_scalar_shared : array<x_element_t, 64>;
var<workgroup> thread_sum_scalar_shared : array<x_element_t, 64>;
fn getValue(row: i32, col: i32, row_stride: i32) -> x_value_t {
  let index = row * row_stride + col;
  return x[index];
}
fn setValue(row: i32, col: i32, row_stride: i32, value: x_value_t) {
  let index = row * row_stride + col;
  result[index] = value;
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let gindex = i32(global_idx);
  let lindex = i32(local_idx);
  const wg = 64;
  let row = gindex / wg;
  let cols = uniforms.packedCols;
  let row_stride : i32 = uniforms.packedCols;
var thread_max = x_element_t(-3.4028234663852886e+38f);
  var thread_sum = x_element_t(0.0);
  for (var col = lindex; col < cols; col += wg) {
    let value = getValue(row, col, row_stride);
    let value_max = x_element_t(max(max(value.x, value.y), max(value.z, value.w)));
    let new_max = max(thread_max, value_max);
    let shifted_exp = exp(value - x_value_t(new_max));
    thread_sum = thread_sum * exp(thread_max - new_max) + x_element_t((shifted_exp.x + shifted_exp.y + shifted_exp.z + shifted_exp.w));
    thread_max = new_max;
  }
  thread_max_scalar_shared[lindex] = thread_max;
  thread_sum_scalar_shared[lindex] = thread_sum;
  workgroupBarrier();
  for (var curr_size = wg >> 1; curr_size > 0; curr_size = curr_size >> 1) {
    if (lindex < curr_size) {
      let rhs_max = thread_max_scalar_shared[lindex + curr_size];
      let rhs_sum = thread_sum_scalar_shared[lindex + curr_size];
      let lhs_max = thread_max_scalar_shared[lindex];
      let lhs_sum = thread_sum_scalar_shared[lindex];
      let merged_max = max(lhs_max, rhs_max);
      thread_sum_scalar_shared[lindex] = lhs_sum * exp(lhs_max - merged_max) + rhs_sum * exp(rhs_max - merged_max);
      thread_max_scalar_shared[lindex] = merged_max;
    }
    workgroupBarrier();
  }
  if (lindex == 0) {
    row_max_shared = x_value_t(thread_max_scalar_shared[0]);
    row_sum_shared = x_value_t(thread_sum_scalar_shared[0]);
  }
  workgroupBarrier();
  for (var col = lindex; col < cols; col += wg) {
    var value = exp(getValue(row, col, row_stride) - row_max_shared) / row_sum_shared;
    // max operation protects against NaN since all values should be >=0
    value = max(value, x_value_t(0.0));
    setValue(row, col, row_stride, value);
  }

}

=== WebGPU Shader code [Softmax, Key="Softmax[4|64]:64,1,1:1:2;4:2;4"] End ===


=== WebGPU Shader code [GroupedConv, Key="GroupedConv[ActivationKind: 0;|4|1|1]:1|2|2|2|1|1||:2;4|2;4|2;1:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> w: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> b: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  x_shape: vec4<u32>,
  x_stride: vec3<u32>,
  w_shape: vec4<u32>,
  w_stride: vec3<u32>,
  b_shape: u32,
  output_shape: vec4<u32>,
  output_stride: vec3<u32>,
  output_size: u32,
  dilations: vec2<u32>,
  strides: vec2<u32>,
  pads: vec2<u32>,
  output_channels_per_group: u32,
  components: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias x_value_t = vec4<f32>;
alias x_indices_t = vec4<u32>;
alias w_value_t = vec4<f32>;
alias w_indices_t = vec4<u32>;
alias b_value_t = vec4<f32>;
alias output_value_t = vec4<f32>;
alias output_indices_t = vec4<u32>;
alias output_element_t = f32;
fn o2i_output(offset : u32)->output_indices_t {
  var indices: output_indices_t;
  var current = offset;
  indices[0] = current / uniforms.output_stride[0];
  current = current % uniforms.output_stride[0];
  indices[1] = current / uniforms.output_stride[1];
  current = current % uniforms.output_stride[1];
  indices[2] = current / uniforms.output_stride[2];
  current = current % uniforms.output_stride[2];
  indices[3] = current;
  return indices;
}

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
let output_indices = o2i_output(global_idx);
let batch: u32 = output_indices[0];
let output_channel: u32 = output_indices[3];
let xRCCorner_x: u32 = output_indices[1];
let xRCCorner_y: u32 = output_indices[2];
let xRCCorner: vec2<i32> = vec2<i32>(i32(xRCCorner_x), i32(xRCCorner_y)) * vec2<i32>(i32(uniforms.strides[0]), i32(uniforms.strides[1])) - vec2<i32>(i32(uniforms.pads[0]), i32(uniforms.pads[1]));
var value: output_value_t = output_value_t(0);
let x_row_base = batch * uniforms.x_shape[1];
let w_plane = uniforms.w_shape[2] * uniforms.w_shape[3];
for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[0]; wHeight++) {
  let xHeight = xRCCorner.x + i32(wHeight * uniforms.dilations[0]);
  if (xHeight < 0 || xHeight >= i32(uniforms.x_shape[1])) {
    continue;
  }
  let x_base = ((x_row_base + u32(xHeight)) * uniforms.x_shape[2]) * uniforms.x_shape[3] + output_channel;
  let w_base = wHeight * uniforms.w_shape[1] * w_plane + output_channel;
  for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[1]; wWidth++) {
    let xWidth = xRCCorner.y + i32(wWidth * uniforms.dilations[1]);
    if (xWidth < 0 || xWidth >= i32(uniforms.x_shape[2])) {
      continue;
    }
    value += x[x_base + u32(xWidth) * uniforms.x_shape[3]] * w[w_base + wWidth * w_plane];
  }
}
value += b[output_channel];

output[global_idx]=value;
}

=== WebGPU Shader code [GroupedConv, Key="GroupedConv[ActivationKind: 0;|4|1|1]:1|2|2|2|1|1||:2;4|2;4|2;1:2;4"] End ===


=== WebGPU Shader code [ResizeNearest2D, Key="ResizeNearest2D[0|1|3]:8|4|1|1:0;4:4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<f32>;
struct Uniforms {
  input_shape: vec4<u32>,
  input_stride: vec3<u32>,
  output_shape: vec4<u32>,
  output_stride: vec3<u32>,
  roi: array<vec4<f32>, 2>,
  scales: vec4<f32>,
  output_size: u32,
  extrapolation_value: f32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias input_value_t = f32;
fn o2i_output(offset : u32)->vec4<u32> {
  var indices: vec4<u32>;
  var current = offset;
  indices[0] = current / uniforms.output_stride[0];
  current = current % uniforms.output_stride[0];
  indices[1] = current / uniforms.output_stride[1];
  current = current % uniforms.output_stride[1];
  indices[2] = current / uniforms.output_stride[2];
  current = current % uniforms.output_stride[2];
  indices[3] = current;
  return indices;
}

fn transform_coordinate(x_resized: u32, x_scale: f32, length_resized: u32, length_original: u32) -> f32 {
return select(f32(x_resized * length_original / length_resized) + f32(x_resized * length_original % length_resized) / f32(length_resized), f32(x_resized) / x_scale, x_scale < 1.0 || floor(x_scale) != x_scale);
}
fn calc_nearest_pixel(x_original: f32) -> i32 {
return i32(floor(x_original));
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
  let output_indices = o2i_output(global_idx);
  var input_index = u32(0);
  for(var axis = 0; axis < 4; axis++) {
    var output_coord = output_indices[axis];
    if (uniforms.scales[axis] != 1.0) {
      let input_coord = transform_coordinate(output_coord, uniforms.scales[axis], uniforms.output_shape[axis], uniforms.input_shape[axis]);
      var nearest_coord = calc_nearest_pixel(input_coord);
      if (nearest_coord >= i32(uniforms.input_shape[axis])) {
        output_coord = uniforms.input_shape[axis] - 1;
      } else if (nearest_coord < 0) {
        output_coord = 0;
      } else {
        output_coord = u32(nearest_coord);
      }    }
    input_index += select(output_coord * uniforms.input_stride[axis], output_coord, axis == 3);
  }
  output[global_idx]=input[input_index];;

}

=== WebGPU Shader code [ResizeNearest2D, Key="ResizeNearest2D[0|1|3]:8|4|1|1:0;4:4"] End ===


=== WebGPU Shader code [Concat, Key="Concat[2,1]:2|2|1:2;4|2;4:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input_0: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> input_1: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  input_0_shape: vec4<u32>,
  input_0_stride: vec3<u32>,
  input_1_shape: vec4<u32>,
  input_1_stride: vec3<u32>,
  output_shape: vec4<u32>,
  output_stride: vec3<u32>,
  offsets: vec2<u32>,
  sizes_in_concat_axis: vec2<u32>,
  output_size: u32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias input_0_indices_t = vec4<u32>;
fn o2i_input_0(offset : u32)->input_0_indices_t {
  var indices: input_0_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_0_stride[0];
  current = current % uniforms.input_0_stride[0];
  indices[1] = current / uniforms.input_0_stride[1];
  current = current % uniforms.input_0_stride[1];
  indices[2] = current / uniforms.input_0_stride[2];
  current = current % uniforms.input_0_stride[2];
  indices[3] = current;
  return indices;
}
alias input_1_indices_t = vec4<u32>;
fn o2i_input_1(offset : u32)->input_1_indices_t {
  var indices: input_1_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_1_stride[0];
  current = current % uniforms.input_1_stride[0];
  indices[1] = current / uniforms.input_1_stride[1];
  current = current % uniforms.input_1_stride[1];
  indices[2] = current / uniforms.input_1_stride[2];
  current = current % uniforms.input_1_stride[2];
  indices[3] = current;
  return indices;
}
alias output_indices_t = vec4<u32>;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride[0] + indices[1] * uniforms.output_stride[1] + indices[2] * uniforms.output_stride[2] + indices[3];
}
fn set_output_by_indices(indices: output_indices_t, value: vec4<f32>) {
  output[i2o_output(indices)]=value;
}

fn calculate_input_index(global_idx: u32) -> u32 {
  for (var i = 1u; i < 2; i = i + 1u) {
    if (global_idx < uniforms.offsets[i]) {
      return i - 1;
    }
  }
  return 1;
}
fn assign_output_data(global_idx: u32, input_index: u32) {
  if (input_index == 0u) {
     var output_indices = o2i_input_0(global_idx - uniforms.offsets[input_index]);
     output_indices[1] += uniforms.sizes_in_concat_axis[0];
     set_output_by_indices(output_indices, input_0[global_idx - uniforms.offsets[input_index]]);
  } else {
     var output_indices = o2i_input_1(global_idx - uniforms.offsets[input_index]);
     output_indices[1] += uniforms.sizes_in_concat_axis[1];
     set_output_by_indices(output_indices, input_1[global_idx - uniforms.offsets[input_index]]);
  }
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
let input_index = calculate_input_index(global_idx);
assign_output_data(global_idx, input_index);

}

=== WebGPU Shader code [Concat, Key="Concat[2,1]:2|2|1:2;4|2;4:"] End ===


=== WebGPU Shader code [Concat, Key="Concat[2,3]:2|2|1:2;4|2;4:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input_0: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> input_1: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  input_0_shape: vec4<u32>,
  input_0_stride: vec3<u32>,
  input_1_shape: vec4<u32>,
  input_1_stride: vec3<u32>,
  output_shape: vec4<u32>,
  output_stride: vec3<u32>,
  offsets: vec2<u32>,
  sizes_in_concat_axis: vec2<u32>,
  output_size: u32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias input_0_indices_t = vec4<u32>;
fn o2i_input_0(offset : u32)->input_0_indices_t {
  var indices: input_0_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_0_stride[0];
  current = current % uniforms.input_0_stride[0];
  indices[1] = current / uniforms.input_0_stride[1];
  current = current % uniforms.input_0_stride[1];
  indices[2] = current / uniforms.input_0_stride[2];
  current = current % uniforms.input_0_stride[2];
  indices[3] = current;
  return indices;
}
alias input_1_indices_t = vec4<u32>;
fn o2i_input_1(offset : u32)->input_1_indices_t {
  var indices: input_1_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_1_stride[0];
  current = current % uniforms.input_1_stride[0];
  indices[1] = current / uniforms.input_1_stride[1];
  current = current % uniforms.input_1_stride[1];
  indices[2] = current / uniforms.input_1_stride[2];
  current = current % uniforms.input_1_stride[2];
  indices[3] = current;
  return indices;
}
alias output_indices_t = vec4<u32>;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride[0] + indices[1] * uniforms.output_stride[1] + indices[2] * uniforms.output_stride[2] + indices[3];
}
fn set_output_by_indices(indices: output_indices_t, value: vec4<f32>) {
  output[i2o_output(indices)]=value;
}

fn calculate_input_index(global_idx: u32) -> u32 {
  for (var i = 1u; i < 2; i = i + 1u) {
    if (global_idx < uniforms.offsets[i]) {
      return i - 1;
    }
  }
  return 1;
}
fn assign_output_data(global_idx: u32, input_index: u32) {
  if (input_index == 0u) {
     var output_indices = o2i_input_0(global_idx - uniforms.offsets[input_index]);
     output_indices[3] += uniforms.sizes_in_concat_axis[0];
     set_output_by_indices(output_indices, input_0[global_idx - uniforms.offsets[input_index]]);
  } else {
     var output_indices = o2i_input_1(global_idx - uniforms.offsets[input_index]);
     output_indices[3] += uniforms.sizes_in_concat_axis[1];
     set_output_by_indices(output_indices, input_1[global_idx - uniforms.offsets[input_index]]);
  }
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
let input_index = calculate_input_index(global_idx);
assign_output_data(global_idx, input_index);

}

=== WebGPU Shader code [Concat, Key="Concat[2,3]:2|2|1:2;4|2;4:"] End ===


=== WebGPU Shader code [GroupedConv, Key="GroupedConv[ActivationKind: 7;QuickGeluUnitAlpha: 1;|4|1|1]:1|2|2|2|1|1||:2;4|2;4|2;1:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> w: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> b: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  x_shape: vec4<u32>,
  x_stride: vec3<u32>,
  w_shape: vec4<u32>,
  w_stride: vec3<u32>,
  b_shape: u32,
  output_shape: vec4<u32>,
  output_stride: vec3<u32>,
  output_size: u32,
  dilations: vec2<u32>,
  strides: vec2<u32>,
  pads: vec2<u32>,
  output_channels_per_group: u32,
  components: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias x_value_t = vec4<f32>;
alias x_indices_t = vec4<u32>;
alias w_value_t = vec4<f32>;
alias w_indices_t = vec4<u32>;
alias b_value_t = vec4<f32>;
alias output_value_t = vec4<f32>;
alias output_indices_t = vec4<u32>;
alias output_element_t = f32;
fn o2i_output(offset : u32)->output_indices_t {
  var indices: output_indices_t;
  var current = offset;
  indices[0] = current / uniforms.output_stride[0];
  current = current % uniforms.output_stride[0];
  indices[1] = current / uniforms.output_stride[1];
  current = current % uniforms.output_stride[1];
  indices[2] = current / uniforms.output_stride[2];
  current = current % uniforms.output_stride[2];
  indices[3] = current;
  return indices;
}

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
let output_indices = o2i_output(global_idx);
let batch: u32 = output_indices[0];
let output_channel: u32 = output_indices[3];
let xRCCorner_x: u32 = output_indices[1];
let xRCCorner_y: u32 = output_indices[2];
let xRCCorner: vec2<i32> = vec2<i32>(i32(xRCCorner_x), i32(xRCCorner_y)) * vec2<i32>(i32(uniforms.strides[0]), i32(uniforms.strides[1])) - vec2<i32>(i32(uniforms.pads[0]), i32(uniforms.pads[1]));
var value: output_value_t = output_value_t(0);
let x_row_base = batch * uniforms.x_shape[1];
let w_plane = uniforms.w_shape[2] * uniforms.w_shape[3];
for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[0]; wHeight++) {
  let xHeight = xRCCorner.x + i32(wHeight * uniforms.dilations[0]);
  if (xHeight < 0 || xHeight >= i32(uniforms.x_shape[1])) {
    continue;
  }
  let x_base = ((x_row_base + u32(xHeight)) * uniforms.x_shape[2]) * uniforms.x_shape[3] + output_channel;
  let w_base = wHeight * uniforms.w_shape[1] * w_plane + output_channel;
  for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[1]; wWidth++) {
    let xWidth = xRCCorner.y + i32(wWidth * uniforms.dilations[1]);
    if (xWidth < 0 || xWidth >= i32(uniforms.x_shape[2])) {
      continue;
    }
    value += x[x_base + u32(xWidth) * uniforms.x_shape[3]] * w[w_base + wWidth * w_plane];
  }
}
value += b[output_channel];
value = value * (output_value_t(output_element_t(1)) / (output_value_t(output_element_t(1)) + exp(-value)));
output[global_idx]=value;
}

=== WebGPU Shader code [GroupedConv, Key="GroupedConv[ActivationKind: 7;QuickGeluUnitAlpha: 1;|4|1|1]:1|2|2|2|1|1||:2;4|2;4|2;1:2;4"] End ===


=== WebGPU Shader code [Concat, Key="Concat[3,2]:3|3|1:2;3|2;3|2;3:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input_0: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> input_1: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> input_2: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  input_0_shape: vec3<u32>,
  input_0_stride: vec2<u32>,
  input_1_shape: vec3<u32>,
  input_1_stride: vec2<u32>,
  input_2_shape: vec3<u32>,
  input_2_stride: vec2<u32>,
  output_shape: vec3<u32>,
  output_stride: vec2<u32>,
  offsets: vec3<u32>,
  sizes_in_concat_axis: vec3<u32>,
  output_size: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias input_0_indices_t = vec3<u32>;
fn o2i_input_0(offset : u32)->input_0_indices_t {
  var indices: input_0_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_0_stride[0];
  current = current % uniforms.input_0_stride[0];
  indices[1] = current / uniforms.input_0_stride[1];
  current = current % uniforms.input_0_stride[1];
  indices[2] = current;
  return indices;
}
alias input_1_indices_t = vec3<u32>;
fn o2i_input_1(offset : u32)->input_1_indices_t {
  var indices: input_1_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_1_stride[0];
  current = current % uniforms.input_1_stride[0];
  indices[1] = current / uniforms.input_1_stride[1];
  current = current % uniforms.input_1_stride[1];
  indices[2] = current;
  return indices;
}
alias input_2_indices_t = vec3<u32>;
fn o2i_input_2(offset : u32)->input_2_indices_t {
  var indices: input_2_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_2_stride[0];
  current = current % uniforms.input_2_stride[0];
  indices[1] = current / uniforms.input_2_stride[1];
  current = current % uniforms.input_2_stride[1];
  indices[2] = current;
  return indices;
}
alias output_indices_t = vec3<u32>;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride[0] + indices[1] * uniforms.output_stride[1] + indices[2];
}
fn set_output_by_indices(indices: output_indices_t, value: vec4<f32>) {
  output[i2o_output(indices)]=value;
}

fn calculate_input_index(global_idx: u32) -> u32 {
  for (var i = 1u; i < 3; i = i + 1u) {
    if (global_idx < uniforms.offsets[i]) {
      return i - 1;
    }
  }
  return 2;
}
fn assign_output_data(global_idx: u32, input_index: u32) {
  if (input_index == 0u) {
     var output_indices = o2i_input_0(global_idx - uniforms.offsets[input_index]);
     output_indices[2] += uniforms.sizes_in_concat_axis[0];
     set_output_by_indices(output_indices, input_0[global_idx - uniforms.offsets[input_index]]);
  } else if (input_index == 1u) {
     var output_indices = o2i_input_1(global_idx - uniforms.offsets[input_index]);
     output_indices[2] += uniforms.sizes_in_concat_axis[1];
     set_output_by_indices(output_indices, input_1[global_idx - uniforms.offsets[input_index]]);
  } else {
     var output_indices = o2i_input_2(global_idx - uniforms.offsets[input_index]);
     output_indices[2] += uniforms.sizes_in_concat_axis[2];
     set_output_by_indices(output_indices, input_2[global_idx - uniforms.offsets[input_index]]);
  }
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
let input_index = calculate_input_index(global_idx);
assign_output_data(global_idx, input_index);

}

=== WebGPU Shader code [Concat, Key="Concat[3,2]:3|3|1:2;3|2;3|2;3:"] End ===


=== WebGPU Shader code [Sigmoid, Key="Sigmoid:1|:2;:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> y: array<vec4<f32>>;
struct Uniforms {
  vec_size: u32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;


@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.vec_size) { return; }
  let a = x[global_idx];
  y[global_idx]=1.0 / (1.0 + exp(-a));
}

=== WebGPU Shader code [Sigmoid, Key="Sigmoid:1|:2;:"] End ===


=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,0,0,1,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> w: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> result: array<vec4<f32>>;
struct Uniforms {
  x_shape: vec4<u32>,
  x_stride: vec3<u32>,
  w_shape: vec4<u32>,
  w_stride: vec3<u32>,
  result_shape: vec4<u32>,
  result_stride: vec3<u32>,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  pads: vec4<u32>,
  strides: vec2<u32>,
  dilations: vec2<u32>,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias x_value_t = vec4<f32>;
alias x_indices_t = vec4<u32>;
alias x_element_t = f32;
alias w_value_t = vec4<f32>;
alias w_indices_t = vec4<u32>;
alias bias_value_t = vec4<f32>;
alias bias_indices_t = u32;
alias bias_element_t = f32;
alias result_indices_t = vec4<u32>;

fn getIndexFromCoords3D(coords : vec3<i32>, shape : vec3<i32>) -> i32 {
  return dot(coords, vec3<i32>(shape.y * shape.z, shape.z, 1));
}
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(i32(uniforms.result_stride.x), i32(uniforms.result_stride.y), i32(uniforms.result_stride.z), 1));
}
fn setOutputAtIndex(flatIndex : i32, value : vec4<x_element_t>) {
  result[u32(flatIndex)]=vec4<x_element_t>(value);
}
fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : vec4<x_element_t>){
  let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
  setOutputAtIndex(flatIndex, value);
}
fn getBiasByOutputCoords(coords : vec4<i32>) -> bias_value_t {
  return bias[u32(coords.w)];
}fn mm_readA(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_inner)) {
  let inChannels = i32(uniforms.w_shape[2]);
let outWidth = i32(uniforms.result_shape[2]);
let outRow = row / outWidth;
 let outCol = row % outWidth;
let WRow = col / (i32(uniforms.w_shape[1]) * inChannels);
let WCol = col / inChannels % i32(uniforms.w_shape[1]);
let xRow = outRow * i32(uniforms.strides[0]) + i32(uniforms.dilations[0]) * WRow - i32(uniforms.pads[0]);
let xCol = outCol * i32(uniforms.strides[1]) + i32(uniforms.dilations[1]) * WCol - i32(uniforms.pads[1]);
let xCh = col % inChannels;
var resData = vec4<x_element_t>(0.0);
 // The bounds checking is always needed since we use it to pad zero for
// the " same " padding type.
if (xRow >= 0 && xRow < i32(uniforms.x_shape[1]) && xCol >= 0 && xCol < i32(uniforms.x_shape[2])) {
  let coord = vec4<i32>(batch, xRow, xCol, xCh / 4);
  let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
  resData = x[xIndex];
 }
return resData;
}
return vec4<x_element_t>(0.0);
}

fn mm_readB(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_inner) && col < i32(uniforms.dim_b_outer)) {
  return w[row * i32(uniforms.w_shape[3])  + colIn];

}
return vec4<x_element_t>(0.0);
}

fn mm_write(batch : i32, row : i32, colIn : i32, valueIn : vec4<x_element_t>) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let outWidth =  i32(uniforms.result_shape[2]) ;
    let coords = vec4<i32>(batch, row / outWidth, row % outWidth, col / 4);
    value = value + getBiasByOutputCoords(coords);
    value = value * (vec4<x_element_t>(x_element_t(1)) / (vec4<x_element_t>(x_element_t(1)) + exp(-value)));
    setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
  }
}
var<workgroup> mm_Asub: array<array<vec4<x_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<x_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<x_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,0,0,1,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] End ===


=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,0,0,0,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 8;
const workgroup_size_y: u32 = 32;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> w: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> result: array<vec4<f32>>;
struct Uniforms {
  x_shape: vec4<u32>,
  x_stride: vec3<u32>,
  w_shape: vec4<u32>,
  w_stride: vec3<u32>,
  result_shape: vec4<u32>,
  result_stride: vec3<u32>,
  dim_a_outer: u32,
  dim_b_outer: u32,
  dim_inner: u32,
  pads: vec4<u32>,
  strides: vec2<u32>,
  dilations: vec2<u32>,
  logical_dispatch_x: u32,
  logical_dispatch_y: u32,
  logical_dispatch_z: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias x_value_t = vec4<f32>;
alias x_indices_t = vec4<u32>;
alias x_element_t = f32;
alias w_value_t = vec4<f32>;
alias w_indices_t = vec4<u32>;
alias bias_value_t = vec4<f32>;
alias bias_indices_t = u32;
alias bias_element_t = f32;
alias result_indices_t = vec4<u32>;

fn getIndexFromCoords3D(coords : vec3<i32>, shape : vec3<i32>) -> i32 {
  return dot(coords, vec3<i32>(shape.y * shape.z, shape.z, 1));
}
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(i32(uniforms.result_stride.x), i32(uniforms.result_stride.y), i32(uniforms.result_stride.z), 1));
}
fn setOutputAtIndex(flatIndex : i32, value : vec4<x_element_t>) {
  result[u32(flatIndex)]=vec4<x_element_t>(value);
}
fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : vec4<x_element_t>){
  let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
  setOutputAtIndex(flatIndex, value);
}
fn getBiasByOutputCoords(coords : vec4<i32>) -> bias_value_t {
  return bias[u32(coords.w)];
}fn mm_readA(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_inner)) {
  let inChannels = i32(uniforms.w_shape[2]);
let outWidth = i32(uniforms.result_shape[2]);
let outRow = row / outWidth;
 let outCol = row % outWidth;
let WRow = col / (i32(uniforms.w_shape[1]) * inChannels);
let WCol = col / inChannels % i32(uniforms.w_shape[1]);
let xRow = outRow * i32(uniforms.strides[0]) + i32(uniforms.dilations[0]) * WRow - i32(uniforms.pads[0]);
let xCol = outCol * i32(uniforms.strides[1]) + i32(uniforms.dilations[1]) * WCol - i32(uniforms.pads[1]);
let xCh = col % inChannels;
var resData = vec4<x_element_t>(0.0);
 // The bounds checking is always needed since we use it to pad zero for
// the " same " padding type.
if (xRow >= 0 && xRow < i32(uniforms.x_shape[1]) && xCol >= 0 && xCol < i32(uniforms.x_shape[2])) {
  let coord = vec4<i32>(batch, xRow, xCol, xCh / 4);
  let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
  resData = x[xIndex];
 }
return resData;
}
return vec4<x_element_t>(0.0);
}

fn mm_readB(batch : i32, row : i32, colIn : i32) -> vec4<x_element_t> {
let col = colIn * 4;
if(row < i32(uniforms.dim_inner) && col < i32(uniforms.dim_b_outer)) {
  return w[row * i32(uniforms.w_shape[3])  + colIn];

}
return vec4<x_element_t>(0.0);
}

fn mm_write(batch : i32, row : i32, colIn : i32, valueIn : vec4<x_element_t>) {
  let col = colIn * 4;
  if(row < i32(uniforms.dim_a_outer) && col < i32(uniforms.dim_b_outer)) {
    var value = valueIn;
    let outWidth =  i32(uniforms.result_shape[2]) ;
    let coords = vec4<i32>(batch, row / outWidth, row % outWidth, col / 4);
    value = value + getBiasByOutputCoords(coords);
    value = value * (vec4<x_element_t>(x_element_t(1)) / (vec4<x_element_t>(x_element_t(1)) + exp(-value)));
    setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
  }
}
var<workgroup> mm_Asub: array<array<vec4<x_element_t>, 8>, 32>;
var<workgroup> mm_Bsub: array<array<vec4<x_element_t>, 8>, 32>;
const rowPerThread = 1;
const colPerThread = 4;
const innerElementSize = 4;
const tileInner = 32;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let logical_workgroup_id_z = workgroup_idx / (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y);
  let logical_workgroup_id_y = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) / uniforms.logical_dispatch_x;
  let logical_workgroup_id_x = (workgroup_idx % (uniforms.logical_dispatch_x * uniforms.logical_dispatch_y)) % uniforms.logical_dispatch_x;
  let logical_workgroup_id = vec3u(logical_workgroup_id_x, logical_workgroup_id_y, logical_workgroup_id_z);
  const workgroupSize = vec3u(workgroup_size_x, workgroup_size_y, workgroup_size_z);
  let logical_global_id = logical_workgroup_id * workgroupSize + local_id;
  let localRow = i32(local_id.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(local_id.x);
  let globalRow = i32(logical_global_id.y) * rowPerThread;
  let globalCol = i32(logical_global_id.x);
  let globalRowStart = i32(logical_workgroup_id.y) * 32;
  let globalColStart = i32(logical_workgroup_id.x) * 32;
  var acc: array<vec4<x_element_t>, rowPerThread>;
  let num_tiles = (uniforms.dim_inner - 1) / tileInner + 1;
  var kStart = 0;
  let batch = i32(logical_global_id.z);
  let tileRowB = localRow * 1;
  for (var t = 0; t < i32(num_tiles); t = t + 1) {
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let inputRow = tileRow + innerRow;
      let inputCol = tileCol;
      mm_Asub[inputRow][inputCol] = mm_readA(batch, globalRow + innerRow, kStart / innerElementSize + inputCol);
    }
    for (var innerRow = 0; innerRow < 1; innerRow = innerRow + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol;
     mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol);
    }
    kStart = kStart + tileInner;
    workgroupBarrier();
    for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
      let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
      let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
      let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
      let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];
      for (var i = 0; i < rowPerThread; i = i + 1) {
        let ACached = mm_Asub[tileRow + i][k];
        acc[i] = BCached0 * ACached.x + acc[i];
        acc[i] = BCached1 * ACached.y + acc[i];
        acc[i] = BCached2 * ACached.z + acc[i];
        acc[i] = BCached3 * ACached.w + acc[i];
      }
    }
    workgroupBarrier();
  }
  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
    mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }

}

=== WebGPU Shader code [Conv2dMM, Key="Conv2dMM[ActivationKind: 7;QuickGeluUnitAlpha: 1;|1|32|4,1,0,0,0,32,32,32,4,]:8,32,1:1|1|1|4|2|2|1|1|1||:2;4|2;4|2;1:2;4"] End ===


=== WebGPU Shader code [Slice, Key="Slice:1|3|3|3:2;3:2;3"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  input_shape: vec3<u32>,
  input_stride: vec2<u32>,
  output_shape: vec3<u32>,
  output_stride: vec2<u32>,
  output_size: u32,
  starts: vec3<u32>,
  steps: vec3<u32>,
  signs: vec3<i32>
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias input_indices_t = vec3<u32>;
fn i2o_input(indices : input_indices_t)->u32 {
  return indices[0] * uniforms.input_stride[0] + indices[1] * uniforms.input_stride[1] + indices[2];
}
fn get_input_by_indices(indices_fnarg: input_indices_t)->vec4<f32> {
  return input[i2o_input(indices_fnarg)];
}
alias output_indices_t = vec3<u32>;
fn o2i_output(offset : u32)->output_indices_t {
  var indices: output_indices_t;
  var current = offset;
  indices[0] = current / uniforms.output_stride[0];
  current = current % uniforms.output_stride[0];
  indices[1] = current / uniforms.output_stride[1];
  current = current % uniforms.output_stride[1];
  indices[2] = current;
  return indices;
}

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
let output_indices = o2i_output(global_idx);
var input_indices: input_indices_t;
var carry = 0u;
let input_shape_2 = uniforms.input_shape[2];
let steps_2 = uniforms.steps[2];
let starts_2 = uniforms.starts[2];
var output_index_2 = output_indices[2];
var input_index_2 = output_index_2 * steps_2 + starts_2 + carry;
carry = input_index_2 / input_shape_2;
input_index_2 = input_index_2 % input_shape_2;
if (uniforms.signs[2] < 0) {
  input_index_2 = input_shape_2 - input_index_2 - 1u + starts_2;
}
input_indices[2]=input_index_2;;
let input_shape_1 = uniforms.input_shape[1];
let steps_1 = uniforms.steps[1];
let starts_1 = uniforms.starts[1];
var output_index_1 = output_indices[1];
var input_index_1 = output_index_1 * steps_1 + starts_1 + carry;
carry = input_index_1 / input_shape_1;
input_index_1 = input_index_1 % input_shape_1;
if (uniforms.signs[1] < 0) {
  input_index_1 = input_shape_1 - input_index_1 - 1u + starts_1;
}
input_indices[1]=input_index_1;;
let input_shape_0 = uniforms.input_shape[0];
let steps_0 = uniforms.steps[0];
let starts_0 = uniforms.starts[0];
var output_index_0 = output_indices[0];
var input_index_0 = output_index_0 * steps_0 + starts_0 + carry;
carry = input_index_0 / input_shape_0;
input_index_0 = input_index_0 % input_shape_0;
if (uniforms.signs[0] < 0) {
  input_index_0 = input_shape_0 - input_index_0 - 1u + starts_0;
}
input_indices[0]=input_index_0;;
output[global_idx]=get_input_by_indices(input_indices);
}

=== WebGPU Shader code [Slice, Key="Slice:1|3|3|3:2;3:2;3"] End ===


=== WebGPU Shader code [Sub, Key="Sub[E00]:1|1:2;|2;:2;"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input_a: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> input_b: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  vec_size: u32,
  element_count: u32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias input_a_value_t = vec4<f32>;
alias input_a_element_t = f32;
alias input_b_value_t = vec4<f32>;
alias input_b_element_t = f32;
alias output_value_t = vec4<f32>;

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.vec_size) { return; }
let a = input_a[global_idx];
let b = input_b[global_idx];
output[global_idx]=a - b;
}

=== WebGPU Shader code [Sub, Key="Sub[E00]:1|1:2;|2;:2;"] End ===


=== WebGPU Shader code [Concat, Key="Concat[2,1]:2|2|1:2;3|2;3:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input_0: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> input_1: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  input_0_shape: vec3<u32>,
  input_0_stride: vec2<u32>,
  input_1_shape: vec3<u32>,
  input_1_stride: vec2<u32>,
  output_shape: vec3<u32>,
  output_stride: vec2<u32>,
  offsets: vec2<u32>,
  sizes_in_concat_axis: vec2<u32>,
  output_size: u32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias input_0_indices_t = vec3<u32>;
fn o2i_input_0(offset : u32)->input_0_indices_t {
  var indices: input_0_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_0_stride[0];
  current = current % uniforms.input_0_stride[0];
  indices[1] = current / uniforms.input_0_stride[1];
  current = current % uniforms.input_0_stride[1];
  indices[2] = current;
  return indices;
}
alias input_1_indices_t = vec3<u32>;
fn o2i_input_1(offset : u32)->input_1_indices_t {
  var indices: input_1_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_1_stride[0];
  current = current % uniforms.input_1_stride[0];
  indices[1] = current / uniforms.input_1_stride[1];
  current = current % uniforms.input_1_stride[1];
  indices[2] = current;
  return indices;
}
alias output_indices_t = vec3<u32>;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride[0] + indices[1] * uniforms.output_stride[1] + indices[2];
}
fn set_output_by_indices(indices: output_indices_t, value: vec4<f32>) {
  output[i2o_output(indices)]=value;
}

fn calculate_input_index(global_idx: u32) -> u32 {
  for (var i = 1u; i < 2; i = i + 1u) {
    if (global_idx < uniforms.offsets[i]) {
      return i - 1;
    }
  }
  return 1;
}
fn assign_output_data(global_idx: u32, input_index: u32) {
  if (input_index == 0u) {
     var output_indices = o2i_input_0(global_idx - uniforms.offsets[input_index]);
     output_indices[1] += uniforms.sizes_in_concat_axis[0];
     set_output_by_indices(output_indices, input_0[global_idx - uniforms.offsets[input_index]]);
  } else {
     var output_indices = o2i_input_1(global_idx - uniforms.offsets[input_index]);
     output_indices[1] += uniforms.sizes_in_concat_axis[1];
     set_output_by_indices(output_indices, input_1[global_idx - uniforms.offsets[input_index]]);
  }
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
let input_index = calculate_input_index(global_idx);
assign_output_data(global_idx, input_index);

}

=== WebGPU Shader code [Concat, Key="Concat[2,1]:2|2|1:2;3|2;3:"] End ===


=== WebGPU Shader code [Mul, Key="Mul[V]:1|1:2;|2;:2;:3|3|2"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input_a: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> input_b: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> output: array<vec4<f32>>;
struct Uniforms {
  bcast_indices_shape: vec3<u32>,
  bcast_indices_stride: vec2<u32>,
  a_indices_shape: vec3<u32>,
  a_indices_stride: vec2<u32>,
  b_indices_shape: vec2<u32>,
  b_indices_stride: u32,
  vec_size: u32,
  element_count: u32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias input_a_value_t = vec4<f32>;
alias input_a_element_t = f32;
alias input_b_value_t = vec4<f32>;
alias input_b_element_t = f32;
alias output_value_t = vec4<f32>;
fn o2i_bcast_indices(offset : u32)->vec3<u32> {
  var indices: vec3<u32>;
  var current = offset;
  indices[0] = current / uniforms.bcast_indices_stride[0];
  current = current % uniforms.bcast_indices_stride[0];
  indices[1] = current / uniforms.bcast_indices_stride[1];
  current = current % uniforms.bcast_indices_stride[1];
  indices[2] = current;
  return indices;
}
fn bcast_indices_bi2o_a_indices(indices : vec3<u32>)->u32 {
  return uniforms.a_indices_stride[0] * (indices[0] % uniforms.a_indices_shape[0]) + uniforms.a_indices_stride[1] * (indices[1] % uniforms.a_indices_shape[1]) + indices[2] % uniforms.a_indices_shape[2];
}
fn bcast_indices_bi2o_b_indices(indices : vec3<u32>)->u32 {
  return uniforms.b_indices_stride * (indices[1] % uniforms.b_indices_shape[0]) + indices[2] % uniforms.b_indices_shape[1];
}

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.vec_size) { return; }
let outputIndices = o2i_bcast_indices(global_idx * 4);
let offset_a = bcast_indices_bi2o_a_indices(outputIndices);
let offset_b = bcast_indices_bi2o_b_indices(outputIndices);
let a = input_a[offset_a / 4];
let b = input_b[offset_b / 4];
output[global_idx]=a * b;
}

=== WebGPU Shader code [Mul, Key="Mul[V]:1|1:2;|2;:2;:3|3|2"] End ===


=== WebGPU Shader code [Transpose, Key="Transpose[0-2-1]:1:0;3:0;3"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
const tile_size: u32 = 32;
const tile_rows: u32 = 8;
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<f32>;
struct Uniforms {
  a_shape: vec3<u32>,
  a_stride: vec2<u32>,
  output_shape: vec3<u32>,
  output_stride: vec2<u32>,
  output_size: u32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias a_indices_t = vec3<u32>;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride[0] + indices[1] * uniforms.a_stride[1] + indices[2];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->f32 {
  return a[i2o_a(indices_fnarg)];
}
alias output_value_t = f32;
alias output_indices_t = vec3<u32>;
fn o2i_output(offset : u32)->output_indices_t {
  var indices: output_indices_t;
  var current = offset;
  indices[0] = current / uniforms.output_stride[0];
  current = current % uniforms.output_stride[0];
  indices[1] = current / uniforms.output_stride[1];
  current = current % uniforms.output_stride[1];
  indices[2] = current;
  return indices;
}

fn perm(i: output_indices_t)->a_indices_t {
  var a: a_indices_t;
  a[0] = i[0];
  a[2] = i[1];
  a[1] = i[2];
  return a;
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
  let indices = o2i_output(global_idx);
  let x_indices = perm(indices);
  output[global_idx]=get_a_by_indices(x_indices);
}

=== WebGPU Shader code [Transpose, Key="Transpose[0-2-1]:1:0;3:0;3"] End ===


=== WebGPU Shader code [ReduceMax, Key="ReduceMax[0|0|0|64|1]:64,1,1:1:0;3:0;2"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> _A: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<f32>;
struct Uniforms {
  reduceSize: u32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias _A_value_t = f32;
alias _A_indices_t = vec3<u32>;
alias _A_element_t = f32;
alias output_value_t = f32;
alias output_indices_t = vec2<u32>;
alias output_element_t = f32;

var<workgroup> aBestValues : array<output_value_t, 64>;

fn DIV_CEIL(a : u32, b : u32) -> u32 {
  return ((a - 1u) / b + 1u);
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
let outputIndex = global_idx / 64;
let offset = outputIndex * uniforms.reduceSize;
var bestValue = output_value_t(_A[offset]);
let length = uniforms.reduceSize;
for (var k = local_idx; k < length; k += 64) {
  let candidate = output_value_t(_A[offset + k]);
  bestValue = select(bestValue, candidate, candidate > bestValue);
}
aBestValues[local_idx] = bestValue;
workgroupBarrier();
var reduceSize = min(length, 64);
for (var currentSize = reduceSize / 2; reduceSize > 1; currentSize = reduceSize / 2) {
  let interval = DIV_CEIL(reduceSize, 2u);
  if (local_idx < currentSize) {
    let candidate = aBestValues[local_idx + interval];
    bestValue = select(bestValue, candidate, candidate > bestValue);
    aBestValues[local_idx] = bestValue;
  }
  reduceSize = interval;
  workgroupBarrier();
}
if (local_idx == 0) {
  let outputValue = output_value_t(bestValue);
  output[outputIndex]=outputValue;;
}

}

=== WebGPU Shader code [ReduceMax, Key="ReduceMax[0|0|0|64|1]:64,1,1:1:0;3:0;2"] End ===


=== WebGPU Shader code [TopKInit, Key="TopKInit[largest|fp32]:256,1,1:1|1:0;2:0;1|6;1"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 256;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> x: array<f32>;
@group(0) @binding(1) var<storage, read_write> vals_buf: array<f32>;
@group(0) @binding(2) var<storage, read_write> idxs_buf: array<i32>;
struct Uniforms {
  cols: i32,
  padded_cols: i32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

alias x_value_t = f32;
alias x_element_t = f32;
alias vals_buf_value_t = f32;

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
let row = workgroup_idx;
let cols = uniforms.cols;
let pcols = uniforms.padded_cols;
for (var idx = local_idx; idx < u32(pcols); idx += 256u) {
  let out_idx = u32(i32(row) * pcols + i32(idx));
  if (i32(idx) < cols) {
    vals_buf[out_idx] = x_element_t(x[u32(i32(row) * cols + i32(idx))]);
    idxs_buf[out_idx] = i32(idx);
  } else {
    vals_buf[out_idx] = x_element_t(-3.4028234663852886e+38f);
    idxs_buf[out_idx] = -1;
  }
}

}

=== WebGPU Shader code [TopKInit, Key="TopKInit[largest|fp32]:256,1,1:1|1:0;2:0;1|6;1"] End ===


=== WebGPU Shader code [TopKSortStep, Key="TopKSortStep[largest]:256,1,1:1|1|1|1::0;1|6;1"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 256;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read_write> vals_buf: array<f32>;
@group(0) @binding(1) var<storage, read_write> idxs_buf: array<i32>;
struct Uniforms {
  block_size: u32,
  gap: u32,
  padded_cols: u32,
  total_threads: u32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias vals_buf_value_t = f32;
alias vals_buf_element_t = f32;

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
if (global_idx >= uniforms.total_threads) { return; }
let pcols = uniforms.padded_cols;
let threads_per_row = pcols / 2u;
let row = global_idx / threads_per_row;
let tid = global_idx % threads_per_row;
let gap = uniforms.gap;
let block = tid / gap;
let pos = tid % gap;
let base = row * pcols;
let i = base + block * 2u * gap + pos;
let j = i + gap;
let asc = (((i - base) / uniforms.block_size) & 1u) != 0u;
let va = vals_buf[i];
let vb = vals_buf[j];
let ia = idxs_buf[i];
let ib = idxs_buf[j];
let do_swap = select(va < vb || (va == vb && ia > ib), va > vb || (va == vb && ia < ib), asc);
if (do_swap) {
  vals_buf[i] = vb;
  vals_buf[j] = va;
  idxs_buf[i] = ib;
  idxs_buf[j] = ia;
}

}

=== WebGPU Shader code [TopKSortStep, Key="TopKSortStep[largest]:256,1,1:1|1|1|1::0;1|6;1"] End ===


=== WebGPU Shader code [TopKOutput, Key="TopKOutput[output]:256,1,1:1|1:0;1|6;1:0;2|12;2"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 256;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> vals_buf: array<f32>;
@group(0) @binding(1) var<storage, read> idxs_buf: array<i32>;
@group(0) @binding(2) var<storage, read_write> values: array<f32>;
@group(0) @binding(3) var<storage, read_write> indices: array<vec2<u32>>;
struct Uniforms {
  padded_cols: i32,
  k: i32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias vals_buf_value_t = f32;
alias values_value_t = f32;
alias indices_value_t = i32;

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
let row = workgroup_idx;
let pcols = uniforms.padded_cols;
let k = uniforms.k;
for (var idx = local_idx; idx < u32(k); idx += 256u) {
  let in_idx = u32(i32(row) * pcols + i32(idx));
  let out_idx = u32(i32(row) * k + i32(idx));
  values[out_idx] = vals_buf[in_idx];
  indices[out_idx]=vec2<u32>(u32(idxs_buf[in_idx]), select(0u, 0xFFFFFFFFu, i32(idxs_buf[in_idx]) < 0));
}

}

=== WebGPU Shader code [TopKOutput, Key="TopKOutput[output]:256,1,1:1|1:0;1|6;1:0;2|12;2"] End ===


=== WebGPU Shader code [Transpose, Key="Transpose[0-2-1]:32,8,1:1:0;2:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 32;
const workgroup_size_y: u32 = 8;
const workgroup_size_z: u32 = 1;
const tile_size: u32 = 32;
const tile_rows: u32 = 8;
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read_write> output: array<f32>;
struct Uniforms {
  a_shape: vec2<u32>,
  a_stride: u32,
  output_shape: vec2<u32>,
  output_stride: u32,
  output_size: u32
};
@group(0) @binding(2) var<uniform> uniforms: Uniforms;

alias a_indices_t = vec2<u32>;
fn i2o_a(indices : a_indices_t)->u32 {
  return indices[0] * uniforms.a_stride + indices[1];
}
fn get_a_by_indices(indices_fnarg: a_indices_t)->f32 {
  return a[i2o_a(indices_fnarg)];
}
alias output_value_t = f32;
alias output_indices_t = vec2<u32>;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride + indices[1];
}
fn set_output_by_indices(indices: output_indices_t, value: output_value_t) {
  output[i2o_output(indices)]=value;
}

var<workgroup> tile : array<array<output_value_t, tile_size + 1>, tile_size>;
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  let stride = (uniforms.output_shape[1] - 1) / tile_size + 1;
  let workgroup_id_x = workgroup_idx % stride;
  let workgroup_id_y = workgroup_idx / stride;
  let input_col = workgroup_id_y * tile_size + local_id.x;
  for (var j: u32 = 0u; j < tile_size; j += tile_rows) {
    let input_row = workgroup_id_x * tile_size + local_id.y + j;
    if (input_row < uniforms.a_shape[0] && input_col < uniforms.a_shape[1]) {
      tile[local_id.y + j][local_id.x] = get_a_by_indices(a_indices_t(input_row, input_col));
    }
  }
  workgroupBarrier();
  let output_col = workgroup_id_x * tile_size + local_id.x;
  for (var j: u32 = 0u; j < tile_size; j += tile_rows) {
    let output_row = workgroup_id_y * tile_size + local_id.y + j;
    if (output_row < uniforms.output_shape[0] && output_col < uniforms.output_shape[1]) {
      set_output_by_indices(output_indices_t(output_row, output_col), tile[local_id.x][local_id.y + j]);
    }
  }
}

=== WebGPU Shader code [Transpose, Key="Transpose[0-2-1]:32,8,1:1:0;2:"] End ===


=== WebGPU Shader code [GatherElements, Key="GatherElements:1|1|1:0;3|12;3:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read> indices: array<vec2<u32>>;
@group(0) @binding(2) var<storage, read_write> output: array<f32>;
struct Uniforms {
  input_shape: vec3<u32>,
  input_stride: vec2<u32>,
  output_shape: vec3<u32>,
  output_stride: vec2<u32>,
  output_size: u32,
  axis_dim_limit: i32,
  axis: i32
};
@group(0) @binding(3) var<uniform> uniforms: Uniforms;

fn i2o_input(indices : vec3<u32>)->u32 {
  return indices[0] * uniforms.input_stride[0] + indices[1] * uniforms.input_stride[1] + indices[2];
}
fn get_input_by_indices(indices_fnarg: vec3<u32>)->f32 {
  return input[i2o_input(indices_fnarg)];
}
fn o2i_output(offset : u32)->vec3<u32> {
  var indices: vec3<u32>;
  var current = offset;
  indices[0] = current / uniforms.output_stride[0];
  current = current % uniforms.output_stride[0];
  indices[1] = current / uniforms.output_stride[1];
  current = current % uniforms.output_stride[1];
  indices[2] = current;
  return indices;
}

@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
let output_indices = o2i_output(global_idx);
var idx = i32(indices[global_idx].x);
if (idx < 0) {
  idx = idx + uniforms.axis_dim_limit;
}
var input_indices = output_indices;
input_indices[uniforms.axis]=u32(idx);;
let value = get_input_by_indices(input_indices);
output[global_idx]=value;;

}

=== WebGPU Shader code [GatherElements, Key="GatherElements:1|1|1:0;3|12;3:"] End ===


=== WebGPU Shader code [Concat, Key="Concat[3,2]:3|3|1:0;3|0;3|0;3:"] Start ===

enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic (off, chromium.subgroup_matrix_uniformity);
const workgroup_size_x: u32 = 64;
const workgroup_size_y: u32 = 1;
const workgroup_size_z: u32 = 1;
@group(0) @binding(0) var<storage, read> input_0: array<f32>;
@group(0) @binding(1) var<storage, read> input_1: array<f32>;
@group(0) @binding(2) var<storage, read> input_2: array<f32>;
@group(0) @binding(3) var<storage, read_write> output: array<f32>;
struct Uniforms {
  input_0_shape: vec3<u32>,
  input_0_stride: vec2<u32>,
  input_1_shape: vec3<u32>,
  input_1_stride: vec2<u32>,
  input_2_shape: vec3<u32>,
  input_2_stride: vec2<u32>,
  output_shape: vec3<u32>,
  output_stride: vec2<u32>,
  offsets: vec3<u32>,
  sizes_in_concat_axis: vec3<u32>,
  output_size: u32
};
@group(0) @binding(4) var<uniform> uniforms: Uniforms;

alias input_0_indices_t = vec3<u32>;
fn o2i_input_0(offset : u32)->input_0_indices_t {
  var indices: input_0_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_0_stride[0];
  current = current % uniforms.input_0_stride[0];
  indices[1] = current / uniforms.input_0_stride[1];
  current = current % uniforms.input_0_stride[1];
  indices[2] = current;
  return indices;
}
alias input_1_indices_t = vec3<u32>;
fn o2i_input_1(offset : u32)->input_1_indices_t {
  var indices: input_1_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_1_stride[0];
  current = current % uniforms.input_1_stride[0];
  indices[1] = current / uniforms.input_1_stride[1];
  current = current % uniforms.input_1_stride[1];
  indices[2] = current;
  return indices;
}
alias input_2_indices_t = vec3<u32>;
fn o2i_input_2(offset : u32)->input_2_indices_t {
  var indices: input_2_indices_t;
  var current = offset;
  indices[0] = current / uniforms.input_2_stride[0];
  current = current % uniforms.input_2_stride[0];
  indices[1] = current / uniforms.input_2_stride[1];
  current = current % uniforms.input_2_stride[1];
  indices[2] = current;
  return indices;
}
alias output_indices_t = vec3<u32>;
fn i2o_output(indices : output_indices_t)->u32 {
  return indices[0] * uniforms.output_stride[0] + indices[1] * uniforms.output_stride[1] + indices[2];
}
fn set_output_by_indices(indices: output_indices_t, value: f32) {
  output[i2o_output(indices)]=value;
}

fn calculate_input_index(global_idx: u32) -> u32 {
  for (var i = 1u; i < 3; i = i + 1u) {
    if (global_idx < uniforms.offsets[i]) {
      return i - 1;
    }
  }
  return 2;
}
fn assign_output_data(global_idx: u32, input_index: u32) {
  if (input_index == 0u) {
     var output_indices = o2i_input_0(global_idx - uniforms.offsets[input_index]);
     output_indices[2] += uniforms.sizes_in_concat_axis[0];
     set_output_by_indices(output_indices, input_0[global_idx - uniforms.offsets[input_index]]);
  } else if (input_index == 1u) {
     var output_indices = o2i_input_1(global_idx - uniforms.offsets[input_index]);
     output_indices[2] += uniforms.sizes_in_concat_axis[1];
     set_output_by_indices(output_indices, input_1[global_idx - uniforms.offsets[input_index]]);
  } else {
     var output_indices = o2i_input_2(global_idx - uniforms.offsets[input_index]);
     output_indices[2] += uniforms.sizes_in_concat_axis[2];
     set_output_by_indices(output_indices, input_2[global_idx - uniforms.offsets[input_index]]);
  }
}
@compute @workgroup_size(workgroup_size_x, workgroup_size_y, workgroup_size_z)
fn main(@builtin(global_invocation_id) global_id : vec3<u32>,
        @builtin(workgroup_id) workgroup_id : vec3<u32>,
        @builtin(local_invocation_index) local_idx : u32,
        @builtin(local_invocation_id) local_id : vec3<u32>,
        @builtin(subgroup_invocation_id) sg_id : u32,
        @builtin(subgroup_size) sg_size : u32,
        @builtin(num_workgroups) num_workgroups : vec3<u32>) {
  let workgroup_idx = workgroup_id.z * num_workgroups[0] * num_workgroups[1] + workgroup_id.y * num_workgroups[0] + workgroup_id.x;
  let global_idx = workgroup_idx * (workgroup_size_x * workgroup_size_y * workgroup_size_z) + local_idx;
  if (global_idx >= uniforms.output_size) { return; }
let input_index = calculate_input_index(global_idx);
assign_output_data(global_idx, input_index);

}

=== WebGPU Shader code [Concat, Key="Concat[3,2]:3|3|1:0;3|0;3|0;3:"] End ===

