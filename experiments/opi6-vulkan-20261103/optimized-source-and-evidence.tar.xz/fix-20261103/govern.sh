#!/bin/sh
set -eu
BENCH=/home/opi6/opk-webgpu-yolo26-20261103/fix-20261103
BACKUP="$BENCH/governors-$(date +%s).txt"
for policy in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    printf '%s %s\n' "$policy" "$(cat "$policy")"
done > "$BACKUP"
HEAP_GROUP=$(stat -c %g /dev/dma_heap/system)
HEAP_MODE=$(stat -c %a /dev/dma_heap/system)
restore() {
    while read -r path value; do printf '%s\n' "$value" > "$path"; done < "$BACKUP"
    chgrp "$HEAP_GROUP" /dev/dma_heap/system
    chmod "$HEAP_MODE" /dev/dma_heap/system
}
trap restore EXIT HUP INT TERM
for policy in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    printf 'performance\n' > "$policy"
done
chgrp video /dev/dma_heap/system
chmod 660 /dev/dma_heap/system
cat /sys/kernel/debug/clk/clk_summary > "$BENCH/clocks-$1.txt" 2>/dev/null || true
su -s /bin/sh opi6 -c "sh $BENCH/run.sh cpu /home/opi6/opk-expkits-1476-vulkan-20261028/runtime/bin/python3.13 $BENCH/measure.py $1"
