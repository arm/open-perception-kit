#!/bin/sh
set -eu
MODE=$1
shift
BENCH=/home/opi6/opk-webgpu-yolo26-20261103
RUNTIME=/home/opi6/opk-expkits-1476-vulkan-20261028/runtime
GPU=/home/opi6/opi6-mlwl-gpu-poc-expkits-1441-01a17759/runtime
unset VK_INSTANCE_LAYERS VK_LAYER_PATH VK_ADD_LAYER_PATH OPK_ORT_WEBGPU_LIBRARY
case "$MODE" in
    cpu) unset ORT_WEBGPU_EP_ALLOW_SOFTWARE_ADAPTER ;;
    gpu)
        export OPK_ORT_WEBGPU_LIBRARY="${OPK_ORT_PLUGIN_LIBRARY:-$BENCH/libonnxruntime_providers_webgpu.so}"
        # ORT misses platform GPUs; Dawn still selects the sole hardware Mali adapter.
        export ORT_WEBGPU_EP_ALLOW_SOFTWARE_ADAPTER=1
        ;;
    *) echo 'Expected cpu or gpu' >&2; exit 1 ;;
esac
export ORT_DISABLE_TELEMETRY=1
export PYTHONDONTWRITEBYTECODE=1
export PYTHONHOME="$RUNTIME"
export PYTHONPATH="$BENCH/generated/open_perception_kit/python/src:$RUNTIME/python3.13:$RUNTIME/python3.13/lib-dynload:$RUNTIME/dist-packages"
export GI_TYPELIB_PATH="$RUNTIME/aarch64-linux-gnu/girepository-1.0:$RUNTIME/girepository-1.0"
export GST_PLUGIN_SYSTEM_PATH="$RUNTIME/aarch64-linux-gnu/gstreamer-1.0"
export GST_PLUGIN_PATH="$BENCH/lib:$BENCH/plugins"
export GST_REGISTRY="/home/opi6/opk-webgpu-yolo26-20261103/fix-20261103/registry.bin"
export GST_REGISTRY_FORK=no
export GST_DEBUG=0
export OPK_LOG_LEVEL=3
export OPK_PROJECT_ROOT="$BENCH"
export VK_DRIVER_FILES="${OPK_VULKAN_ICD:-/etc/vulkan/icd.d/mali.json}"
export VK_ICD_FILENAMES="$VK_DRIVER_FILES"
export XDG_RUNTIME_DIR="$BENCH/xdg"
export MESA_SHADER_CACHE_DIR="$BENCH/shader-cache"
export LD_LIBRARY_PATH="$BENCH/onnxruntime-linux-aarch64-1.31.1/lib:$BENCH/lib:$GPU/lib:$RUNTIME/onnxruntime/lib:$RUNTIME/aarch64-linux-gnu:$RUNTIME/aarch64-linux-gnu/blas:$RUNTIME/aarch64-linux-gnu/lapack:$RUNTIME/aarch64-linux-gnu/pulseaudio"
exec "$RUNTIME/aarch64-linux-gnu/ld-linux-aarch64.so.1" "$@"
