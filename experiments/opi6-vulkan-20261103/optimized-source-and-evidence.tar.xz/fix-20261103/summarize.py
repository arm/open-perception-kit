"""Summarize only a complete, accuracy-checked CPU/GPU matrix."""
import json
from pathlib import Path
import statistics
ROOT = Path(__file__).resolve().parent
MODELS = tuple(f'yolo26{variant}-{size}' for variant in ('n', 's') for size in (320, 480, 640))
REPETITIONS = 3
FRAME_COUNT = 417
MINIMUM_TIMED_FRAMES = 50
MINIMUM_TIMED_SECONDS = 10
PERCENT = 100
summary = {}
for model in MODELS:
    summary[model] = {}
    for provider in ('cpu', 'gpu'):
        focused = [json.loads((ROOT / 'evidence' / f'matrix-{model}-{provider}-r{repeat}.json').read_text()) for repeat in range(1, REPETITIONS + 1)]
        videos = [json.loads((ROOT / 'evidence' / f'video-{model}-{provider}-r{repeat}.json').read_text()) for repeat in range(1, REPETITIONS + 1)]
        assert all(row['frames'] == FRAME_COUNT and row['ordered_pts_match'] and row['input_memory_preserved'] and not row['warnings'] for row in videos)
        assert all(row['frames'] >= MINIMUM_TIMED_FRAMES and row['inference_seconds'] >= MINIMUM_TIMED_SECONDS for row in focused)
        summary[model][provider] = {
            'focused_ms': statistics.median(row['mean_ms'] for row in focused),
            'focused_ms_min': min(row['mean_ms'] for row in focused),
            'focused_ms_max': max(row['mean_ms'] for row in focused),
            'focused_fps': statistics.median(row['inferences_per_second'] for row in focused),
            'pipeline_fps': statistics.median(row['fps'] for row in videos),
            'pipeline_fps_min': min(row['fps'] for row in videos),
            'pipeline_fps_max': max(row['fps'] for row in videos),
            'pipeline_inference_ms': statistics.median(row['inference_mean_ms'] for row in videos),
            'pipeline_preprocess_ms': statistics.median(row['preprocess_mean_ms'] for row in videos),
            'pipeline_cpu_ms_per_frame': statistics.median(row['cpu_ms_per_frame'] for row in videos),
        }
    agreements = [json.loads((ROOT / 'evidence' / (f'accuracy-{model}.json' if repeat == 1 else f'accuracy-{model}-r{repeat}.json')).read_text())['detection_agreement'] for repeat in range(1, REPETITIONS + 1)]
    assert all(row['within_detection_tolerance'] for row in agreements)
    summary[model]['accuracy'] = {'detections_per_video': agreements[0]['cpu_detections'], 'maximum_box_error_pixels': max(row['maximum_box_component_difference_pixels'] for row in agreements), 'maximum_confidence_error': max(row['maximum_confidence_difference'] for row in agreements)}
    summary[model]['pipeline_gain_percent'] = (summary[model]['gpu']['pipeline_fps'] / summary[model]['cpu']['pipeline_fps'] - 1) * PERCENT
    summary[model]['focused_gain_percent'] = (summary[model]['gpu']['focused_fps'] / summary[model]['cpu']['focused_fps'] - 1) * PERCENT
(ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
