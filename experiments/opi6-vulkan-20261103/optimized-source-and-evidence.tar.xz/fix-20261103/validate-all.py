"""Recheck every measured video pair, including finite values and packet counters."""
import copy
import json
from pathlib import Path
import compare
from measure import MODELS, REPETITIONS

ROOT = Path(__file__).resolve().parent
compare.BENCH = ROOT
UNIT_CONFIDENCE = 0.5
UNIT_CLASS = 1
unit = [[{'type': 'BoxDetections', 'value': {'detections': [
    {'box': compare.unit_box, 'confidence': UNIT_CONFIDENCE, 'classId': UNIT_CLASS}]}}]]
assert compare.detection_agreement(unit, unit)['within_detection_tolerance']
for invalid in (float('nan'), float('inf')):
    changed = copy.deepcopy(unit)
    changed[0][0]['value']['detections'][0]['confidence'] = invalid
    rejected = False
    try:
        compare.detection_agreement(changed, unit)
    except AssertionError as error:
        assert str(error) == 'Non-finite detection'
        rejected = True
    assert rejected, 'Non-finite confidence was accepted'

summary = {}
for model in MODELS:
    for repetition in range(1, REPETITIONS + 1):
        result = compare.compare_labels(f'video-{model}-cpu-r{repetition}',
                                        f'video-{model}-gpu-r{repetition}')
        assert result['result_packet_counters_match']
        assert result['detection_agreement']['finite_detection_values']
        assert result['detection_agreement']['within_detection_tolerance']
        name = f'accuracy-{model}' + ('' if repetition == 1 else f'-r{repetition}')
        (ROOT / 'evidence' / (name + '.json')).write_text(json.dumps(result, indent=2) + '\n')
        summary[name] = result['detection_agreement']
        print(name, result['frames'], result['detection_agreement']['matched_detections'], flush=True)
(ROOT / 'validation-complete.json').write_text(json.dumps(summary, indent=2) + '\n')
