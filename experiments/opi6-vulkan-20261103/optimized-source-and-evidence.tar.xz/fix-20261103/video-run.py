"""Real-video CPU/Vulkan comparison, adapted from the saved OPK video harness."""
import csv
import ctypes
import json
from pathlib import Path
import os
import statistics
import sys
import threading
import time
import gi

gi.require_version('Gst', '1.0')
gi.require_version('GstAllocators', '1.0')
from gi.repository import Gst, GstAllocators
Gst.init(None)
FRAME_COUNT = 417
WARMUP_FRAMES = 30
PIPELINE_TIMEOUT_SECONDS = 1800
DRAIN_TIMEOUT_SECONDS = 30
PUBLICATION_POLL_SECONDS = 0.02
DEVICE_STARTUP_GRACE_SECONDS = 5
NANOSECONDS_PER_SECOND = 1_000_000_000
NANOSECONDS_PER_MILLISECOND = 1_000_000
P95_FRACTION = .95
VP8_THREADS = 2
OUTPUT_WIDTH = 960
OUTPUT_HEIGHT = 540
model, mode, label, output_mode = sys.argv[1:]
assert mode in ('cpu','gpu')
ROOT = Path('/home/opi6/opk-webgpu-yolo26-20261103')
BUILD = ROOT / 'lib'
MODEL_NAME = model
execution = 'cpu'
pixel_format = 'NV12'
prefix = Path('/home/opi6/opk-webgpu-yolo26-20261103/fix-20261103') / 'evidence' / label
assert not prefix.with_suffix('.json').exists(), 'Preserve existing results'
perf = ctypes.CDLL(str(ROOT / 'libperfbridge.so'))
perf.bench_history_write.argtypes = [ctypes.c_char_p]
perf.bench_history_write.restype = ctypes.c_bool
plugin_file = Gst.ElementFactory.find('opkinfer').get_plugin().get_filename()
assert plugin_file == str(BUILD / 'libopkinfer.so'), plugin_file
chain_file = ROOT / 'models' / model / 'opchain.json'
video = '/home/opi6/opk-expkits-1476-vulkan-20261028/work/data/videos/GettyImages-1140581459.mov'
launch = (f'filesrc location="{video}" ! decodebin ! videoconvert ! '
          'video/x-raw,format=NV12 ! benchdmaupload name=upload ! ')
launch += f'opkinfer name=infer opchain-path="{chain_file}" active=true ! '
if output_mode == 'encode':
    launch += (f'videoconvert ! videoscale ! video/x-raw,format=BGRA,width={OUTPUT_WIDTH},height={OUTPUT_HEIGHT} ! '
               'opksink name=sink')
else:
    if output_mode == 'validate':
        launch += f'opkcomm method=file file-name="{prefix}.ndjson" ! '
    launch += 'fakesink name=sink sync=false'
pipe = Gst.parse_launch(launch)
infer = pipe.get_by_name('infer')
sink = pipe.get_by_name('sink')
if output_mode == 'encode':
    # Measure processing capacity without the sink's playback-clock pacing.
    sink.set_property('qos-enabled', False)
    sink.get_by_name('vclock').set_property('sync', False)
    assert not sink.get_by_name('vclock').get_property('sync')
    sink.get_by_name('vp8enc').set_property('threads', VP8_THREADS)
    assert sink.get_by_name('vp8enc').get_property('threads') == VP8_THREADS
final_pad = sink.get_by_name('vp8enc').get_static_pad('src') if output_mode == 'encode' else sink.get_static_pad('sink')
entered, exited, completed = [], [], []
memory_upload, memory_in, memory_out = {}, {}, {}

def record(pad, info, target):
    if target is entered and not target:
        time.sleep(DEVICE_STARTUP_GRACE_SECONDS)
    buffer = info.get_buffer()
    target.append((buffer.pts, time.monotonic_ns(), time.process_time_ns()))
    return Gst.PadProbeReturn.OK

for pad, target in ((infer.get_static_pad('sink'), entered), (infer.get_static_pad('src'), exited), (final_pad, completed)):
    pad.add_probe(Gst.PadProbeType.BUFFER, record, target)
def record_memory(pad, info, target):
    buffer = info.get_buffer()
    target[buffer.pts] = [(hash(buffer.peek_memory(index)), GstAllocators.is_dmabuf_memory(buffer.peek_memory(index)))
                          for index in range(buffer.n_memory())]
    return Gst.PadProbeReturn.OK

for pad, records in ((pipe.get_by_name('upload').get_static_pad('src'), memory_upload),
                     (infer.get_static_pad('sink'), memory_in),
                     (infer.get_static_pad('src'), memory_out)):
    pad.add_probe(Gst.PadProbeType.BUFFER, record_memory, records)
drained = threading.Event()

def on_event(pad, info):
    if info.get_event().type == Gst.EventType.EOS:
        drained.set()
    return Gst.PadProbeReturn.OK

final_pad.add_probe(Gst.PadProbeType.EVENT_DOWNSTREAM, on_event)
perf.bench_history_enable()
started = time.monotonic()
warnings = []
try:
    state = pipe.set_state(Gst.State.PLAYING)
    bus = pipe.get_bus()
    deadline = started + PIPELINE_TIMEOUT_SECONDS
    while True:
        remaining = deadline - time.monotonic()
        assert remaining > 0, 'Pipeline timeout'
        message = bus.timed_pop_filtered(int(remaining * Gst.SECOND), Gst.MessageType.ERROR | Gst.MessageType.EOS | Gst.MessageType.WARNING)
        assert message is not None, 'Pipeline timeout'
        if message.type == Gst.MessageType.ERROR:
            raise RuntimeError(str(message.parse_error()))
        if message.type == Gst.MessageType.WARNING:
            warnings.append(str(message.parse_warning()))
            continue
        break
    assert drained.wait(DRAIN_TIMEOUT_SECONDS), 'Output did not drain'
    if output_mode == 'validate':
        publication_deadline = time.monotonic() + DRAIN_TIMEOUT_SECONDS
        while prefix.with_suffix('.ndjson').read_bytes().count(b'\n') < FRAME_COUNT:
            assert time.monotonic() < publication_deadline, 'Metadata publisher did not drain'
            time.sleep(PUBLICATION_POLL_SECONDS)
    caps = infer.get_static_pad('sink').get_current_caps().to_string()
    maps = Path('/proc/self/maps').read_text()
    assert '/onnxruntime-linux-aarch64-1.31.1/lib/libonnxruntime.so.1.31.1' in maps
    prefix.with_suffix('.maps').write_text(maps)
    drm_files = {}
    for path in Path('/proc/self/fdinfo').iterdir():
        try:
            contents = path.read_text()
            if 'drm-' in contents:
                drm_files[path.name] = contents
        except FileNotFoundError:
            pass
    prefix.with_suffix('.drm.json').write_text(json.dumps(drm_files, indent=2)+'\n')
    if mode == 'gpu':
        assert 'libonnxruntime_providers_webgpu' in maps and 'libmali.so' in maps
        assert 'libvulkan_lvp' not in maps and 'libvk_swiftshader' not in maps
    else:
        assert 'libonnxruntime_providers_webgpu' not in maps
finally:
    pipe.set_state(Gst.State.NULL)
assert perf.bench_history_write(str(prefix.with_suffix('.csv')).encode()), 'Performance recorder dropped events'
assert len(entered) == len(exited) == len(completed) == FRAME_COUNT, (len(entered), len(exited), len(completed))
assert [frame[0] for frame in entered] == [frame[0] for frame in exited] == [frame[0] for frame in completed]
assert len({frame[0] for frame in completed}) == FRAME_COUNT, 'Duplicate PTS'
with prefix.with_suffix('.csv').open() as handle:
    spans = list(csv.DictReader(handle))
preprocessing_name = ('vulkan' if execution == 'gpu' else 'std') + '/GenImgPre/' + MODEL_NAME
preprocessing = [int(row['duration_ns']) / NANOSECONDS_PER_MILLISECOND for row in spans if row['name'] == preprocessing_name]
assert len(preprocessing) == FRAME_COUNT, (preprocessing_name, len(preprocessing), sorted({row['name'] for row in spans}))
inference_name = 'onnx/Infer/' + MODEL_NAME
inference_times = [int(row['duration_ns']) / NANOSECONDS_PER_MILLISECOND for row in spans if row['name'] == inference_name]
assert len(inference_times) == FRAME_COUNT, (inference_name, len(inference_times))
assert len(memory_upload) == FRAME_COUNT and all(all(value[1] for value in values) for values in memory_upload.values())
assert all(all(value[1] for value in values) for values in memory_in.values())
assert memory_in == memory_out, 'OPK replaced the input video memory'
inference_times = inference_times[WARMUP_FRAMES:]
preprocessing = preprocessing[WARMUP_FRAMES:]
steady = completed[WARMUP_FRAMES:]
latencies = [(end[1] - start[1]) / NANOSECONDS_PER_MILLISECOND for start, end in zip(entered[WARMUP_FRAMES:], exited[WARMUP_FRAMES:])]
summary = dict(model=model, provider=mode, inference_mean_ms=statistics.mean(inference_times),
    inference_p95_ms=sorted(inference_times)[int(len(inference_times)*P95_FRACTION)],
    dma_frames=FRAME_COUNT, input_memory_preserved=True, label=label, execution=execution, format=pixel_format, output=output_mode,
    pipeline=launch, plugin_file=plugin_file, frames=FRAME_COUNT, warmup_frames=WARMUP_FRAMES,
    ordered_pts_match=True, pts=[frame[0] for frame in completed], caps=caps,
    wall_seconds=time.monotonic()-started,
    fps=(len(steady)-1)*NANOSECONDS_PER_SECOND/(steady[-1][1]-steady[0][1]),
    preprocess_mean_ms=statistics.mean(preprocessing), preprocess_p95_ms=sorted(preprocessing)[int(len(preprocessing)*P95_FRACTION)],
    opchain_mean_ms=statistics.mean(latencies), opchain_p95_ms=sorted(latencies)[int(len(latencies)*P95_FRACTION)],
    cpu_ms_per_frame=(steady[-1][2]-steady[0][2])/NANOSECONDS_PER_MILLISECOND/(len(steady)-1), warnings=warnings)
prefix.with_suffix('.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key != 'pts'}), flush=True)
