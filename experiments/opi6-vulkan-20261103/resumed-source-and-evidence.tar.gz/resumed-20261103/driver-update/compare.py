"""Compare every decoded detection from identical CPU and GPU ONNX models."""
import base64
import importlib
import json
import math
from pathlib import Path
import sys

ROOT = Path('/home/opi6/opk-webgpu-yolo26-20261103')
BENCH = Path('/home/opi6/opk-webgpu-yolo26-20261103/driver-update-20261103')
FRAME_COUNT = 417
RELATIVE_CORRECTNESS_TOLERANCE = 1e-3
ABSOLUTE_CORRECTNESS_TOLERANCE = 1e-4
PIXEL_TOLERANCE = 0.1
CONFIDENCE_TOLERANCE = 1e-3
MINIMUM_MATCH_IOU = 0.5
sys.path.insert(0, str(ROOT / 'generated/open_perception_kit/python/src'))
from open_perception_kit.packet import decode
from open_perception_kit import ProducerIdentityStatus
from open_perception_kit.registry import _TYPE_REGISTRY


def canonical(value):
    if isinstance(value, bytes):
        return value.decode()
    if isinstance(value, (list, tuple)):
        return [canonical(item) for item in value]
    if hasattr(value, 'tolist'):
        return canonical(value.tolist())
    if hasattr(value, '__dict__'):
        return {key: canonical(item) for key, item in vars(value).items()
                if key not in {'object', 'producer', 'inferElementId'}}
    return value


def semantic_packet(packet):
    envelope = decode(packet)
    assert envelope.valid(), envelope.error()
    assert envelope.producer_identity() == ProducerIdentityStatus.EXACT_MATCH
    payloads = []
    for entry in _TYPE_REGISTRY.values():
        if entry['root_type'] in {'FrameContext', 'PerformanceOverlay', 'ObjectTracks', 'TrackTraces'}:
            continue
        native = getattr(importlib.import_module(entry['module']), entry['native_type'])
        payloads.extend({'type': entry['root_type'], 'value': canonical(value)}
                        for value in envelope.for_each(native))
    assert payloads, 'No recognized model payloads'
    return payloads


def compare(actual, expected, path="$"):
    if isinstance(expected, float):
        assert math.isfinite(actual) and math.isclose(actual, expected, rel_tol=RELATIVE_CORRECTNESS_TOLERANCE, abs_tol=ABSOLUTE_CORRECTNESS_TOLERANCE), (path, actual, expected)
    elif isinstance(expected, dict):
        assert actual.keys() == expected.keys(), (path, "keys", list(actual), list(expected))
        for key in expected:
            compare(actual[key], expected[key], f"{path}.{key}")
    elif isinstance(expected, list):
        assert len(actual) == len(expected), (path, "length", len(actual), len(expected))
        for index, (a, b) in enumerate(zip(actual, expected)):
            compare(a, b, f"{path}[{index}]")
    else:
        assert actual == expected, (path, actual, expected)


def semantic_status(actual, expected, record_differences, video=False):
    try:
        compare(actual, expected)
        return {'semantic_output_matches': True}
    except AssertionError as error:
        if not record_differences:
            raise
        status = {'semantic_output_matches': False, 'semantic_comparison_error': str(error),
                  'semantic_differences_recorded_explicitly': True}
        if video:
            failures = []
            for index, (actual_frame, expected_frame) in enumerate(zip(actual, expected)):
                try:
                    compare(actual_frame, expected_frame, f'$[{index}]')
                except AssertionError as frame_error:
                    failures.append({'frame_index': index, 'first_mismatch': str(frame_error)})
            status['semantic_mismatching_frames'] = failures
        return status


def box_iou(a, b):
    intersection = max(0, min(a['x'] + a['width'], b['x'] + b['width']) - max(a['x'], b['x'])) * max(
        0, min(a['y'] + a['height'], b['y'] + b['height']) - max(a['y'], b['y']))
    union = a['width'] * a['height'] + b['width'] * b['height'] - intersection
    return intersection / union if union > 0 else 0


def detection_agreement(actual, expected):
    metrics = {'matched_detections': 0, 'cpu_detections': 0, 'gpu_detections': 0,
               'unmatched_cpu': 0, 'unmatched_gpu': 0, 'minimum_iou': 1.0,
               'maximum_box_component_difference_pixels': 0.0, 'maximum_confidence_difference': 0.0}
    for gpu_frame, cpu_frame in zip(actual, expected):
        assert len(gpu_frame) == len(cpu_frame) == 1
        assert gpu_frame[0]['type'] == cpu_frame[0]['type'] == 'BoxDetections'
        gpu = gpu_frame[0]['value']['detections']
        cpu = cpu_frame[0]['value']['detections']
        metrics['cpu_detections'] += len(cpu)
        metrics['gpu_detections'] += len(gpu)
        candidates = sorted(((box_iou(a['box'], b['box']), i, j)
                             for i, a in enumerate(gpu) for j, b in enumerate(cpu)
                             if a['classId'] == b['classId']), reverse=True)
        used_gpu, used_cpu = set(), set()
        for iou, i, j in candidates:
            if iou < MINIMUM_MATCH_IOU or i in used_gpu or j in used_cpu:
                continue
            used_gpu.add(i)
            used_cpu.add(j)
            metrics['matched_detections'] += 1
            metrics['minimum_iou'] = min(metrics['minimum_iou'], iou)
            difference = max(abs(gpu[i]['box'][key] - cpu[j]['box'][key]) for key in ('x', 'y', 'width', 'height'))
            metrics['maximum_box_component_difference_pixels'] = max(metrics['maximum_box_component_difference_pixels'], difference)
            metrics['maximum_confidence_difference'] = max(metrics['maximum_confidence_difference'], abs(gpu[i]['confidence'] - cpu[j]['confidence']))
        metrics['unmatched_cpu'] += len(cpu) - len(used_cpu)
        metrics['unmatched_gpu'] += len(gpu) - len(used_gpu)
    metrics['within_detection_tolerance'] = (metrics['matched_detections'] > 0 and metrics['unmatched_cpu'] == metrics['unmatched_gpu'] == 0
        and metrics['maximum_box_component_difference_pixels'] <= PIXEL_TOLERANCE
        and metrics['maximum_confidence_difference'] <= CONFIDENCE_TOLERANCE)
    metrics['pixel_tolerance'] = PIXEL_TOLERANCE
    metrics['confidence_tolerance'] = CONFIDENCE_TOLERANCE
    return metrics


unit_box = {'x': 0, 'y': 0, 'width': 1, 'height': 1}
assert box_iou(unit_box, unit_box) == 1
assert box_iou(unit_box, unit_box | {'x': 2}) == 0


def compare_labels(reference_label, candidate_label):
    captures = {}
    timestamps = {}
    for provider, label in (('cpu', reference_label), ('gpu', candidate_label)):
        path = BENCH / 'evidence' / f'{label}.ndjson'
        timestamps[provider] = json.loads(path.with_suffix('.json').read_text())['pts']
        packets = [json.loads(line) for line in path.read_text().splitlines()]
        assert len(packets) == FRAME_COUNT, (path, len(packets))
        captures[provider] = [semantic_packet(base64.b64decode(packet['frame_results_packet_b64'])) for packet in packets]
    assert timestamps['cpu'] == timestamps['gpu'], 'CPU/GPU frame timestamps differ'
    assert len({json.dumps(frame, sort_keys=True) for frame in captures['cpu']}) > 1, 'Video produced constant results'
    result = semantic_status(captures['gpu'], captures['cpu'], True, video=True)
    result['frames'] = FRAME_COUNT
    result['detection_agreement'] = detection_agreement(captures['gpu'], captures['cpu'])
    return result


if __name__ == '__main__':
    summary = {name: compare_labels(f'{name}-cpu-validate', f'{name}-gpu-validate')
               for name in sys.argv[1:]}
    path = BENCH / 'accuracy.json'
    previous = json.loads(path.read_text()) if path.exists() else {}
    previous.update(summary)
    path.write_text(json.dumps(previous, indent=2) + '\n')
    print(json.dumps({name: {key: value for key, value in result.items() if key != 'semantic_mismatching_frames'}
                      for name, result in summary.items()}), flush=True)
