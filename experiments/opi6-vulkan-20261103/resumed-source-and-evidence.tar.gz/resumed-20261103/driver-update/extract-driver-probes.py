"""Derive small ONNX probes; diagnostic.cpp supplies decoded real-video frames."""
import json
from pathlib import Path
import onnx

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'models/yolo26n-320-fp32'
PROBE_OPSET = 18
PROBE_IR_VERSION = 9
IMAGE_SHAPE = [1, 3, 320, 320]
descriptor = json.loads((BASE / 'model.json').read_text())
original = BASE / descriptor['modelFile']
model = onnx.load(original)
first_conv = next(node for node in model.graph.node if node.op_type == 'Conv')
for name in ('first-conv', 'relu'):
    destination = ROOT / name
    destination.mkdir(exist_ok=True)
    if name == 'first-conv':
        onnx.utils.extract_model(str(original), str(destination / 'model.onnx'),
                                 [model.graph.input[0].name], [first_conv.output[0]])
    else:
        graph = onnx.helper.make_graph(
            [onnx.helper.make_node('Relu', ['x'], ['y'])], 'real-video-relu',
            [onnx.helper.make_tensor_value_info('x', onnx.TensorProto.FLOAT, IMAGE_SHAPE)],
            [onnx.helper.make_tensor_value_info('y', onnx.TensorProto.FLOAT, IMAGE_SHAPE)])
        probe = onnx.helper.make_model(graph, opset_imports=[onnx.helper.make_opsetid('', PROBE_OPSET)],
                                       ir_version=PROBE_IR_VERSION)
        onnx.checker.check_model(probe)
        onnx.save(probe, destination / 'model.onnx')
    (destination / 'model.json').write_text(json.dumps(descriptor | {'modelFile': 'model.onnx'}, indent=2))
