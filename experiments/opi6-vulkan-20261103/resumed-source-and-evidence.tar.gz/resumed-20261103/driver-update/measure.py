"""Record real-video driver and kernel comparisons in a separate evidence directory."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
sys.path.insert(0, str(BASE))
import batch

batch.ROOT = ROOT
PYTHON = batch.PYTHON
MODELS = batch.MODELS
REPETITIONS = 3
PLUGINS = {
    'package': BASE / 'libonnxruntime_providers_webgpu.so',
    'control': BASE / 'mali-tiling-20261103/lib/control/libonnxruntime_providers_webgpu.so',
    'candidate': BASE / 'mali-tiling-20261103/lib/candidate/libonnxruntime_providers_webgpu.so',
}
TILES = ('8x8-r1', '8x8-r2', '8x16-r1', '8x16-r2', '8x4-r2')


def diagnostic(label, model, plugin, tile=None, memory_model=None):
    settings = {'OPK_ORT_PLUGIN_LIBRARY': str(PLUGINS[plugin])}
    if tile:
        settings['ORT_WEBGPU_MALI_TILE'] = tile
    if memory_model:
        settings['ORT_WEBGPU_DISABLE_VULKAN_MEMORY_MODEL'] = memory_model
    batch.ENVIRONMENT.update(settings)
    try:
        batch.execute('gpu', [str(BASE / 'diagnostic'), batch.RAW,
                             str(BASE / 'models' / (model + '-fp32') / 'model.json'),
                             'host', '0', 'disabled'], label)
    finally:
        for key in settings:
            batch.ENVIRONMENT.pop(key)
    log = (ROOT / 'evidence' / (label + '.log')).read_text()
    values = [json.loads(line) for line in log.splitlines() if line.startswith('{"frames":')]
    assert len(values) == 1, label
    row = values[0]
    assert row['frames'] >= batch.MINIMUM_FOCUSED_FRAMES
    assert row['inference_seconds'] >= batch.MINIMUM_FOCUSED_SECONDS
    row.update(label=label, model=model, plugin=plugin, tile=tile,
               disable_vulkan_memory_model=memory_model,
               plugin_sha256=hashlib.sha256(PLUGINS[plugin].read_bytes()).hexdigest())
    (ROOT / 'evidence' / (label + '.json')).write_text(json.dumps(row, indent=2))
    print(json.dumps(row), flush=True)
    return row


def main():
    mode = sys.argv[1]
    (ROOT / 'evidence').mkdir(exist_ok=True)
    stopped = threading.Event()
    samples = []

    def monitor():
        while not stopped.is_set():
            samples.append(batch.hardware())
            stopped.wait(batch.SAMPLE_SECONDS)

    thread = threading.Thread(target=monitor)
    thread.start()
    try:
        if mode == 'control':
            diagnostic('control-original-n320', 'yolo26n-320', 'control')
        elif mode == 'memory-model':
            diagnostic('candidate-memory-model-off-n320', 'yolo26n-320', 'candidate', memory_model='1')
        elif mode == 'screen':
            for tile in (None, *TILES):
                diagnostic('screen-n320-' + (tile or 'generic'), 'yolo26n-320', 'candidate', tile, '1')
                time.sleep(batch.COOLDOWN_SECONDS)
        elif mode in ('preprocess', 'preprocess-clean'):
            for repetition in range(1, REPETITIONS + 1):
                for provider in (('cpu', 'gpu') if repetition % 2 else ('gpu', 'cpu')):
                    label = f'{mode}-{provider}-r{repetition}'
                    with (ROOT / 'evidence' / (label + '.log')).open('w') as log:
                        subprocess.run(['sh', str(ROOT / 'preprocess-new-driver.sh'), batch.RAW,
                                        'NV12', provider], env=batch.ENVIRONMENT, stdout=log, stderr=subprocess.STDOUT,
                                       timeout=batch.TRIAL_TIMEOUT_SECONDS, check=True)
                    time.sleep(batch.COOLDOWN_SECONDS)
        else:
            raise ValueError(mode)
    finally:
        stopped.set()
        thread.join()
        (ROOT / ('hardware-' + mode + '.json')).write_text(json.dumps(samples, indent=2))


if __name__ == '__main__':
    main()
