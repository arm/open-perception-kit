// Benchmark-only bridge: copy decoded video into real DMA-BUF allocations.
#include <gst/allocators/gstdmabuf.h>
#include <gst/base/gstbasetransform.h>
#include <gst/video/video.h>
#include <fcntl.h>
#include <linux/dma-buf.h>
#include <linux/dma-heap.h>
#include <sys/ioctl.h>
#include <unistd.h>

struct BenchDmaUpload {
    GstBaseTransform parent;
    GstVideoInfo video;
    GstAllocator* allocator;
    int heap;
};
struct BenchDmaUploadClass { GstBaseTransformClass parent; };
G_DEFINE_TYPE(BenchDmaUpload, bench_dma_upload, GST_TYPE_BASE_TRANSFORM)

static gboolean start(GstBaseTransform* const base) {
    auto* const self = reinterpret_cast<BenchDmaUpload*>(base);
    self->heap = open("/dev/dma_heap/system", O_RDWR | O_CLOEXEC);
    self->allocator = gst_dmabuf_allocator_new();
    if (self->heap < 0) {
        GST_ELEMENT_ERROR(base, RESOURCE, OPEN_READ_WRITE, ("Cannot open DMA heap"), (nullptr));
        return FALSE;
    }
    return TRUE;
}
static gboolean stop(GstBaseTransform* const base) {
    auto* const self = reinterpret_cast<BenchDmaUpload*>(base);
    if (self->heap >= 0) close(self->heap);
    self->heap = -1;
    gst_clear_object(&self->allocator);
    return TRUE;
}
static gboolean setCaps(GstBaseTransform* const base, GstCaps* const input, GstCaps*) {
    return gst_video_info_from_caps(&reinterpret_cast<BenchDmaUpload*>(base)->video, input);
}
static GstFlowReturn prepare(GstBaseTransform* const base, GstBuffer* const input, GstBuffer** const output) {
    auto* const self = reinterpret_cast<BenchDmaUpload*>(base);
    dma_heap_allocation_data allocation{};
    allocation.len = self->video.size;
    allocation.fd_flags = O_RDWR | O_CLOEXEC;
    if (ioctl(self->heap, DMA_HEAP_IOCTL_ALLOC, &allocation) < 0) {
        GST_ELEMENT_ERROR(base, RESOURCE, NO_SPACE_LEFT, ("DMA allocation failed"), (nullptr));
        return GST_FLOW_ERROR;
    }
    GstMemory* const memory = gst_dmabuf_allocator_alloc(self->allocator, allocation.fd, allocation.len);
    if (!memory) { close(allocation.fd); return GST_FLOW_ERROR; }
    *output = gst_buffer_new();
    gst_buffer_append_memory(*output, memory);
    gst_buffer_copy_into(*output, input,
        static_cast<GstBufferCopyFlags>(GST_BUFFER_COPY_FLAGS | GST_BUFFER_COPY_TIMESTAMPS), 0, -1);
    gst_buffer_add_video_meta_full(*output, GST_VIDEO_FRAME_FLAG_NONE,
        GST_VIDEO_INFO_FORMAT(&self->video), self->video.width, self->video.height,
        GST_VIDEO_INFO_N_PLANES(&self->video), self->video.offset, self->video.stride);
    return GST_FLOW_OK;
}
static GstFlowReturn transform(GstBaseTransform* const base, GstBuffer* const input, GstBuffer* const output) {
    auto* const self = reinterpret_cast<BenchDmaUpload*>(base);
    GstVideoFrame source{}, destination{};
    if (!gst_video_frame_map(&source, &self->video, input, GST_MAP_READ)) return GST_FLOW_ERROR;
    if (!gst_video_frame_map(&destination, &self->video, output, GST_MAP_WRITE)) {
        gst_video_frame_unmap(&source);
        return GST_FLOW_ERROR;
    }
    const int fd = gst_dmabuf_memory_get_fd(gst_buffer_peek_memory(output, 0));
    dma_buf_sync sync{DMA_BUF_SYNC_START | DMA_BUF_SYNC_WRITE};
    const bool started = ioctl(fd, DMA_BUF_IOCTL_SYNC, &sync) == 0;
    const bool copied = started && gst_video_frame_copy(&destination, &source);
    sync.flags = DMA_BUF_SYNC_END | DMA_BUF_SYNC_WRITE;
    const bool ended = started && ioctl(fd, DMA_BUF_IOCTL_SYNC, &sync) == 0;
    gst_video_frame_unmap(&destination);
    gst_video_frame_unmap(&source);
    if (!copied || !ended) {
        GST_ELEMENT_ERROR(base, RESOURCE, WRITE, ("DMA upload or synchronization failed"), (nullptr));
        return GST_FLOW_ERROR;
    }
    return GST_FLOW_OK;
}
static void bench_dma_upload_class_init(BenchDmaUploadClass* const klass) {
    auto* const element = GST_ELEMENT_CLASS(klass);
    gst_element_class_set_static_metadata(element, "Benchmark DMA uploader", "Filter/Video",
        "Copies decoded pixels into a kernel DMA heap; benchmark instrumentation only", "OPK benchmark");
    GstCaps* const caps = gst_caps_from_string("video/x-raw,format=NV12");
    gst_element_class_add_pad_template(element, gst_pad_template_new("sink", GST_PAD_SINK, GST_PAD_ALWAYS, caps));
    gst_element_class_add_pad_template(element, gst_pad_template_new("src", GST_PAD_SRC, GST_PAD_ALWAYS, caps));
    gst_caps_unref(caps);
    auto* const transformClass = GST_BASE_TRANSFORM_CLASS(klass);
    transformClass->start = start;
    transformClass->stop = stop;
    transformClass->set_caps = setCaps;
    transformClass->prepare_output_buffer = prepare;
    transformClass->transform = transform;
}
static void bench_dma_upload_init(BenchDmaUpload* const self) {
    self->heap = -1;
    gst_base_transform_set_in_place(GST_BASE_TRANSFORM(self), FALSE);
    gst_base_transform_set_passthrough(GST_BASE_TRANSFORM(self), FALSE);
}
// The base branch rejects DMA-BUF: provide its required CPU-memory boundary.
struct BenchCpuCopy { GstBaseTransform parent; };
struct BenchCpuCopyClass { GstBaseTransformClass parent; };
G_DEFINE_TYPE(BenchCpuCopy, bench_cpu_copy, GST_TYPE_BASE_TRANSFORM)
static GstFlowReturn prepareCpu(GstBaseTransform*, GstBuffer* const input, GstBuffer** const output) {
    *output = gst_buffer_copy_deep(input);
    return *output ? GST_FLOW_OK : GST_FLOW_ERROR;
}
static GstFlowReturn passCpu(GstBaseTransform*, GstBuffer*) { return GST_FLOW_OK; }
static void bench_cpu_copy_class_init(BenchCpuCopyClass* const klass) {
    auto* const element = GST_ELEMENT_CLASS(klass);
    gst_element_class_set_static_metadata(element, "Benchmark CPU copy", "Filter/Video",
        "CPU copy required by the base branch", "OPK benchmark");
    GstCaps* const caps = gst_caps_from_string("video/x-raw,format=NV12");
    gst_element_class_add_pad_template(element, gst_pad_template_new("sink", GST_PAD_SINK, GST_PAD_ALWAYS, caps));
    gst_element_class_add_pad_template(element, gst_pad_template_new("src", GST_PAD_SRC, GST_PAD_ALWAYS, caps));
    gst_caps_unref(caps);
    auto* const transformClass = GST_BASE_TRANSFORM_CLASS(klass);
    transformClass->prepare_output_buffer = prepareCpu;
    transformClass->transform_ip = passCpu;
}
static void bench_cpu_copy_init(BenchCpuCopy* const self) {
    gst_base_transform_set_in_place(GST_BASE_TRANSFORM(self), TRUE);
    gst_base_transform_set_passthrough(GST_BASE_TRANSFORM(self), FALSE);
}
static gboolean init(GstPlugin* const plugin) {
    return gst_element_register(plugin, "benchdmaupload", GST_RANK_NONE, bench_dma_upload_get_type()) &&
        gst_element_register(plugin, "benchcpucopy", GST_RANK_NONE, bench_cpu_copy_get_type());
}
#define PACKAGE "opk-benchmark"
GST_PLUGIN_DEFINE(GST_VERSION_MAJOR, GST_VERSION_MINOR, benchdmaupload,
    "Benchmark DMA upload", init, "1.0", "LGPL", PACKAGE, "https://github.com/arm/open-perception-kit")
