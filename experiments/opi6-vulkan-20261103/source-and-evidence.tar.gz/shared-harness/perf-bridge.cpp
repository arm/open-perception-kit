#include "runtime/PerformanceMetrics.h"
extern "C" void bench_history_enable() {
    opk::runtime::PerformanceMetrics::setHistoryEnabled(true);
}
extern "C" bool bench_history_write(const char *const path) {
    opk::runtime::PerformanceMetrics::setHistoryEnabled(false);
    const auto snapshot = opk::runtime::PerformanceMetrics::snapshot();
    return !snapshot.droppedMetrics && !snapshot.droppedSpans && !snapshot.droppedHistoryEvents &&
           !snapshot.wrongThreadScopeCloses && !snapshot.threadSlotOverflow &&
           opk::runtime::PerformanceMetrics::writeCsv(path);
}
