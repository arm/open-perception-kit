# Native ONNX/Vulkan experiment on OPi6

Local benchmark implementation for YOLO26n and YOLO26s at 320, 480 and 640 pixels. The primary comparison loads the **same FP32 ONNX file on CPU and GPU**. The packaged INT8 models are an additional CPU reference with a different precision, not the primary CPU/GPU comparison.

The prototype uses ONNX Runtime 1.31.1 and native WebGPU provider 0.5.0. Dawn selects Vulkan and the board's Mali-G720 MC10 through PanVK 26.0.5. No browser is involved. Both providers use 11 intra-op threads, one inter-op thread and sequential execution; CPU affinity is not pinned. Measurements use the performance CPU governor and a 1 GHz GPU clock. The OPK source basis is `c5c1aac6cc3fc3a639e5170d375936130447174d`.

## Implementation

- `WebGpuProvider.h` registers the native provider, selects it explicitly, and rejects missing GPU-provider discovery. `ops-onnx/Inference.cpp` calls it during session setup. CPU operation uses the existing path when `OPK_ORT_WEBGPU_LIBRARY` is unset.
- `run.sh` selects the isolated runtime, provider and PanVK ICD. The discovery workaround `ORT_WEBGPU_EP_ALLOW_SOFTWARE_ADAPTER=1` lets ORT expose the EP when its device discovery misses this platform GPU. It does not select a software Vulkan driver: Dawn adapter index 0 is the sole Mali hardware adapter. Driver maps, adapter logs and DRM file descriptors provide independent checks.
- `video-run.py` reuses the OPK real-video harness, counts all 417 frames and performance scopes, checks ordered timestamps and retained DMA-BUF memory, and writes raw timing evidence.
- `focused.cpp` prepares real video frames outside the timer and measures inference including host input/output transfers. `diagnostic.cpp` additionally tests I/O binding: input binding/upload happens before the timer, outputs remain on the GPU, and a four-byte completion readback is included in the timer. Native EP I/O synchronization alone did not bound GPU work, so an explicit completed readback is required. Internal CPU fallback and its transfers remain part of the full-model binding diagnostic. A separate, explicitly labelled compute subgraph removes the decoded detection output while preserving every Conv/MatMul and its original parameters; it tests GPU-resident execution and graph capture without being presented as complete-model FPS.
- `compare.py` decodes OPK FrameResults and records both strict numerical comparison and detection agreement. The latter requires matching classes/counts, box-component differences at most 0.1 pixels, and confidence differences at most 0.001.
- `batch.py` runs three sequential focused-inference repetitions with 30 warmup frames and reversed order in the second repetition. Each CPU/GPU pair also has one complete 417-frame pipeline pass, which supplies the all-frame output comparison and pipeline FPS. Focused trials require at least 50 timed inferences and 10 seconds of measured inference time. `govern.sh` saves and restores clock settings and DMA-heap permissions with an exit trap.

The primary pipeline deliberately uses identical CPU preprocessing and CPU detection parsing for both providers. Its GPU path uploads the tensor and returns all six original model outputs to CPU memory. It is not a GPU-resident preprocessing-to-inference integration. The I/O-binding diagnostic measures the benefit of removing these external transfers separately.

## Optimization experiments

The baseline binaries are preserved in `baseline-build/`. `tune.py` screens layout, CPU thread count, submission batching, FP16, a combined-convolution graph and the board's system PanVK driver. These are separate results; the baseline model artifacts remain unchanged.

The exact binaries used for optimization screening and full-video candidates are preserved in `tuning-build/`. Final binaries remove an unused `MatMulNBits` accumulation override; the default execution settings are unchanged. `provenance.json` records both sets. `profile-candidates.py` uses the final helper to verify operator placement separately from timing; `optimization-video.py` compares every candidate frame against the original CPU captures.

`convert-fp16.py` uses the official converter with explicit boundary casts for the export's intermediate graph outputs, and corrects the converter's original-Cast type mismatch. All candidate ONNX files pass the full checker. `combine-convolutions.py` recombines 15 groups of summed pointwise convolutions into Concat+Conv, retaining each weight value and bias. It checks exclusive use of removed intermediates, convolution attributes and preserved outputs. Numerical checks are still required because FP32 reduction order changes.

The helper accepts benchmark-only environment overrides for layout, pending dispatch count and a single CPU thread. `OPK_ORT_REFERENCE_MODEL` lets the diagnostic validate a transformed model's auxiliary outputs against the original CPU model. `OPK_VULKAN_ICD` selects an explicit alternative ICD for the driver comparison. These options are private experimental controls, not production OPK configuration.

## Local reproduction

The dated paths in these scripts refer to the prepared OPi6 benchmark and the existing build container; inspect them before reuse. Builds reuse the configured OPK release compile/link commands through `build-module.py`, `build-focused.py` and `build-diagnostic.py`. Model acquisition belongs to the repository's `scripts/download-models.py`; `models-source.json` and `models-inspected.json` preserve pinned sources, shapes and hashes.

On the prepared board, run one mode at a time:

```sh
sudo sh /home/opi6/opk-webgpu-yolo26-20261103/govern.sh focused
sudo sh /home/opi6/opk-webgpu-yolo26-20261103/govern.sh full
```

The additional sequential governor modes are `resident`, `profile`, `tune`, `tune-large` and `optimization-video`. Run candidate placement checks without changing governors:

```sh
sh /home/opi6/opk-webgpu-yolo26-20261103/run.sh cpu \
  /home/opi6/opk-expkits-1476-vulkan-20261028/runtime/bin/python3.13 \
  /home/opi6/opk-webgpu-yolo26-20261103/profile-candidates.py
```

Only n/320 and s/640 were benchmarked for the derived FP16/combined graphs. The six original FP32 model/size pairs were all benchmarked; creating the remaining FP16 candidates does not constitute testing them on the GPU.

`full` validates CPU/GPU detections and measures one complete unpaced video-pipeline pass per model/provider pair. Pipeline FPS therefore has no between-run confidence interval; focused inference has three repetitions. Completed trial JSON files are preserved on resume. Failed or incomplete runs are not valid throughput results.

The input is the 417-frame GettyImages video, decoded to 1920×1080 NV12, BT.709 limited range. The harness uploads decoded frames into a real DMA-BUF allocation. Pipeline FPS includes decode, upload, preprocessing, inference, detection parsing and file publication of FrameResults; it excludes display, video encoding and playback pacing. This is processing capacity, not camera or displayed-video FPS.

Only Linux on OPi6 is tested. Native macOS, Windows, WSL GPU execution and other boards are outside these measurements. The prototype is local and is not a production backend integration.

References: [native WebGPU provider](https://onnxruntime.ai/docs/execution-providers/WebGPU-ExecutionProvider.html), [ONNX Runtime I/O binding](https://onnxruntime.ai/docs/performance/tune-performance/iobinding.html), [ONNX Runtime 1.31.1](https://github.com/microsoft/onnxruntime/releases/tag/v1.31.1), [WebGPU provider 0.5.0](https://www.nuget.org/packages/Microsoft.ML.OnnxRuntime.EP.WebGpu/0.5.0).
