#pragma once

#include "mediaio/VideoFrame.h"
#include "opk/Model.h"
#include "ops-std/preproc/GenericImageTensorBuilder.h"
#include <fstream>
#include <stdexcept>
#include <vector>

namespace benchmark {
constexpr uint32_t SourceWidth = 1920;
constexpr uint32_t SourceHeight = 1080;
constexpr size_t FrameCount = 417;
constexpr size_t ChromaSubsampling = 2;
constexpr size_t SourcePixels = SourceWidth * SourceHeight;
constexpr size_t FrameBytes = SourcePixels + SourcePixels / ChromaSubsampling;
constexpr size_t NchwHeightDimension = 2;
constexpr size_t NchwWidthDimension = 3;

inline void require(const bool condition, const char *const message) {
    if (!condition)
        throw std::runtime_error(message);
}

class Frame final : public opk::mediaio::VideoFrame {
  public:
    explicit Frame(uint8_t *const data)
        : views{
              opk::mediaio::DataView::host(data, SourcePixels, SourceWidth, opk::AccessMode::Read),
              opk::mediaio::DataView::host(data + SourcePixels,
                                           SourcePixels / ChromaSubsampling,
                                           SourceWidth,
                                           opk::AccessMode::Read)} {}
    opk::RawImagePixelFormat format() const noexcept override {
        return opk::RawImagePixelFormat::Nv12;
    }
    opk::YuvColorMatrix yuvColorMatrix() const noexcept override {
        return opk::YuvColorMatrix::Bt709;
    }
    opk::YuvRange yuvRange() const noexcept override {
        return opk::YuvRange::Limited;
    }
    uint32_t width() const noexcept override {
        return SourceWidth;
    }
    uint32_t height() const noexcept override {
        return SourceHeight;
    }
    opk::mediaio::TimestampNs timestampNs() const noexcept override {
        return 0;
    }
    opk::MemoryType memoryType() const noexcept override {
        return opk::MemoryType::Host;
    }
    std::span<const opk::mediaio::DataView> planes() const noexcept override {
        return views;
    }
    bool canMap(const opk::AccessMode) const noexcept override {
        return true;
    }
    std::unique_ptr<VideoFrame> map(const opk::AccessMode) const override {
        return std::make_unique<Frame>(*this);
    }

  private:
    std::vector<opk::mediaio::DataView> views;
};

class Frames final {
  public:
    Frames(const std::string &path, const opk::ModelInput &input)
        : raw(FrameCount * FrameBytes), output(input.shape.getFullValueCount()), input{input} {
        std::ifstream stream{path, std::ios::binary | std::ios::ate};
        require(bool(stream) && stream.tellg() == static_cast<std::streamoff>(raw.size()),
                "Raw video size mismatch");
        stream.seekg(0);
        stream.read(reinterpret_cast<char *>(raw.data()), static_cast<std::streamsize>(raw.size()));
        require(bool(stream), "Incomplete raw video read");
    }

    std::span<const float> prepare(const size_t index) {
        require(index < FrameCount, "Frame index out of range");
        const Frame frame{raw.data() + index * FrameBytes};
        opk::TensorBuilder::Setup setup;
        auto &source = setup.imageSourceDesc;
        source.surfaceWidth = SourceWidth;
        source.surfaceHeight = SourceHeight;
        source.rect = {0, 0, SourceWidth, SourceHeight};
        source.format = frame.format();
        source.type = opk::Dtype::Uint8;
        source.mean = input.mean;
        source.std = input.std;
        source.yuvMatrix = frame.yuvColorMatrix();
        source.yuvRange = frame.yuvRange();
        source.planeCount = frame.planes().size();
        for (size_t planeIndex = 0; planeIndex < source.planeCount; ++planeIndex) {
            const auto &plane = frame.planes()[planeIndex];
            source.planes[planeIndex] = {static_cast<const uint8_t *>(plane.data()),
                                         nullptr,
                                         plane.byteSize(),
                                         plane.strideBytes()};
        }
        auto &destination = setup.imageDestinationDesc;
        const auto width = static_cast<size_t>(input.shape.dims[NchwWidthDimension]);
        const auto height = static_cast<size_t>(input.shape.dims[NchwHeightDimension]);
        destination.type = input.valueType;
        destination.kind = input.dataKind;
        destination.surfaceWidth = width;
        destination.surfaceHeight = height;
        destination.rect = {0, 0, width, height};
        destination.planeCount = 1;
        destination.planes[0] = {
            nullptr, reinterpret_cast<uint8_t *>(output.data()), output.size() * sizeof(float), 0};
        destination.keepAspectRatio = input.keepAspectRatio;
        destination.letterboxRed = input.letterboxRed;
        destination.letterboxGreen = input.letterboxGreen;
        destination.letterboxBlue = input.letterboxBlue;
        require(bool(builder.build(setup)), "CPU preprocessing failed");
        return output;
    }

  private:
    std::vector<uint8_t> raw;
    std::vector<float> output;
    const opk::ModelInput input;
    opk::stdop::preproc::GenericImageTensorBuilder builder;
};
} // namespace benchmark
