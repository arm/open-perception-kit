"""Summarize completed trials; do not extrapolate missing results."""
from collections import defaultdict
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
REPETITIONS = 3
MODELS = tuple(f'yolo26{variant}-{size}' for variant in ('n', 's') for size in (320, 480, 640))
VARIANTS = (('fp32', 'cpu'), ('fp32', 'gpu'), ('int8', 'cpu'))
FRAME_COUNT = 417


def aggregate(filename, metrics, pipeline):
    path = ROOT / filename
    rows = json.loads(path.read_text()) if path.exists() else []
    groups = defaultdict(list)
    labels = set()
    for row in rows:
        assert row['label'] not in labels, row['label']
        labels.add(row['label'])
        if pipeline:
            assert row['frames'] == FRAME_COUNT and row['ordered_pts_match']
            assert row['input_memory_preserved'] and not row['warnings']
        groups[(row['model'], row['provider'])].append(row)
    results = {}
    for (model, provider), group in groups.items():
        repetitions = sorted(row['repetition'] for row in group)
        assert len(set(repetitions)) == len(repetitions)
        assert len(group) <= REPETITIONS
        results[model + '/' + provider] = {
            'repetitions': repetitions,
            'metrics': {metric: {'median': statistics.median(row[metric] for row in group),
                                 'min': min(row[metric] for row in group),
                                 'max': max(row[metric] for row in group)}
                        for metric in metrics}}
    expected_repetitions = 1 if pipeline else REPETITIONS
    variants = VARIANTS[:2] if pipeline else VARIANTS
    complete = all(len(results.get(name + '-' + precision + '/' + provider, {}).get('repetitions', [])) == expected_repetitions
                   for name in MODELS for precision, provider in variants)
    return {'complete': complete, 'trials': len(rows), 'groups': results}


def main():
    summary = {
        'pipeline': aggregate('results.json', ('fps', 'inference_mean_ms', 'preprocess_mean_ms', 'opchain_mean_ms', 'cpu_ms_per_frame'), True),
        'focused': aggregate('focused-results.json', ('mean_ms', 'p95_ms', 'inferences_per_second'), False)}
    (ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({name: {key: value for key, value in result.items() if key != 'groups'} for name, result in summary.items()}))
    for name in MODELS:
        values = []
        for precision, provider in VARIANTS:
            group = summary['focused']['groups'].get(name + '-' + precision + '/' + provider)
            values.append(None if group is None else round(group['metrics']['inferences_per_second']['median'], 2))
        print(name, values)
    for scope in ('focused', 'pipeline'):
        if summary[scope]['complete']:
            plot(summary, scope)


def plot(summary, scope):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    sizes = (320, 480, 640)
    is_pipeline = scope == 'pipeline'
    metric = 'fps' if is_pipeline else 'inferences_per_second'
    ylabel = 'Complete pipeline FPS' if is_pipeline else 'Inferences per second'
    figure, axes = plt.subplots(1, 2, figsize=(10, 4.7), constrained_layout=True)
    for axis, variant in zip(axes, ('n', 's')):
        for provider, color, label in (('cpu', '#1766a3', 'CPU · FP32'), ('gpu', '#c6531d', 'GPU · FP32')):
            metrics = [summary[scope]['groups'][f'yolo26{variant}-{size}-fp32/{provider}']['metrics'][metric] for size in sizes]
            medians = [row['median'] for row in metrics]
            errors = None if is_pipeline else [[row['median']-row['min'] for row in metrics], [row['max']-row['median'] for row in metrics]]
            axis.errorbar(sizes, medians, yerr=errors, color=color, marker='o', linewidth=2.2, capsize=4, label=label)
            for size, median in zip(sizes, medians):
                axis.annotate(f'{median:.1f}', (size, median), xytext=(0, 8), textcoords='offset points', ha='center', color=color)
        axis.set_title('YOLO26' + variant)
        axis.set_xlabel('Square model input (pixels)')
        axis.set_ylabel(ylabel)
        axis.set_xticks(sizes)
        axis.set_ylim(bottom=0)
        axis.margins(y=.2)
        axis.grid(axis='y', alpha=.2)
        axis.spines[['top', 'right']].set_visible(False)
        axis.legend(frameon=False)
    figure.suptitle('OPi6 · Identical ONNX models on CPU and Vulkan GPU', fontsize=14)
    note = ('One complete 417-frame pass per point · 30 warmup frames excluded\nCPU preprocessing, parsing and result publication; GPU transfers included' if is_pipeline
            else 'Median and range of 3 runs · 30 warmup frames excluded\nPreprocessing excluded; GPU input/output transfers included')
    figure.supxlabel(note, fontsize=9)
    figure.savefig(ROOT / (scope + '-fps.png'), dpi=180)
    figure.savefig(ROOT / (scope + '-fps.svg'))


if __name__ == '__main__':
    main()
