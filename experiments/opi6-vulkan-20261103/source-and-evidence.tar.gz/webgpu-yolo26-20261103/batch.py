"""Resumable, sequential measurements using the existing OPK video harness."""
from pathlib import Path
import json
import os
import subprocess
import sys
import threading
import time

ROOT = Path('/home/opi6/opk-webgpu-yolo26-20261103')
PYTHON = '/home/opi6/opk-expkits-1476-vulkan-20261028/runtime/bin/python3.13'
RAW = '/home/opi6/opk-preprocess-only-20261028/NV12.raw'
MODELS = tuple(f'yolo26{variant}-{size}' for variant in ('n', 's') for size in (320, 480, 640))
REPETITIONS = 3
FRAME_COUNT = 417
COOLDOWN_SECONDS = 8
TRIAL_TIMEOUT_SECONDS = 900
SAMPLE_SECONDS = 1
MINIMUM_FOCUSED_FRAMES = 50
MINIMUM_FOCUSED_SECONDS = 10
ENVIRONMENT = {key: value for key, value in os.environ.items()
               if key not in ('LD_LIBRARY_PATH', 'PYTHONHOME', 'PYTHONPATH', 'OPK_ORT_PROFILE')}

def hardware():
    paths = [*Path('/sys/class/thermal').glob('thermal_zone*/temp'),
             *Path('/sys/class/thermal').glob('cooling_device*/cur_state'),
             *Path('/sys/devices/system/cpu/cpufreq').glob('policy*/scaling_cur_freq'),
             *Path('/sys/devices/system/cpu/cpufreq').glob('policy*/scaling_governor'),
             *Path('/sys/class/devfreq').glob('*/cur_freq')]
    return {'time': time.time(), 'load': Path('/proc/loadavg').read_text().strip(),
            'sysfs': {str(path): path.read_text().strip() for path in paths}}

def execute(provider, arguments, label):
    print('START ' + label, flush=True)
    with (ROOT / 'evidence' / (label + '.log')).open('w') as log:
        subprocess.run(['/bin/sh', str(ROOT / 'run.sh'), provider, *arguments],
                       env=ENVIRONMENT, stdout=log, stderr=subprocess.STDOUT,
                       timeout=TRIAL_TIMEOUT_SECONDS, check=True)

def video(model, provider, label, output):
    path = ROOT / 'evidence' / (label + '.json')
    if not path.exists():
        execute(provider, [PYTHON, str(ROOT / 'video-run.py'), model, provider, label, output], label)
    row = json.loads(path.read_text())
    assert row['frames'] == FRAME_COUNT and row['ordered_pts_match'] and row['input_memory_preserved']
    assert not row['warnings'], row['warnings']
    print(json.dumps({key: row[key] for key in ('label', 'fps', 'inference_mean_ms')}), flush=True)
    return row

def focused(model, provider, label):
    path = ROOT / 'evidence' / (label + '.json')
    if not path.exists():
        execute(provider, [str(ROOT / 'focused'), RAW, str(ROOT / 'models' / model / 'model.json')], label)
        lines = (ROOT / 'evidence' / (label + '.log')).read_text().splitlines()
        rows = [json.loads(line) for line in lines if line.startswith('{"frames":')]
        assert len(rows) == 1, label
        row = rows[0] | {'model': model, 'provider': provider, 'label': label}
        assert row['frames'] >= MINIMUM_FOCUSED_FRAMES and row['inference_seconds'] >= MINIMUM_FOCUSED_SECONDS
        path.write_text(json.dumps(row, indent=2) + '\n')
    row = json.loads(path.read_text())
    print(json.dumps(row), flush=True)
    return row

def run(mode):
    assert mode in ('pilot', 'full', 'cpu', 'focused')
    samples = []
    stopped = threading.Event()
    def monitor():
        while not stopped.is_set():
            samples.append(hardware())
            stopped.wait(SAMPLE_SECONDS)
    thread = threading.Thread(target=monitor)
    thread.start()
    models = MODELS[:1] if mode == 'pilot' else MODELS
    result_path = ROOT / 'results.json'
    pipeline_rows = json.loads(result_path.read_text()) if result_path.exists() else []
    focused_rows = []
    try:
        for name in (() if mode == 'focused' else models):
            for provider in (('cpu',) if mode == 'cpu' else ('cpu', 'gpu')):
                row = video(name + '-fp32', provider, name + '-' + provider + '-validate', 'validate') | {'repetition': 1}
                pipeline_rows = [item for item in pipeline_rows if item['label'] != row['label']] + [row]
                (ROOT / 'results.json').write_text(json.dumps(pipeline_rows, indent=2) + '\n')
                time.sleep(COOLDOWN_SECONDS)
            if mode != 'cpu':
                execute('cpu', [PYTHON, str(ROOT / 'compare.py'), name], name + '-accuracy')
        if mode in ('full', 'cpu'):
            return
        if mode == 'pilot':
            for provider in ('cpu', 'gpu'):
                focused(models[0] + '-fp32', provider, models[0] + '-' + provider + '-pilot')
            return
        for repetition in range(1, REPETITIONS + 1):
            order = models if repetition % 2 else tuple(reversed(models))
            variants = (('fp32', 'cpu'), ('int8', 'cpu')) if mode == 'cpu' else (('fp32', 'cpu'), ('fp32', 'gpu'), ('int8', 'cpu'))
            if not repetition % 2:
                variants = tuple(reversed(variants))
            for name in order:
                for precision, provider in variants:
                    model = name + '-' + precision
                    label = f'{model}-{provider}-r{repetition}'
                    already_focused = (ROOT / 'evidence' / (label + '-focused.json')).exists()
                    row = focused(model, provider, label + '-focused') | {'repetition': repetition}
                    focused_rows.append(row)
                    (ROOT / 'focused-results.json').write_text(json.dumps(focused_rows, indent=2) + '\n')
                    if not already_focused:
                        time.sleep(COOLDOWN_SECONDS)
    finally:
        stopped.set()
        thread.join()
        (ROOT / ('hardware-' + mode + '.json')).write_text(json.dumps(samples, indent=2) + '\n')

if __name__ == '__main__':
    run(sys.argv[1])
