"""Reuse the repository's configured release compile and link commands."""
from pathlib import Path
import json
import shlex
import subprocess

ROOT = Path('/bench/webgpu-yolo26-20261103')
BUILD = Path('/bench/stage4/development/build-native')
TARGET = 'meson-out/opk-onnx-ops.so'
SOURCES = ('Inference.cpp', 'InferenceOp.cpp', 'Plugin.cpp')
commands = json.loads((BUILD / 'compile_commands.json').read_text())
objects = {}
(ROOT / 'lib').mkdir(exist_ok=True)
for name in SOURCES:
    entry = next(row for row in commands if row['file'].endswith('/ops-onnx/' + name))
    args = shlex.split(entry['command'])
    output = str(ROOT / 'lib' / (name + '.o'))
    for option in ('-o', '-MQ', '-MF'):
        index = args.index(option) + 1
        if option == '-o':
            objects[args[index]] = output
        args[index] = output + '.d' if option == '-MF' else output
    args[args.index('-c') + 1] = str(ROOT / 'ops-onnx' / name)
    args = [arg.replace('/opt/opk-deps/onnxruntime-arm64', str(ROOT / 'onnxruntime-linux-aarch64-1.31.1')) for arg in args]
    subprocess.run(args, cwd=BUILD, check=True)

link = subprocess.check_output(['ninja', '-t', 'commands', TARGET], cwd=BUILD, text=True).splitlines()[-1]
args = [objects.get(arg, arg) for arg in shlex.split(link)]
args[args.index('-o') + 1] = str(ROOT / 'lib' / 'opk-onnx-ops.so')
args = [arg.replace('/opt/opk-deps/onnxruntime-arm64', str(ROOT / 'onnxruntime-linux-aarch64-1.31.1')) for arg in args]
subprocess.run(args, cwd=BUILD, check=True)
