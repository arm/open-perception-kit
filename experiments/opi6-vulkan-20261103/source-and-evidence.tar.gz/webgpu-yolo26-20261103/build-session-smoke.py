"""Compile the session-smoke runner using the configured OPK release command."""
from pathlib import Path
import json
import shlex
import subprocess

ROOT = Path('/bench/webgpu-yolo26-20261103')
BUILD = Path('/bench/stage4/development/build-native')
entry = next(row for row in json.loads((BUILD / 'compile_commands.json').read_text())
             if row['file'].endswith('/ops-onnx/Inference.cpp'))
args = []
skip = False
for value in shlex.split(entry['command']):
    if skip:
        skip = False
        continue
    if value in ('-MQ', '-MF', '-o', '-c'):
        skip = True
        continue
    if value != '-MD':
        args.append(value)
args += ['-I' + str(ROOT), '-I/bench/stage4/development', str(ROOT / 'session-smoke.cpp'),
         '-L' + str(ROOT / 'lib'), '-L' + str(BUILD / 'meson-out'),
         '-Wl,-rpath-link,' + str(BUILD / 'meson-out'),
         '-L/opt/opk-deps/onnxruntime-arm64/lib',
         '-Wl,-rpath-link,/opt/opk-deps/onnxruntime-arm64/lib',
         '-l:opk-onnx-ops.so', '-l:opk-std-ops.so', '-lopk-common', '-lonnxruntime',
         '-o', str(ROOT / 'session-smoke')]
args = [arg.replace('/opt/opk-deps/onnxruntime-arm64', str(ROOT / 'onnxruntime-linux-aarch64-1.31.1')) for arg in args]
subprocess.run(args, cwd=BUILD, check=True)
