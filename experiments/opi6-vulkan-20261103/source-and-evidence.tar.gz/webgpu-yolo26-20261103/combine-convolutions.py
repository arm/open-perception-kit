"""Recombine exported pointwise Conv sums; preserve every weight value and graph output."""
from collections import defaultdict
import copy
import hashlib
import json
from pathlib import Path
import re

import numpy as np
import onnx
from onnx import numpy_helper

ROOT = Path('/bench/webgpu-yolo26-20261103')
CHANNEL_AXIS = 1
POINTWISE_KERNEL = (1, 1)


def combine(model):
    groups = defaultdict(list)
    for node in model.graph.node:
        match = re.fullmatch(r'(.+_split)\.(\d+)/Conv', node.name)
        if node.op_type == 'Conv' and match:
            groups[match[1]].append((int(match[2]), node))
    assert groups, 'No split convolution groups found'
    changes = []
    for name, numbered in groups.items():
        convolutions = [node for _, node in sorted(numbered)]
        assert [number for number, _ in sorted(numbered)] == list(range(len(convolutions)))
        initializers = {value.name: value for value in model.graph.initializer}
        attributes = [attribute.SerializeToString() for attribute in convolutions[0].attribute]
        weights = []
        for index, node in enumerate(convolutions):
            assert [attribute.SerializeToString() for attribute in node.attribute] == attributes
            assert all(attribute.i == 1 for attribute in node.attribute if attribute.name == 'group')
            assert len(node.input) == (3 if index == 0 else 2), 'Unexpected bias distribution'
            weight = numpy_helper.to_array(initializers[node.input[1]])
            assert weight.dtype == np.float32 and weight.shape[-2:] == POINTWISE_KERNEL
            weights.append(weight)
        assert len({weight.shape[0] for weight in weights}) == 1
        removed = {node.name for node in convolutions}
        frontier = {node.output[0] for node in convolutions}
        consumed = set()
        for node in model.graph.node:
            if node.op_type == 'Add' and len(node.input) == 2 and all(value in frontier for value in node.input):
                frontier.difference_update(node.input)
                consumed.update(node.input)
                frontier.add(node.output[0])
                removed.add(node.name)
        assert len(frontier) == 1 and len(removed) == 2 * len(convolutions) - 1
        result = frontier.pop()
        for node in model.graph.node:
            assert node.name in removed or not consumed.intersection(node.input), 'Intermediate has another consumer'
        assert not consumed.intersection(value.name for value in model.graph.output)
        combined_weight = np.concatenate(weights, axis=CHANNEL_AXIS)
        start = 0
        for weight in weights:
            stop = start + weight.shape[CHANNEL_AXIS]
            assert np.array_equal(combined_weight[:, start:stop], weight)
            start = stop
        weight_name = name + '_combined_weight'
        concat_name = name + '_combined_input'
        concat = onnx.helper.make_node('Concat', [node.input[0] for node in convolutions],
                                       [concat_name], name=name + '_Concat', axis=CHANNEL_AXIS)
        conv = onnx.helper.make_node('Conv', [concat_name, weight_name, convolutions[0].input[2]],
                                     [result], name=name + '_Conv')
        conv.attribute.extend(copy.deepcopy(convolutions[0].attribute))
        insertion = max(index for index, node in enumerate(model.graph.node) if node.name in removed)
        nodes = []
        for index, node in enumerate(model.graph.node):
            if node.name not in removed:
                nodes.append(node)
            if index == insertion:
                nodes.extend((concat, conv))
        del model.graph.node[:]
        model.graph.node.extend(nodes)
        removed_weights = {node.input[1] for node in convolutions}
        retained = [value for value in model.graph.initializer if value.name not in removed_weights]
        retained.append(numpy_helper.from_array(combined_weight, weight_name))
        del model.graph.initializer[:]
        model.graph.initializer.extend(retained)
        retained_info = [value for value in model.graph.value_info if value.name not in consumed]
        del model.graph.value_info[:]
        model.graph.value_info.extend(retained_info)
        changes.append({'group': name, 'convolutions_before': len(convolutions), 'convolutions_after': 1})
    onnx.checker.check_model(model, full_check=True)
    return changes


records = []
for name in ('yolo26n-320', 'yolo26s-640'):
    source = ROOT / 'models' / (name + '-fp32')
    descriptor = json.loads((source / 'model.json').read_text())
    original_path = source / descriptor['modelFile']
    model = onnx.load(original_path)
    original_outputs = [value.SerializeToString() for value in model.graph.output]
    changes = combine(model)
    assert [value.SerializeToString() for value in model.graph.output] == original_outputs
    destination = ROOT / 'models' / (name + '-combined-fp32')
    destination.mkdir(exist_ok=True)
    path = destination / 'model-combined.onnx'
    onnx.save(model, path)
    descriptor.pop('hfDownload')
    descriptor['name'] = destination.name
    descriptor['modelFile'] = path.name
    (destination / 'model.json').write_text(json.dumps(descriptor, indent=2) + '\n')
    chain = json.loads((source / 'opchain.json').read_text())
    chain['name'] = name.replace('-', '') + 'combined'
    chain['displayName'] = destination.name
    chain['description'] = 'Equivalent FP32 graph with summed pointwise convolutions recombined.'
    (destination / 'opchain.json').write_text(json.dumps(chain, indent=2) + '\n')
    records.append({'model': name, 'changes': changes,
                    'source_sha256': hashlib.sha256(original_path.read_bytes()).hexdigest(),
                    'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(ROOT / 'combined-manifest.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
