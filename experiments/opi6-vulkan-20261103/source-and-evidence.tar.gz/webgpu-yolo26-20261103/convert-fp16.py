"""Create explicitly labelled FP16 candidates with the official ORT converter."""
from collections import Counter
import hashlib
import json
from pathlib import Path

import onnx
from onnxconverter_common import float16

ROOT = Path('/bench/webgpu-yolo26-20261103')
SIZES = (320, 480, 640)
records = []
for family in ('n', 's'):
    for size in SIZES:
        name = f'yolo26{family}-{size}'
        source = ROOT / 'models' / (name + '-fp32')
        descriptor = json.loads((source / 'model.json').read_text())
        original_path = source / descriptor['modelFile']
        original = onnx.load(original_path)
        operators = Counter(node.op_type for node in original.graph.node)
        original_float_casts = {node.name for node in original.graph.node if node.op_type == 'Cast'
                               and any(attr.name == 'to' and attr.i == onnx.TensorProto.FLOAT
                                       for attr in node.attribute)}
        converted = float16.convert_float_to_float16(original, keep_io_types=False)
        # Converter 1.16 changes these tensor types but leaves the original Cast attribute intact.
        for node in converted.graph.node:
            if node.name in original_float_casts:
                for attribute in node.attribute:
                    if attribute.name == 'to':
                        attribute.i = onnx.TensorProto.FLOAT16
        # Keep internal feature outputs in FP16 even when later layers consume them.
        for value in (*converted.graph.input, *converted.graph.output):
            external = value.name
            internal = external + '_fp16_internal'
            for node in converted.graph.node:
                for names in (node.input, node.output):
                    for index, tensor in enumerate(names):
                        if tensor == external:
                            names[index] = internal
            for intermediate in converted.graph.value_info:
                if intermediate.name == external:
                    intermediate.name = internal
            is_input = any(item.name == external for item in converted.graph.input)
            cast = onnx.helper.make_node('Cast', [external if is_input else internal],
                                          [internal if is_input else external],
                                          name=external + '_boundary_cast',
                                          to=onnx.TensorProto.FLOAT16 if is_input else onnx.TensorProto.FLOAT)
            if is_input:
                converted.graph.node.insert(0, cast)
            else:
                converted.graph.node.append(cast)
            value.type.tensor_type.elem_type = onnx.TensorProto.FLOAT
        onnx.checker.check_model(converted, full_check=True)
        after = Counter(node.op_type for node in converted.graph.node)
        assert all(operators[op] == after[op] for op in ('Conv', 'MatMul', 'TopK'))
        assert all(value.type.tensor_type.elem_type == onnx.TensorProto.FLOAT
                   for value in (*converted.graph.input, *converted.graph.output))
        destination = ROOT / 'models' / (name + '-fp16')
        destination.mkdir(exist_ok=True)
        path = destination / 'model-fp16.onnx'
        onnx.save(converted, path)
        descriptor.pop('hfDownload')
        descriptor['name'] = name + '-fp16'
        descriptor['modelFile'] = path.name
        (destination / 'model.json').write_text(json.dumps(descriptor, indent=2) + '\n')
        records.append({'model': name, 'precision': 'FP16 with FP32 I/O and blocked ops',
                        'source_sha256': hashlib.sha256(original_path.read_bytes()).hexdigest(),
                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'operators': dict(after)})
(ROOT / 'fp16-manifest.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
