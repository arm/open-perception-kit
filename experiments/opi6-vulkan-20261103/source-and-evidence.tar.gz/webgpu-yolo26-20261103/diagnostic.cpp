#include "WebGpuProvider.h"
#include "YoloFrames.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <iostream>
#include <string_view>

namespace {
constexpr int RequiredArguments = 6;
constexpr int CpuIntraThreads = 11;
constexpr int CpuInterThreads = 1;
constexpr size_t WarmupFrames = 30;
constexpr size_t MinimumTimedFrames = 50;
constexpr double MinimumTimedMilliseconds = 10000.0;
constexpr double MillisecondsPerSecond = 1000.0;
constexpr double P95Fraction = 0.95;
using Clock = std::chrono::steady_clock;
using Milliseconds = std::chrono::duration<double, std::milli>;
constexpr size_t FullModelOutputCount = 6;
constexpr size_t FirstAuxiliaryOutput = 1;
constexpr float OutputAbsoluteTolerance = 1e-3F;
constexpr float OutputRelativeTolerance = 1e-3F;

float checkAuxiliaryOutputs(Ort::Env &environment,
                            const std::string &modelPath,
                            const char *const inputName,
                            const Ort::Value &input,
                            const std::vector<const char *> &outputNames,
                            const std::vector<Ort::Value> &actual) {
    Ort::SessionOptions cpuOptions;
    cpuOptions.SetIntraOpNumThreads(CpuIntraThreads);
    cpuOptions.SetInterOpNumThreads(CpuInterThreads);
    cpuOptions.SetGraphOptimizationLevel(ORT_ENABLE_ALL);
    Ort::Session cpuSession{environment, modelPath.c_str(), cpuOptions};
    const auto expected = cpuSession.Run(
        Ort::RunOptions{nullptr}, &inputName, &input, 1, outputNames.data(), outputNames.size());
    benchmark::require(actual.size() == expected.size(), "Output count mismatch");
    float maximumDifference = 0;
    // Decoded detections are checked across the full video by compare.py.
    for (size_t index = actual.size() == FullModelOutputCount ? FirstAuxiliaryOutput : 0;
         index < actual.size();
         ++index) {
        const auto count = expected[index].GetTensorTypeAndShapeInfo().GetElementCount();
        benchmark::require(actual[index].GetTensorTypeAndShapeInfo().GetElementCount() == count,
                           "Output shape mismatch");
        const auto *const reference = expected[index].GetTensorData<float>();
        const auto *const observed = actual[index].GetTensorData<float>();
        for (size_t value = 0; value < count; ++value) {
            const float difference = std::abs(observed[value] - reference[value]);
            maximumDifference = std::max(maximumDifference, difference);
            benchmark::require(difference <=
                                   OutputAbsoluteTolerance +
                                       OutputRelativeTolerance * std::abs(reference[value]),
                               "Bound output disagrees with CPU reference");
        }
    }
    return maximumDifference;
}

void checkFiniteOutputs(const std::vector<Ort::Value> &outputs) {
    for (const auto &output : outputs) {
        const auto count = output.GetTensorTypeAndShapeInfo().GetElementCount();
        const auto *const data = output.GetTensorData<float>();
        benchmark::require(
            std::all_of(data, data + count, [](const float value) { return std::isfinite(value); }),
            "Non-finite output");
    }
}

std::vector<Ort::Value> downloadOutputs(Ort::Env &environment,
                                        const std::vector<Ort::Value> &outputs) {
    Ort::AllocatorWithDefaultOptions allocator;
    std::vector<Ort::Value> downloaded;
    for (const auto &output : outputs) {
        benchmark::require(output.GetTensorMemoryInfo().GetDeviceType() ==
                               OrtMemoryInfoDeviceType_GPU,
                           "Output did not remain on GPU");
        const auto outputShape = output.GetTensorTypeAndShapeInfo().GetShape();
        downloaded.push_back(
            Ort::Value::CreateTensor<float>(allocator, outputShape.data(), outputShape.size()));
    }
    const auto copied = environment.CopyTensors(outputs, downloaded, nullptr);
    if (!copied.IsOK()) {
        throw std::runtime_error(copied.GetErrorMessage());
    }
    return downloaded;
}
} // namespace

int main(const int argc, const char *const *const argv) {
    try {
        benchmark::require(argc == RequiredArguments,
                           "Usage: diagnostic NV12.raw model.json host|bound capture validation");
        const bool bound = std::string_view{argv[3]} == "bound";
        benchmark::require(bound || std::string_view{argv[3]} == "host", "Invalid binding mode");
        const auto descriptor = opk::ModelDescriptor::fromFile(argv[2]);
        benchmark::require(bool(descriptor), "Invalid model descriptor");
        Ort::Env environment{ORT_LOGGING_LEVEL_WARNING, "webgpu-diagnostic"};
        Ort::SessionOptions options;
        options.SetIntraOpNumThreads(CpuIntraThreads);
        options.SetInterOpNumThreads(CpuInterThreads);
        options.SetGraphOptimizationLevel(ORT_ENABLE_ALL);
        configureBenchmarkProvider(environment, options);
        options.AddConfigEntry("ep.webgpuexecutionprovider.enableGraphCapture", argv[4]);
        options.AddConfigEntry("ep.webgpuexecutionprovider.validationMode", argv[5]);
        Ort::Session session{environment, descriptor->modelFile.c_str(), options};
        benchmark::require(session.GetInputCount() == 1, "Expected one image input");
        const auto type = session.GetInputTypeInfo(0);
        const auto info = type.GetTensorTypeAndShapeInfo();
        const auto shape = info.GetShape();
        benchmark::require(info.GetElementType() == ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT,
                           "Expected FP32 image input");
        opk::Model model;
        model.inputs.resize(session.GetInputCount());
        model.outputs.resize(session.GetOutputCount());
        model.inputs.front().shape.setFrom(shape);
        benchmark::require(bool(model.applyModelFromDescriptor(*descriptor)),
                           "Invalid image settings");
        benchmark::Frames frames{argv[1], model.inputs.front()};
        const auto inputNames = session.GetInputNames();
        const auto outputNames = session.GetOutputNames();
        std::vector<const char *> outputPointers;
        for (const auto &name : outputNames) {
            outputPointers.push_back(name.c_str());
        }
        const auto cpuMemory = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
        Ort::ConstMemoryInfo gpuMemory{nullptr};
        for (const auto &device : environment.GetEpDevices()) {
            if (std::string_view{device.EpName()} == "WebGpuExecutionProvider") {
                gpuMemory = device.GetMemoryInfo(OrtDeviceMemoryType_DEFAULT);
                break;
            }
        }
        Ort::Allocator gpuAllocator{nullptr};
        std::vector<Ort::Value> gpuInputs;
        std::vector<Ort::Value> gpuOutputs;
        Ort::IoBinding binding{session};
        if (bound) {
            benchmark::require(static_cast<const OrtMemoryInfo *>(gpuMemory) != nullptr,
                               "Provider did not expose GPU memory info");
            benchmark::require(gpuMemory.GetDeviceType() == OrtMemoryInfoDeviceType_GPU,
                               "Input was not assigned to GPU memory");
            gpuAllocator = Ort::Allocator{session, gpuMemory};
            gpuInputs.push_back(
                Ort::Value::CreateTensor<float>(gpuAllocator, shape.data(), shape.size()));
            binding.BindInput(inputNames.front().c_str(), gpuInputs.front());
            for (size_t index = 0; index < outputNames.size(); ++index) {
                const auto outputType = session.GetOutputTypeInfo(index);
                const auto outputShape = outputType.GetTensorTypeAndShapeInfo().GetShape();
                benchmark::require(
                    std::ranges::all_of(outputShape, [](const int64_t size) { return size > 0; }),
                    "GPU binding requires static output shapes");
                gpuOutputs.push_back(Ort::Value::CreateTensor<float>(
                    gpuAllocator, outputShape.data(), outputShape.size()));
                binding.BindOutput(outputNames[index].c_str(), gpuOutputs.back());
            }
        }
        float completionValue = 0;
        const std::array completionShape{int64_t{1}};
        Ort::Value completionSource{nullptr};
        auto completionTarget = Ort::Value::CreateTensor<float>(cpuMemory,
                                                                &completionValue,
                                                                completionShape.front(),
                                                                completionShape.data(),
                                                                completionShape.size());
        if (bound) {
            // A four-byte readback waits for the queue; native EP I/O synchronization alone did
            // not.
            completionSource =
                Ort::Value::CreateTensor(gpuMemory,
                                         gpuOutputs.front().GetTensorMutableRawData(),
                                         sizeof(completionValue),
                                         completionShape.data(),
                                         completionShape.size(),
                                         ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT);
        }
        std::vector<double> durations;
        std::vector<Ort::Value> outputs;
        double total = 0;
        size_t iteration = 0;
        while (iteration < WarmupFrames || durations.size() < MinimumTimedFrames ||
               total < MinimumTimedMilliseconds) {
            const auto input = frames.prepare(iteration % benchmark::FrameCount);
            auto tensor = Ort::Value::CreateTensor(cpuMemory,
                                                   const_cast<float *>(input.data()),
                                                   input.size(),
                                                   shape.data(),
                                                   shape.size());
            if (bound) {
                std::vector<Ort::Value> hostInputs;
                hostInputs.push_back(std::move(tensor));
                const auto copied = environment.CopyTensors(hostInputs, gpuInputs, nullptr);
                if (!copied.IsOK()) {
                    throw std::runtime_error(copied.GetErrorMessage());
                }
                binding.SynchronizeInputs();
            }
            const auto start = Clock::now();
            if (bound) {
                session.Run(Ort::RunOptions{nullptr}, binding);
                binding.SynchronizeOutputs();
                const auto completed =
                    environment.CopyTensor(completionSource, completionTarget, nullptr);
                if (!completed.IsOK()) {
                    throw std::runtime_error(completed.GetErrorMessage());
                }
            } else {
                const auto inputName = inputNames.front().c_str();
                outputs = session.Run(Ort::RunOptions{nullptr},
                                      &inputName,
                                      &tensor,
                                      1,
                                      outputPointers.data(),
                                      outputPointers.size());
            }
            const double elapsed = Milliseconds{Clock::now() - start}.count();
            if (iteration++ >= WarmupFrames) {
                durations.push_back(elapsed);
                total += elapsed;
            }
        }
        if (bound) {
            outputs = downloadOutputs(environment, binding.GetOutputValues());
            benchmark::require(completionValue == outputs.front().GetTensorData<float>()[0],
                               "Completion readback disagrees with output");
        }
        checkFiniteOutputs(outputs);
        const auto lastInput = frames.prepare((iteration - 1) % benchmark::FrameCount);
        auto lastTensor = Ort::Value::CreateTensor(cpuMemory,
                                                   const_cast<float *>(lastInput.data()),
                                                   lastInput.size(),
                                                   shape.data(),
                                                   shape.size());
        const char *const referenceModel = std::getenv("OPK_ORT_REFERENCE_MODEL");
        const float maximumDifference =
            checkAuxiliaryOutputs(environment,
                                  referenceModel ? referenceModel : descriptor->modelFile,
                                  inputNames.front().c_str(),
                                  lastTensor,
                                  outputPointers,
                                  outputs);
        std::ranges::sort(durations);
        std::cout << "{\"frames\":" << durations.size() << ",\"warmup_frames\":" << WarmupFrames
                  << ",\"inference_seconds\":" << total / MillisecondsPerSecond
                  << ",\"mean_ms\":" << total / durations.size() << ",\"p95_ms\":"
                  << durations[static_cast<size_t>(durations.size() * P95Fraction)]
                  << ",\"inferences_per_second\":"
                  << durations.size() * MillisecondsPerSecond / total
                  << ",\"max_auxiliary_output_difference\":" << maximumDifference
                  << ",\"completion_readback_bytes\":" << (bound ? sizeof(completionValue) : 0)
                  << ",\"gpu_bound_io\":" << (bound ? "true" : "false") << "}\n";
        return 0;
    } catch (const std::exception &error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
