"""Short provider and device-I/O checks before the long video matrix."""
import json
from pathlib import Path
import subprocess
import threading
import batch

samples = []
stopped = threading.Event()
def monitor():
    while not stopped.is_set():
        samples.append(batch.hardware())
        stopped.wait(batch.SAMPLE_SECONDS)
thread = threading.Thread(target=monitor)
thread.start()
result_path = batch.ROOT / 'diagnostic-results.json'
rows = json.loads(result_path.read_text()) if result_path.exists() else []
try:
    model = 'yolo26n-320-fp32'
    for io, capture, validation in (('host', '0', 'wgpuOnly'), ('host', '0', 'disabled'),
                                     ('bound', '0', 'disabled'), ('bound', '1', 'disabled')):
        label = f'diagnostic-{model}-{io}-capture{capture}-{validation}'
        if any(row['label'] == label for row in rows):
            continue
        batch.execute('gpu', [str(batch.ROOT / 'diagnostic'), batch.RAW,
                             str(batch.ROOT / 'models' / model / 'model.json'), io, capture, validation], label)
        log = (batch.ROOT / 'evidence' / (label + '.log')).read_text()
        values = [json.loads(line) for line in log.splitlines() if line.startswith('{"frames":')]
        assert len(values) == 1
        row = values[0] | {'label': label, 'model': model}
        assert row['frames'] >= batch.MINIMUM_FOCUSED_FRAMES
        rows.append(row)
        (batch.ROOT / 'diagnostic-results.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(json.dumps(row), flush=True)
finally:
    stopped.set()
    thread.join()
    (batch.ROOT / 'hardware-diagnostic.json').write_text(json.dumps(samples, indent=2) + '\n')
