"""Extract an explicitly labelled compute diagnostic, preserving every Conv/MatMul."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import onnx

ROOT = Path('/bench/webgpu-yolo26-20261103')
records = []
for name in ('yolo26n-320', 'yolo26s-640'):
    source = ROOT / 'models' / (name + '-fp32')
    descriptor = json.loads((source / 'model.json').read_text())
    original = onnx.load(source / descriptor['modelFile'])
    destination = ROOT / 'compute-subgraphs' / name
    destination.mkdir(parents=True, exist_ok=True)
    path = destination / 'compute.onnx'
    outputs = [value.name for value in original.graph.output][1:]
    onnx.utils.extract_model(str(source / descriptor['modelFile']), str(path),
                             [value.name for value in original.graph.input], outputs)
    extracted = onnx.load(path)
    onnx.checker.check_model(extracted)
    before = Counter(node.op_type for node in original.graph.node)
    after = Counter(node.op_type for node in extracted.graph.node)
    assert all(before[operator] == after[operator] for operator in ('Conv', 'MatMul'))
    assert after['TopK'] == 0
    weights = {value.name: value.SerializeToString() for value in original.graph.initializer}
    assert all(value.SerializeToString() == weights[value.name] for value in extracted.graph.initializer)
    descriptor.pop('hfDownload')
    descriptor['name'] = name + '-compute-subgraph'
    descriptor['modelFile'] = path.name
    (destination / 'model.json').write_text(json.dumps(descriptor, indent=2) + '\n')
    records.append({'model': name, 'diagnostic_only': True,
                    'removed_output': original.graph.output[0].name,
                    'retained_outputs': outputs, 'operators': dict(after),
                    'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(ROOT / 'compute-subgraphs' / 'manifest.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
