#include "YoloFrames.h"
#include "ops-onnx/Inference.h"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <iostream>
#include <numeric>

int main(const int argc, const char *const *const argv) {
    constexpr int RequiredArgumentCount = 3;
    constexpr size_t WarmupFrames = 30;
    constexpr size_t MinimumTimedFrames = 50;
    constexpr double MinimumTimedMilliseconds = 10000.0;
    constexpr double MillisecondsPerSecond = 1000.0;
    constexpr double P95Fraction = 0.95;
    using Clock = std::chrono::steady_clock;
    using Milliseconds = std::chrono::duration<double, std::milli>;
    try {
        benchmark::require(argc == RequiredArgumentCount, "Usage: focused NV12.raw model.json");
        opk::onnx::Inference inference;
        benchmark::require(bool(inference.setupFromJson(argv[2])), "Model setup failed");
        const auto &model = inference.getModel();
        benchmark::require(model.inputs.size() == 1, "Expected one image input");
        benchmark::Frames frames{argv[1], model.inputs.front()};
        std::vector<double> durations;
        double total = 0;
        size_t iteration = 0;
        while (iteration < WarmupFrames || durations.size() < MinimumTimedFrames ||
               total < MinimumTimedMilliseconds) {
            const auto input = frames.prepare(iteration % benchmark::FrameCount);
            std::memcpy(inference.getInputTensorDataAddress(0), input.data(), input.size_bytes());
            const auto start = Clock::now();
            benchmark::require(bool(inference.inference()), "Inference failed");
            const double elapsed = Milliseconds{Clock::now() - start}.count();
            if (iteration++ >= WarmupFrames) {
                durations.push_back(elapsed);
                total += elapsed;
            }
        }
        std::ranges::sort(durations);
        std::cout << "{\"frames\":" << durations.size() << ",\"warmup_frames\":" << WarmupFrames
                  << ",\"inference_seconds\":" << total / MillisecondsPerSecond
                  << ",\"mean_ms\":" << total / durations.size() << ",\"p95_ms\":"
                  << durations[static_cast<size_t>(durations.size() * P95Fraction)]
                  << ",\"inferences_per_second\":"
                  << durations.size() * MillisecondsPerSecond / total << "}\n";
        return 0;
    } catch (const std::exception &error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
