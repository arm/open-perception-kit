#!/bin/sh
set -eu
BENCH=/home/opi6/opk-webgpu-yolo26-20261103
MODE=$1
case "$MODE" in pilot|full|cpu|focused|diagnostic|resident|profile|tune|tune-large|optimization-video) ;; *) echo 'Expected pilot, full, cpu or diagnostic' >&2; exit 1 ;; esac
BACKUP="$BENCH/governors-$MODE-$(date +%s).txt"
test ! -e "$BACKUP"
for policy in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    printf '%s %s\n' "$policy" "$(cat "$policy")"
done > "$BACKUP"
for limit in /sys/class/devfreq/*/min_freq /sys/class/devfreq/*/max_freq; do
    printf '%s %s\n' "$limit" "$(cat "$limit")"
done >> "$BACKUP"
HEAP_GROUP=$(stat -c %g /dev/dma_heap/system)
HEAP_MODE=$(stat -c %a /dev/dma_heap/system)
restore() {
    while read -r path value; do printf '%s\n' "$value" > "$path"; done < "$BACKUP"
    chgrp "$HEAP_GROUP" /dev/dma_heap/system
    chmod "$HEAP_MODE" /dev/dma_heap/system
    printf 'Restored governors and DMA heap permissions\n'
}
trap restore EXIT HUP INT TERM
for policy in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    printf 'performance\n' > "$policy"
done
if [ "$MODE" != cpu ]; then
    for gpu in /sys/class/devfreq/*; do cat "$gpu/max_freq" > "$gpu/min_freq"; done
fi
chgrp render /dev/dma_heap/system
chmod 660 /dev/dma_heap/system
SCRIPT=batch.py
if [ "$MODE" = optimization-video ]; then SCRIPT=optimization-video.py; fi
if [ "$MODE" = diagnostic ]; then SCRIPT=diagnostics.py; fi
if [ "$MODE" = resident ]; then SCRIPT=resident-checks.py; fi
if [ "$MODE" = profile ]; then SCRIPT=profile-all.py; fi
if [ "$MODE" = tune ] || [ "$MODE" = tune-large ]; then SCRIPT=tune.py; fi
su -s /bin/sh opi6 -c "sh $BENCH/run.sh cpu /home/opi6/opk-expkits-1476-vulkan-20261028/runtime/bin/python3.13 $BENCH/$SCRIPT $MODE > $BENCH/run-$MODE.log 2>&1"
