"""Count convolution arithmetic from inferred tensor shapes, without estimating latency."""
from collections import Counter
import json
import math
from pathlib import Path
import onnx

ROOT = Path('/bench/webgpu-yolo26-20261103')
records = {}
for name in ('yolo26n-320', 'yolo26s-640'):
    directory = ROOT / 'models' / (name + '-fp32')
    descriptor = json.loads((directory / 'model.json').read_text())
    model = onnx.shape_inference.infer_shapes(onnx.load(directory / descriptor['modelFile']))
    shapes = {value.name: [dimension.dim_value for dimension in value.type.tensor_type.shape.dim]
              for value in (*model.graph.input, *model.graph.value_info, *model.graph.output)}
    shapes.update({value.name: list(value.dims) for value in model.graph.initializer})
    operators = Counter()
    operations = Counter()
    unknown_outputs = []
    for node in model.graph.node:
        if node.op_type != 'Conv':
            continue
        weight = shapes[node.input[1]]
        output = shapes[node.output[0]]
        assert len(weight) == len(output) == 4 and all(value > 0 for value in weight)
        kernel = f'{weight[2]}x{weight[3]}'
        operators[kernel] += 1
        if not all(value > 0 for value in output):
            unknown_outputs.append(node.name)
            continue
        # A multiply and add count as two operations; bias/activation are excluded.
        operations[kernel] += 2 * math.prod(output) * math.prod(weight[1:])
    assert sum(operators.values()) == 127
    records[name] = {'convolution_count_by_kernel': dict(operators),
                     'convolution_operations_by_kernel': dict(operations),
                     'known_shape_convolution_operations': sum(operations.values()),
                     'unknown_output_shape_nodes': unknown_outputs}
(ROOT / 'convolution-work.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
