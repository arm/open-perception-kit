#!/bin/sh
set -eu
BENCH=/home/opi6/opk-webgpu-yolo26-20261103
MODE=$1
case "$MODE" in control|screen|profile|verify|matrix|clock-600|clock-800|clock-1000|clock-large-600|clock-large-1000|cpu-low) ;; *) echo 'Expected control, screen, profile, verify or matrix' >&2; exit 1 ;; esac
BACKUP="$BENCH/mali-tiling-20261103/governors-$MODE-$(date +%s).txt"
test ! -e "$BACKUP"
for policy in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    printf '%s %s\n' "$policy" "$(cat "$policy")"
done > "$BACKUP"
for limit in /sys/devices/system/cpu/cpufreq/policy*/scaling_min_freq /sys/devices/system/cpu/cpufreq/policy*/scaling_max_freq /sys/class/devfreq/*/min_freq /sys/class/devfreq/*/max_freq; do
    printf '%s %s\n' "$limit" "$(cat "$limit")"
done >> "$BACKUP"
HEAP_GROUP=$(stat -c %g /dev/dma_heap/system)
HEAP_MODE=$(stat -c %a /dev/dma_heap/system)
restore() {
    while read -r path value; do printf '%s\n' "$value" > "$path"; done < "$BACKUP"
    chgrp "$HEAP_GROUP" /dev/dma_heap/system
    chmod "$HEAP_MODE" /dev/dma_heap/system
    printf 'Restored governors and DMA heap permissions\n'
}
trap restore EXIT HUP INT TERM
for policy in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    printf 'performance\n' > "$policy"
done
if [ "$MODE" = cpu-low ]; then
    for policy in /sys/devices/system/cpu/cpufreq/policy*; do
        cat "$policy/scaling_min_freq" > "$policy/scaling_max_freq"
    done
fi
for gpu in /sys/class/devfreq/*; do
    case "$MODE" in
        clock-600|clock-large-600) BENCH_GPU_HZ=600000000 ;;
        clock-800) BENCH_GPU_HZ=800000000 ;;
        *) BENCH_GPU_HZ=$(cat "$gpu/max_freq") ;;
    esac
    printf '%s\n' "$BENCH_GPU_HZ" > "$gpu/min_freq"
    printf '%s\n' "$BENCH_GPU_HZ" > "$gpu/max_freq"
done
chgrp render /dev/dma_heap/system
chmod 660 /dev/dma_heap/system
SCRIPT="$BENCH/mali-tiling-20261103/run-experiments.py"
su -s /bin/sh opi6 -c "sh $BENCH/mali-tiling-20261103/run.sh cpu /home/opi6/opk-expkits-1476-vulkan-20261028/runtime/bin/python3.13 $SCRIPT $MODE > $BENCH/mali-tiling-20261103/run-$MODE.log 2>&1"
