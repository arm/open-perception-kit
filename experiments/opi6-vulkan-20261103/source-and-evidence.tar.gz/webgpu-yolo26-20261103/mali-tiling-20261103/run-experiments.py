"""Measure private kernel candidates with the existing video-input diagnostic."""
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
sys.path.insert(0, str(BASE))
import batch

batch.ROOT = ROOT
TILES = ("8x8-r1", "8x8-r2", "8x16-r1", "8x16-r2", "8x4-r2")
ENDPOINTS = ("yolo26n-320", "yolo26s-640")
PLUGINS = {
    "package": BASE / "libonnxruntime_providers_webgpu.so",
    "control": ROOT / "lib" / "control" / "libonnxruntime_providers_webgpu.so",
    "candidate": ROOT / "lib" / "candidate" / "libonnxruntime_providers_webgpu.so",
}


def cases(mode):
    if mode in ("clock-large-600", "clock-large-1000"):
        return [(ENDPOINTS[1], "package", None)]
    if mode in ("cpu-low", "clock-600", "clock-800", "clock-1000"):
        return [(ENDPOINTS[0], "package", None)]
    if mode == "control":
        return [(model, plugin, None) for model in ENDPOINTS for plugin in ("package", "control")]
    if mode == "screen":
        return [(ENDPOINTS[0], "candidate", tile) for tile in (None, *TILES)]
    if mode == "profile":
        return [(ENDPOINTS[0], "candidate", tile) for tile in (None, *TILES)]
    raise ValueError("Unsupported experiment mode: " + mode)


def measure(mode, model, plugin, tile):
    label = "mali-" + "-".join((mode, model, plugin, tile or "generic"))
    result_path = ROOT / "evidence" / (label + ".json")
    with PLUGINS[plugin].open("rb") as binary:
        plugin_sha256 = hashlib.file_digest(binary, "sha256").hexdigest()
    if result_path.exists():
        row = json.loads(result_path.read_text())
        assert row["plugin_sha256"] == plugin_sha256, "Plugin changed under saved result: " + label
        return row
    settings = {"OPK_ORT_PLUGIN_LIBRARY": str(PLUGINS[plugin])}
    if tile:
        settings["ORT_WEBGPU_MALI_TILE"] = tile
    directory = BASE / "models" / (model + "-fp32")
    if mode == "profile":
        settings["ORT_WEBGPU_GPU_PROFILE"] = "1"
        settings["OPK_ORT_PROFILE"] = str(ROOT / "evidence" / label)
        descriptor = json.loads((directory / "model.json").read_text())
        arguments = [str(BASE / "session-smoke"), str(directory / descriptor["modelFile"])]
    else:
        arguments = [str(BASE / "diagnostic"), batch.RAW, str(directory / "model.json"),
                     "host", "0", "disabled"]
    batch.ENVIRONMENT.update(settings)
    try:
        batch.execute("gpu", arguments, label)
    finally:
        for key in settings:
            del batch.ENVIRONMENT[key]
    log = (ROOT / "evidence" / (label + ".log")).read_text()
    if mode == "profile":
        timing_lines = [line for line in log.splitlines() if line.startswith("MALI_GPU_US\t")]
        assert timing_lines, "No GPU timestamps: " + label
        assert not tile or "Selected Mali FP32 tile " + tile in log, label
        values = {"gpu_timing_records": len(timing_lines)}
    else:
        records = [json.loads(line) for line in log.splitlines() if line.startswith('{"frames":')]
        assert len(records) == 1, label
        values = records[0]
        assert values["frames"] >= batch.MINIMUM_FOCUSED_FRAMES
        assert values["inference_seconds"] >= batch.MINIMUM_FOCUSED_SECONDS
    row = values | {"label": label, "model": model, "plugin": plugin, "tile": tile,
                    "plugin_sha256": plugin_sha256}
    result_path.write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    return row


def main():
    mode = sys.argv[1]
    (ROOT / "evidence").mkdir(exist_ok=True)
    samples = []
    stopped = threading.Event()

    def monitor():
        while not stopped.is_set():
            samples.append(batch.hardware())
            stopped.wait(batch.SAMPLE_SECONDS)

    thread = threading.Thread(target=monitor)
    thread.start()
    rows = []
    try:
        for model, plugin, tile in cases(mode):
            rows.append(measure(mode, model, plugin, tile))
            (ROOT / (mode + "-results.json")).write_text(json.dumps(rows, indent=2) + "\n")
            time.sleep(batch.COOLDOWN_SECONDS)
    finally:
        stopped.set()
        thread.join()
        (ROOT / ("hardware-" + mode + ".json")).write_text(json.dumps(samples, indent=2) + "\n")


if __name__ == "__main__":
    main()
