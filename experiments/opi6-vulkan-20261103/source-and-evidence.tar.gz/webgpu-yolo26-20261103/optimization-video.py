"""Validate the screened graph/precision candidates on every original video frame."""
import json
import threading
import time
import batch
from compare import compare_labels

MODELS = ('yolo26n-320', 'yolo26s-640')
VARIANTS = ('combined-fp32', 'fp16')
samples = []
stopped = threading.Event()
def monitor():
    while not stopped.is_set():
        samples.append(batch.hardware())
        stopped.wait(batch.SAMPLE_SECONDS)
thread = threading.Thread(target=monitor)
thread.start()
rows = []
agreement = {}
try:
    for name in MODELS:
        for variant in VARIANTS:
            label = f'optimized-{name}-{variant}'
            row = batch.video(name + '-' + variant, 'gpu', label, 'validate')
            rows.append(row)
            (batch.ROOT / 'optimization-video-results.json').write_text(json.dumps(rows, indent=2) + '\n')
            result = compare_labels(name + '-cpu-validate', label)
            agreement[label] = result
            (batch.ROOT / 'optimization-accuracy.json').write_text(json.dumps(agreement, indent=2) + '\n')
            print(label, json.dumps(result['detection_agreement']), flush=True)
            if variant == 'combined-fp32':
                assert result['detection_agreement']['within_detection_tolerance']
            time.sleep(batch.COOLDOWN_SECONDS)
finally:
    stopped.set()
    thread.join()
    (batch.ROOT / 'hardware-optimization-video.json').write_text(json.dumps(samples, indent=2) + '\n')
