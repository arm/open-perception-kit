"""Record operator placement separately from throughput measurements."""
import json
from pathlib import Path
import subprocess
import batch

for name in batch.MODELS:
    folder = batch.ROOT / 'models' / (name + '-fp32')
    descriptor = json.loads((folder / 'model.json').read_text())
    for provider in ('cpu', 'gpu'):
        label = 'placement-' + name + '-' + provider
        environment = batch.ENVIRONMENT | {'OPK_ORT_PROFILE': str(batch.ROOT / 'evidence' / label)}
        with (batch.ROOT / 'evidence' / (label + '.log')).open('w') as log:
            subprocess.run(['/bin/sh', str(batch.ROOT / 'run.sh'), provider,
                            str(batch.ROOT / 'session-smoke'), str(folder / descriptor['modelFile'])],
                           env=environment, stdout=log, stderr=subprocess.STDOUT,
                           timeout=batch.TRIAL_TIMEOUT_SECONDS, check=True)
        print('Profiled ' + name + ' ' + provider, flush=True)
