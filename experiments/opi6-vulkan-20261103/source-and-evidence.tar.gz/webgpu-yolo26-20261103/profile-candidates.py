"""Check candidate GPU placement separately from performance runs."""
import json
import batch

for name in ('yolo26n-320', 'yolo26s-640'):
    for variant in ('combined-fp32', 'fp16'):
        directory = batch.ROOT / 'models' / (name + '-' + variant)
        descriptor = json.loads((directory / 'model.json').read_text())
        label = 'placement-optimized-' + name + '-' + variant
        batch.ENVIRONMENT['OPK_ORT_PROFILE'] = str(batch.ROOT / 'evidence' / label)
        batch.execute('gpu', [str(batch.ROOT / 'session-smoke'),
                              str(directory / descriptor['modelFile'])], label)
