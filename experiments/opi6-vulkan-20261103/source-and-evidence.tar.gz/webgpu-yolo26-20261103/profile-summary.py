"""Execution placement and host-side trace timings; these are not GPU shader timestamps."""
from collections import Counter, defaultdict
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
PROFILE_ITERATIONS = 10
MICROSECONDS_PER_MILLISECOND = 1000


def summarize(path):
    events = json.loads(path.read_text())
    nodes = [event for event in events if event.get('cat') == 'Node' and event.get('args', {}).get('provider')]
    runs = [event for event in events if event.get('name') == 'model_run']
    assert runs and nodes, path
    unique = {(event['args']['provider'], event['args']['node_index']):
              {'name': event['name'], 'operator': event['args']['op_name'], 'provider': event['args']['provider']}
              for event in nodes}
    placement = Counter(node['provider'] for node in unique.values())
    heavy = defaultdict(Counter)
    for node in unique.values():
        if node['operator'] in ('Conv', 'FusedConv', 'MatMul', 'Gemm'):
            heavy[node['operator']][node['provider']] += 1
    timing = defaultdict(list)
    for run in runs[1:]:
        totals = Counter()
        for event in nodes:
            if run['ts'] <= event['ts'] and event['ts'] + event['dur'] <= run['ts'] + run['dur']:
                totals[event['args']['provider'] + '/' + event['args']['op_name']] += event['dur'] / MICROSECONDS_PER_MILLISECOND
        for category, duration in totals.items():
            timing[category].append(duration)
    return {'profile_iterations': len(runs), 'trace_categories': dict(Counter(event.get('cat') for event in events)),
            'unique_node_placement': dict(placement), 'heavy_operator_placement': dict(heavy),
            'cpu_nodes': [node for node in unique.values() if node['provider'] == 'CPUExecutionProvider'],
            'median_model_run_ms_after_first': statistics.median(run['dur'] / MICROSECONDS_PER_MILLISECOND for run in runs[1:]) if len(runs) > 1 else None,
            'median_host_trace_ms_by_provider_operator': {category: statistics.median(values) for category, values in timing.items()},
            'warning': 'Host node durations include asynchronous queue submission and waits. They are not isolated GPU shader timings.'}


def main():
    profiles = {}
    for variant in ('n', 's'):
        for size in (320, 480, 640):
            name = f'yolo26{variant}-{size}'
            for provider in ('cpu', 'gpu'):
                paths = list((ROOT / 'evidence').glob(f'placement-{name}-{provider}_*.json'))
                assert len(paths) == 1, (name, provider, paths)
                row = summarize(paths[0])
                assert row['profile_iterations'] == PROFILE_ITERATIONS
                if provider == 'gpu':
                    assert row['heavy_operator_placement']['Conv'] == {'WebGpuExecutionProvider': 127}
                    assert row['heavy_operator_placement']['MatMul'] == {'WebGpuExecutionProvider': 4}
                profiles[name + '/' + provider] = row
    (ROOT / 'placement-summary.json').write_text(json.dumps(profiles, indent=2) + '\n')
    for name, row in profiles.items():
        print(name, row['unique_node_placement'])


if __name__ == '__main__':
    main()
