#include <onnxruntime_cxx_api.h>

#include <cstring>
#include <iostream>
#include <stdexcept>

int main(const int argc, const char *const *const argv) {
    constexpr int RequiredArgumentCount = 2;
    try {
        if (argc != RequiredArgumentCount) {
            throw std::runtime_error("Usage: provider-probe plugin-library");
        }
        std::cout << "ONNX Runtime " << OrtGetApiBase()->GetVersionString() << '\n';
        Ort::Env environment{ORT_LOGGING_LEVEL_INFO, "webgpu-probe"};
        environment.RegisterExecutionProviderLibrary("webgpu", argv[1]);
        bool found = false;
        for (const auto &device : environment.GetEpDevices()) {
            const auto hardware = device.Device();
            std::cout << device.EpName() << " vendor=" << hardware.Vendor()
                      << " vendorId=" << hardware.VendorId() << " deviceId=" << hardware.DeviceId()
                      << " type=" << hardware.Type() << '\n';
            found = found || std::strcmp(device.EpName(), "WebGpuExecutionProvider") == 0;
        }
        if (!found) {
            throw std::runtime_error("Native WebGPU provider did not register a device");
        }
        return 0;
    } catch (const std::exception &error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
