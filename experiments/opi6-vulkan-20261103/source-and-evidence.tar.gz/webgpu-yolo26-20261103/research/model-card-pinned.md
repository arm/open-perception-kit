---
license: agpl-3.0
pipeline_tag: object-detection
library_name: onnxruntime
tags:
  - arm
  - arm-optimized
  - edge-linux
  - onnx
  - onnxruntime
  - int8
base_model: Ultralytics/YOLO26
base_model_relation: quantized
---

# YOLO26n (320x320) optimized for Arm-based Edge Linux systems

An INT8-quantized version of yolo26n for object detection, exported to ONNX (`.onnx`) and optimized for Arm-based Edge Linux systems, evaluated at a reduced 320x320 input resolution.

## Summary

This repository contains an Arm-optimized version of yolo26n for object detection, evaluated at a 320x320 input resolution. YOLO26n is Ultralytics' NMS-free, end-to-end object detector with a one2one Detect head: predictions are already deduplicated internally, so no separate non-maximum-suppression pass is required at inference time. The model is provided in ONNX (`.onnx`) format and run with ONNX Runtime, targeting Edge Linux systems.

The detection head is quantized like the rest of the network rather than being kept in FP32.

This version is intended to demonstrate efficient inference on Arm-based platforms while preserving the original model's intended behavior. Arm has evaluated this model on COCO 2017 and measured performance on a representative evaluation target.

**Key results**

| Area | Result |
|---|---|
| Model format | ONNX (`.onnx`) |
| Target device class | Edge Linux |
| Reference device | Raspberry Pi 5 (Cortex-A76, linux Raspberry Pi OS 64-bit based on Debian 13 "Trixie") |
| Primary performance result | p50 latency 36.831 ms (1.01x faster than baseline), 27.15 frames per second |
| Accuracy result | mAP@0.5:0.95 29.31%, mAP@0.5 42.21% |
| Size / memory result | 3.941 MB (2.37x smaller), peak memory 91.20 MB |

## Original model

| Field | Value |
|---|---|
| Original model | yolo26n |
| Original source | Hugging Face |
| Original developer | Ultralytics |
| Original model card | [Ultralytics/YOLO26](https://huggingface.co/Ultralytics/YOLO26) |
| Original license | [AGPL-3.0](https://www.gnu.org/licenses/agpl-3.0.en.html) |

## Model files

| File | Description |
|---|---|
| `yolo26n_raspberry_onnx_optimized.onnx` | Arm-optimized INT8 model for deployment |
| `example.py` | Minimal inference example |
| `pyproject.toml` | Pinned runtime dependencies for `example.py`, resolved with uv |
| `uv.lock` | Locked dependency resolution for `pyproject.toml` |
| `config.yaml` | Model I/O contract used by the example |
| `benchmarks/` | FP32 baseline and Arm-optimized benchmark records |

## Performance

Performance was measured on the reference configuration below. Results are intended to make the optimization reproducible but do not guarantee identical performance on every Arm-based system.

**Reference configuration**

| Field | Value |
|---|---|
| Device / platform | Raspberry Pi 5 |
| CPU | Cortex-A76, 4 cores, arm64 |
| OS | linux, Raspberry Pi OS 64-bit based on Debian 13 "Trixie" |
| Runtime | ONNX Runtime 1.29.0 |
| Execution backend | CPU execution provider (MLAS, KleidiAI) |
| Threads | 4 |
| Precision | INT8 static, symmetric — 8-bit per-channel weights, 8-bit activations |
| Batch size | 1 |
| Input resolution | 320x320 |
| Runs / warmup | 100 / 100 |

**Performance results**

| Metric | Original / baseline | Arm-optimized | Improvement |
|---|---:|---:|---:|
| Model size (MB) | 9.327 | 3.941 | 2.37x smaller |
| End-to-end latency p50 (ms) | 37.356 | 36.831 | 1.01x faster |
| End-to-end latency p90 (ms) | 38.770 | 40.685 | 0.95x (slower) |
| End-to-end latency p99 (ms) | 45.393 | 45.063 | 1.01x faster |
| Time to first inference (ms) | 29.103 | 31.004 | 0.94x (slower) |
| Model load time (ms) | 88.519 | 315.391 | 0.28x (slower) |
| Frames per second | 26.77 | 27.15 | 1.01x |
| Peak memory (MB) | 82.73 | 91.20 | 0.91x (more) |
| Average memory (MB) | 82.67 | 91.16 | 0.91x (more) |

## Accuracy

Accuracy was evaluated using the same preprocessing, input resolution, and evaluation protocol described below. Where possible, the optimized model is compared against the original model under the same evaluation conditions.

**Evaluation setup**

| Field | Value |
|---|---|
| Dataset | COCO 2017 |
| Split | val2017 |
| Sample count | 5000 |
| Metric(s) | mAP@0.5:0.95, mAP@0.5, mAP@0.75 |
| Confidence threshold | 0.001 (keeps the full precision-recall curve) |
| Runtime | ONNX Runtime 1.29.0 (CPU execution provider) |

**Accuracy results**

| Metric | Original / baseline | Arm-optimized | Change |
|---|---:|---:|---:|
| mAP@0.5:0.95 (%) | 29.83 | 29.31 | -0.52 pp |
| mAP@0.5 (%) | 42.78 | 42.21 | -0.57 pp |
| mAP@0.75 (%) | 31.68 | 31.29 | -0.39 pp |

Accuracy was measured using the evaluation setup described above. Users should re-evaluate the model on their own data before production use.

## Arm optimization approach

Arm optimized this model for efficient inference on Arm-based platforms using a hardware-aware conversion and validation flow.

For this release, Arm used:

| Optimization area | Applied? | Notes |
|---|---|---|
| Model conversion | Yes | Converted to ONNX `.onnx` |
| Quantization | Yes | INT8 static symmetric, per-channel weights, calibrated on 300 randomly selected COCO 2017 samples; the detection head is quantized like the rest of the network |
| Runtime/backend selection | Yes | ONNX Runtime CPU execution provider with MLAS and KleidiAI |
| Graph/runtime compatibility updates | Yes | Performed as part of the shared PT2E export pipeline, with ONNX-specific graph translation |
| Accuracy validation | Yes | Compared against the original model or published baseline |
| Performance validation | Yes | Measured on the reference Arm platform |

The goal of this process is to improve deployment characteristics such as latency, memory use, model size, and runtime compatibility while preserving the model's intended behavior. Detailed conversion scripts, calibration configuration, or backend-specific implementation details may be provided separately where appropriate.

## Using this model

### Install dependencies

Dependencies are declared in `pyproject.toml`, which ships with this repository. Resolve and install them into a local virtual environment with uv:

```bash
uv python install
uv sync --frozen
```

### Run the example

```bash
uv run example.py
```

### Expected input

| Property | Value |
|---|---|
| Input shape | [1, 3, 320, 320] |
| Input type | float32 |
| Input range | [0.0, 1.0] |
| Preprocessing | letterbox to 320x320 (aspect-preserving, centered), pad value 114 (gray fill), to tensor with no mean/std normalization |

### Expected output

| Property | Value |
|---|---|
| Output shape | [1, 300, 6] |
| Output type | 300 pre-deduplicated one2one detections; 4 box coordinates (xyxy, pixel-space in the 320x320 letterboxed frame) + 1 score + 1 class index, already top-k selected by the head |
| Postprocessing | confidence threshold 0.4, no non-maximum suppression (the head already deduplicates predictions), boxes mapped back to original image coordinates (letterbox padding removed and rescaled) |

## Intended use

This model is intended for developers evaluating object detection workloads on Arm-based platforms. It is suitable as a reference implementation for benchmarking, prototyping, and integration exploration.

## Limitations

- Accuracy was evaluated on COCO 2017 val2017 (5000 samples) and may not generalize to all domains.
- The model expects a fixed 320x320 input; other resolutions, including the 640x640 resolution used by the standard-resolution release of this model, require re-export.
- Performance measurements are from Raspberry Pi 5 hardware; results may differ on other Arm devices.

## Additional notes

YOLO26n detects the 80 COCO object categories at a fixed 320x320 input resolution using its NMS-free one2one head — a reduced-resolution variant of the same recipe validated at 640x640. The quantized artifact keeps the same architecture and parameter count as the source weights; only numeric precision (and the input resolution) changes.

The bundled `example.py` reads `sample_input.jpg` and writes an annotated `sample_output.jpg` plus a `detections.json` file beside itself.

The sample input `sample_input.jpg` is derived from [Living room (Unsplash)](https://commons.wikimedia.org/wiki/File:Living_room_%28Unsplash%29.jpg) by Jarosław Ceborski, via Wikimedia Commons ([CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)).

## About this version

Original Model:
YOLO26n by Ultralytics - [Repository](https://huggingface.co/Ultralytics/YOLO26)

Optimization/conversion:
Arm-Optimized version for execution on Arm-based platforms.

Converted/optimized by:
Arm

License:
The Original Model and the Optimized Model are subject to [AGPL-3.0](https://huggingface.co/datasets/choosealicense/licenses/blob/main/markdown/agpl-3.0.md).

This repository contains a converted or optimized version of the Original Model (the “Optimized Model”). The Original Model has been converted or optimized as described above for execution on Arm-based platforms.

No retraining or fine-tuning of the Original Model was performed as part of the conversion or optimization. The conversion or optimization was not intended to change the Original Model’s behavior or intended use.

### Original Model and Documentation

For information about the Original Model, including its development, training data, intended uses, limitations and other relevant information, please refer to the [Original Model repository](https://huggingface.co/Ultralytics/YOLO26). Information in that repository was provided by the original developer or other third parties and, unless expressly stated otherwise, has not been independently verified by Arm.

### Licenses and Third-Party Terms

Use of the Original Model and the Optimized Model is subject to the applicable licenses, usage restrictions and other terms identified above and in the relevant repositories. Publication of the Optimized Model does not grant any rights beyond those provided under the applicable license terms.

You are responsible for reviewing those terms and ensuring that your use of the Original Model and the Optimized Model is permitted.

### Purpose of this Release

The Optimized Model is provided as a reference implementation to demonstrate and evaluate execution and performance on Arm-based systems. It is not a production-ready or supported solution.

Arm’s publication of the Optimized Model does not constitute an endorsement or certification of the Original Model or a representation that the Optimized Model is suitable for production use or any particular purpose.

To the fullest extent permitted by applicable law (i) the Optimized Model is provided “as is.” Arm makes no representations or warranties that the Original Model, the Optimized Model or their outputs are accurate, safe, secure, non-infringing, legally compliant, suitable for production use or fit for any particular purpose; and (ii) Arm will not be liable for any loss or damage arising from or in connection with the Optimized Model, its use or its outputs.

You are responsible for independently evaluating the Optimized Model, its outputs and its suitability for your intended use, including compliance with applicable legal, regulatory, safety and security requirements.

Arm does not commit to provide ongoing support, maintenance or updates for the Optimized Model. Any use of or reliance on the Optimized Model or its outputs is at your own risk.

## Use of Ultralytics models

Ultralytics provides Ultralytics YOLO software and models available through the Arm AI Portal and/or Arm's Hugging Face Organization under the GNU Affero General Public License v3.0 ("AGPL-3.0"), unless you have entered into a separate written license agreement with Ultralytics. Accessing, downloading, or retraining these materials through Arm AI Portal does not grant you an Ultralytics Enterprise License or any other proprietary Ultralytics license.

AGPL-3.0 requires you to release the complete source code of any application that uses Ultralytics YOLO, including applications made available over a network, under the same license. If you are embedding YOLO in a commercial product, internal tool, or production deployment and cannot open-source your code, you need an Ultralytics Enterprise License.

You are responsible for determining which applies to your use. Terms and enterprise licensing options are available at [ultralytics.com](https://www.ultralytics.com/license?utm_source=arm&utm_medium=referral&utm_content=license_notice_message).
