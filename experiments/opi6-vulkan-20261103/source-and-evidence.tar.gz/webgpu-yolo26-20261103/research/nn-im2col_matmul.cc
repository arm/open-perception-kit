// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
#include <string>
#include <utility>
#include <vector>

#include "core/providers/webgpu/webgpu_utils.h"
#include "core/providers/webgpu/nn/im2col_matmul.h"
#include "core/providers/webgpu/nn/conv.h"
#include "core/providers/webgpu/nn/activation_util.h"
#include "core/providers/webgpu/tensor/transpose.h"

namespace onnxruntime {
namespace webgpu {
namespace {
// Chooses the optimal tile size (M, N) for the im2col operation.
// This tile size is performance-tuned and varies depending on the target device.
std::pair<uint32_t, uint32_t> ChooseTileSize(uint32_t im2col_m, uint32_t im2col_n) {
  // Define a list of preferred (tile_m, tile_n) pairs in descending order of preference.
  const std::vector<std::pair<uint32_t, uint32_t>> kTileSizes = {
      std::make_pair(32, 64),
      std::make_pair(16, 64),
  };

  for (const auto& tile_pair : kTileSizes) {
    const uint32_t tile_m = tile_pair.first;
    const uint32_t tile_n = tile_pair.second;

    const uint32_t dispatch_m = CeilDiv(im2col_m, tile_m);
    const uint32_t dispatch_n = CeilDiv(im2col_n, tile_n);
    const uint32_t dispatch = dispatch_m * dispatch_n;

    if (dispatch >= 128) {
      return tile_pair;
    }
  }

  // If none of the tile sizes meet the dispatch >=128 requirement,
  return kTileSizes.back();
}

// Add support for more devices.
bool IsDeviceSupported(const ComputeContextBase& context) {
  const wgpu::AdapterInfo& adapter_info = context.AdapterInfo();

  if (adapter_info.vendor == std::string_view("intel")) {
    if (adapter_info.architecture == std::string_view("xe-2lpg") ||
        adapter_info.architecture == std::string_view("xe-2hpg") ||
        adapter_info.architecture == std::string_view("xe-3lpg") ||
        adapter_info.architecture == std::string_view("xe-3lpg-xs")) {
      return true;
    }
  }

  return false;
}

// Keep this list synchronized with the activation_kind branches in the WGSL template.
bool IsActivationSupported(const Activation& activation) {
  switch (activation.activation_kind_) {
    case ActivationKind::None:
    case ActivationKind::Relu:
    case ActivationKind::Sigmoid:
    case ActivationKind::Clip:
    case ActivationKind::HardSigmoid:
    case ActivationKind::LeakyRelu:
    case ActivationKind::Tanh:
    case ActivationKind::QuickGelu:
      return true;
    default:
      return false;
  }
}

// The weight layout consumed by Im2ColMatMulProgram: OIHW -> OHWI.
const InlinedVector<size_t>& OihwToOhwiPerm() {
  static const InlinedVector<size_t> perm = {0, 2, 3, 1};
  return perm;
}

}  // namespace

Status PrePackIm2ColMatMulWeight(ComputeContextBase& context,
                                 const Tensor& weight,
                                 AllocatorPtr alloc,
                                 std::unique_ptr<Tensor>& packed_weight) {
  const TensorShape& weight_shape = weight.Shape();
  ORT_RETURN_IF_NOT(weight_shape.NumDimensions() == 4, "Im2ColMatMul weight must be 4D (OIHW).");

  TensorShape ohwi_shape({weight_shape[0], weight_shape[2], weight_shape[3], weight_shape[1]});
  packed_weight = std::make_unique<Tensor>(weight.DataType(), ohwi_shape, alloc);
  return Transpose::DoTranspose(context, OihwToOhwiPerm(), weight, *packed_weight);
}

// The template dispatches on the numeric enum values.
static_assert(static_cast<int>(ActivationKind::None) == 0, "im2col_matmul.wgsl.template mirrors ActivationKind");
static_assert(static_cast<int>(ActivationKind::Relu) == 1, "im2col_matmul.wgsl.template mirrors ActivationKind");
static_assert(static_cast<int>(ActivationKind::Sigmoid) == 2, "im2col_matmul.wgsl.template mirrors ActivationKind");
static_assert(static_cast<int>(ActivationKind::Clip) == 3, "im2col_matmul.wgsl.template mirrors ActivationKind");
static_assert(static_cast<int>(ActivationKind::HardSigmoid) == 4, "im2col_matmul.wgsl.template mirrors ActivationKind");
static_assert(static_cast<int>(ActivationKind::LeakyRelu) == 5, "im2col_matmul.wgsl.template mirrors ActivationKind");
static_assert(static_cast<int>(ActivationKind::Tanh) == 6, "im2col_matmul.wgsl.template mirrors ActivationKind");
static_assert(static_cast<int>(ActivationKind::QuickGelu) == 7, "im2col_matmul.wgsl.template mirrors ActivationKind");

Status Im2ColMatMulProgram::GenerateShaderCode(ShaderHelper& shader) const {
  const auto& src = shader.AddInput("src", ShaderUsage::UseValueTypeAlias | ShaderUsage::UseElementTypeAlias);
  const auto& weight = shader.AddInput("weight", ShaderUsage::UseValueTypeAlias | ShaderUsage::UseElementTypeAlias);
  if (has_bias_) {
    shader.AddInput("bias", ShaderUsage::UseValueTypeAlias | ShaderUsage::UseElementTypeAlias);
  }
  const auto& output = shader.AddOutput("output", ShaderUsage::UseValueTypeAlias | ShaderUsage::UseElementTypeAlias);

  ORT_ENFORCE(tile_m_ == 16 || tile_m_ == 32, "tile_m must be 16 or 32.");
  ORT_ENFORCE(tile_n_ == 64, "tile_n must be 64.");
  ORT_ENFORCE(vec_size_ == 1 || vec_size_ == 2 || vec_size_ == 4, "vec_size must be 1, 2 or 4.");

  return WGSL_TEMPLATE_APPLY(shader, "nn/im2col_matmul.wgsl.template",
                             WGSL_TEMPLATE_PARAMETER(activation_kind, static_cast<uint32_t>(activation_.activation_kind_)),
                             WGSL_TEMPLATE_PARAMETER(has_bias, has_bias_),
                             // Alpha 1 selects the QuickGelu variant without the multiply or alpha uniform.
                             WGSL_TEMPLATE_PARAMETER(quick_gelu_unit_alpha, activation_.HasUnitQuickGeluAlpha()),
                             WGSL_TEMPLATE_PARAMETER(tile_m, tile_m_),
                             WGSL_TEMPLATE_PARAMETER(tile_n, tile_n_),
                             WGSL_TEMPLATE_PARAMETER(use_subgroup, use_subgroup_),
                             WGSL_TEMPLATE_PARAMETER(vec_size, vec_size_),
                             WGSL_TEMPLATE_VARIABLE(output, output),
                             WGSL_TEMPLATE_VARIABLE(src, src),
                             WGSL_TEMPLATE_VARIABLE(weight, weight));
}

Status ApplyIm2ColMatMulProgram(ComputeContext& context,
                                bool is_channels_last,
                                const Activation& activation,
                                const std::vector<uint32_t>& dilations,
                                const std::vector<uint32_t>& pads,
                                const std::vector<uint32_t>& strides,
                                const Tensor* packed_weight,
                                Tensor* output) {
  const auto* src = context.Input<Tensor>(0);
  const bool has_bias = context.InputCount() > 2;
  const auto* bias = has_bias ? context.Input<Tensor>(2) : nullptr;

  // The weight is expected in OHWI layout. Prefer the prepacked one; otherwise
  // transpose OIHW -> OHWI on the fly (e.g. when the weight is not an initializer).
  Tensor transposed_weight;
  const Tensor* ohwi_weight = packed_weight;
  if (ohwi_weight == nullptr) {
    const auto* weight = context.Input<Tensor>(1);
    ORT_RETURN_IF_ERROR(TransposeKernel(context, weight, weight->Shape(), &transposed_weight, OihwToOhwiPerm()));
    ohwi_weight = &transposed_weight;
  }

  const TensorShape& ohwi_shape = ohwi_weight->Shape();
  const uint32_t channel_output = onnxruntime::narrow<uint32_t>(ohwi_shape[0]);
  const uint32_t kernel_height = onnxruntime::narrow<uint32_t>(ohwi_shape[1]);
  const uint32_t kernel_width = onnxruntime::narrow<uint32_t>(ohwi_shape[2]);
  const uint32_t channel_input = onnxruntime::narrow<uint32_t>(ohwi_shape[3]);

  // im2col-matmul
  const TensorShape src_shape = src->Shape();
  const TensorShape output_shape = output->Shape();

  const uint32_t batch = onnxruntime::narrow<uint32_t>(src_shape[0]);
  const uint32_t src_height = onnxruntime::narrow<uint32_t>(src_shape[is_channels_last ? 1 : 2]);
  const uint32_t src_width = onnxruntime::narrow<uint32_t>(src_shape[is_channels_last ? 2 : 3]);
  const uint32_t output_height = onnxruntime::narrow<uint32_t>(output_shape[is_channels_last ? 1 : 2]);
  const uint32_t output_width = onnxruntime::narrow<uint32_t>(output_shape[is_channels_last ? 2 : 3]);

  const uint32_t im2col_m = output_height * output_width;
  const uint32_t im2col_k = kernel_height * kernel_width * channel_input;
  const uint32_t im2col_n = channel_output;

  const auto [tile_m, tile_n] = ChooseTileSize(im2col_m, im2col_n);
  const uint32_t workgroup_size = tile_n;

  // Check the device's subgroup size before shader compilation to avoid potential performance penalties
  // associated with conditional checks in the shader runtime.
  //
  // Ensure the subgroup size must be greater than or equal to `tile_m` to safely enable `use_subgroup`.
  // If the status of this condition is uncertain, the feature must be disabled.
  const bool use_subgroup = false;
  const uint32_t vec_size = channel_input % 4 == 0 ? 4 : (channel_input % 2 == 0 ? 2 : 1);
  Im2ColMatMulProgram im2col_mm_program{has_bias, tile_m, tile_n, vec_size, use_subgroup, activation};
  im2col_mm_program.SetWorkgroupSize(workgroup_size);

  const uint32_t M_tiles = CeilDiv(im2col_m, tile_m);
  const uint32_t N_tiles = CeilDiv(im2col_n, tile_n);
  im2col_mm_program.SetDispatchGroupSize(M_tiles, N_tiles, batch);

  im2col_mm_program.AddInput({src,
                              ProgramTensorMetadataDependency::TypeAndRank,
                              static_cast<int>(vec_size)});
  im2col_mm_program.AddInput({ohwi_weight,
                              ProgramTensorMetadataDependency::TypeAndRank,
                              static_cast<int>(vec_size)});
  if (has_bias) {
    im2col_mm_program.AddInput({bias,
                                ProgramTensorMetadataDependency::TypeAndRank});
  }
  im2col_mm_program.AddOutput({output,
                               ProgramTensorMetadataDependency::TypeAndRank});
  im2col_mm_program.AddUniformVariables({{batch},
                                         {src_height},
                                         {src_width},
                                         {channel_input},
                                         {kernel_height},
                                         {kernel_width},
                                         {output_height},
                                         {output_width},
                                         {im2col_m},
                                         {im2col_k},
                                         {im2col_n},
                                         {M_tiles},
                                         {N_tiles},
                                         {CeilDiv(CeilDiv(im2col_k, 4u), 4u)},
                                         {dilations},
                                         {pads},
                                         {strides}});
  AppendActivationUniformsData(activation, im2col_mm_program);
  im2col_mm_program.CacheHint(has_bias, tile_m, tile_n, vec_size, use_subgroup, activation.CacheKey());

  return context.RunProgram(im2col_mm_program);
}

bool CanApplyIm2ColMatMulProgram(ComputeContextBase& context,
                                 const bool is_channels_last,
                                 const Activation& activation,
                                 const TensorShape weight_shape,
                                 const uint32_t group,
                                 const MLDataType data_type) {
  if (!IsDeviceSupported(context)) {
    return false;
  }

  // The im2col-matmul kernel is performance-tuned for fp16. Use the default
  // conv path for fp32.
  if (data_type != DataTypeImpl::GetType<MLFloat16>()) {
    return false;
  }

  // TODO: Support !is_channels_last
  // TODO: Support group conv
  if (!is_channels_last || group != 1) {
    return false;
  }

  if (!IsActivationSupported(activation)) {
    return false;
  }

  // TODO: Support conv1d
  // TODO: Support conv2d_1x1
  const uint32_t kernel_height = onnxruntime::narrow<uint32_t>(weight_shape[2]);
  const uint32_t kernel_width = onnxruntime::narrow<uint32_t>(weight_shape[3]);
  if (kernel_height == 1 || kernel_width == 1) {
    return false;
  }

  return true;
}

}  // namespace webgpu
}  // namespace onnxruntime
