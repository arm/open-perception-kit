"""External-I/O and complete-GPU compute diagnostics, separate from full-model FPS."""
import json
from pathlib import Path
import threading
import batch

samples = []
stopped = threading.Event()
def monitor():
    while not stopped.is_set():
        samples.append(batch.hardware())
        stopped.wait(batch.SAMPLE_SECONDS)
thread = threading.Thread(target=monitor)
thread.start()
rows = []
try:
    for name in ('yolo26n-320', 'yolo26s-640'):
        full = batch.ROOT / 'models' / (name + '-fp32') / 'model.json'
        compute = batch.ROOT / 'compute-subgraphs' / name / 'model.json'
        cases = (('full-bound', 'gpu', full, 'bound', '0'),
                 ('compute-cpu', 'cpu', compute, 'host', '0'),
                 ('compute-gpu', 'gpu', compute, 'bound', '0'),
                 ('compute-captured', 'gpu', compute, 'bound', '1'))
        for case, provider, descriptor, io, capture in cases:
            label = f'resident-sync-{name}-{case}'
            batch.execute(provider, [str(batch.ROOT / 'diagnostic'), batch.RAW,
                                     str(descriptor), io, capture, 'disabled'], label)
            log = (batch.ROOT / 'evidence' / (label + '.log')).read_text()
            values = [json.loads(line) for line in log.splitlines() if line.startswith('{"frames":')]
            assert len(values) == 1
            row = values[0] | {'label': label, 'model': name, 'case': case}
            assert row['frames'] >= batch.MINIMUM_FOCUSED_FRAMES
            rows.append(row)
            (batch.ROOT / 'resident-results.json').write_text(json.dumps(rows, indent=2) + '\n')
            print(json.dumps(row), flush=True)
finally:
    stopped.set()
    thread.join()
    (batch.ROOT / 'hardware-resident.json').write_text(json.dumps(samples, indent=2) + '\n')
