#include "WebGpuProvider.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <numeric>
#include <vector>

int main(const int argc, const char *const *const argv) {
    constexpr int RequiredArgumentCount = 2;
    constexpr int CpuIntraThreads = 11;
    constexpr int CpuInterThreads = 1;
    constexpr float SmokeInputValue = 0.5F;
    constexpr size_t ProfileIterations = 10;
    try {
        if (argc != RequiredArgumentCount) {
            throw std::runtime_error("Usage: session-smoke model.onnx");
        }
        Ort::Env environment{ORT_LOGGING_LEVEL_INFO, "webgpu-smoke"};
        Ort::SessionOptions options;
        options.SetIntraOpNumThreads(CpuIntraThreads);
        options.SetInterOpNumThreads(CpuInterThreads);
        options.SetGraphOptimizationLevel(ORT_ENABLE_ALL);
        configureBenchmarkProvider(environment, options);
        Ort::Session session{environment, argv[1], options};
        if (session.GetInputCount() != 1) {
            throw std::runtime_error("Expected one image input");
        }
        const auto inputType = session.GetInputTypeInfo(0);
        const auto inputInfo = inputType.GetTensorTypeAndShapeInfo();
        const auto shape = inputInfo.GetShape();
        if (inputInfo.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT ||
            std::ranges::any_of(shape, [](const int64_t value) { return value <= 0; })) {
            throw std::runtime_error("Expected static FP32 input");
        }
        std::vector<float> input(inputInfo.GetElementCount(), SmokeInputValue);
        const auto memory = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
        auto tensor = Ort::Value::CreateTensor<float>(
            memory, input.data(), input.size(), shape.data(), shape.size());
        Ort::AllocatorWithDefaultOptions allocator;
        const auto inputName = session.GetInputNameAllocated(0, allocator);
        const std::array inputNames{inputName.get()};
        std::vector<Ort::AllocatedStringPtr> names;
        std::vector<const char *> outputNames;
        for (size_t index = 0; index < session.GetOutputCount(); ++index) {
            names.push_back(session.GetOutputNameAllocated(index, allocator));
            outputNames.push_back(names.back().get());
        }
        std::vector<Ort::Value> outputs;
        for (size_t iteration = 0; iteration < ProfileIterations; ++iteration) {
            const auto start = std::chrono::steady_clock::now();
            outputs = session.Run(Ort::RunOptions{nullptr},
                                  inputNames.data(),
                                  &tensor,
                                  inputNames.size(),
                                  outputNames.data(),
                                  outputNames.size());
            const auto milliseconds =
                std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start)
                    .count();
            std::cout << "Profile iteration " << iteration << " milliseconds: " << milliseconds
                      << '\n';
        }
        for (size_t index = 0; index < outputs.size(); ++index) {
            const auto count = outputs[index].GetTensorTypeAndShapeInfo().GetElementCount();
            const float *const data = outputs[index].GetTensorData<float>();
            if (!std::all_of(
                    data, data + count, [](const float value) { return std::isfinite(value); })) {
                throw std::runtime_error("Non-finite output");
            }
            std::cout << outputNames[index] << " values=" << count
                      << " sum=" << std::accumulate(data, data + count, 0.0) << '\n';
        }
        return 0;
    } catch (const std::exception &error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
