# OPK: DMA-BUF, Vulkan preprocessing and native ONNX GPU inference

Wednesday, 4 November 2026. About 90 seconds of overview, followed by 30 seconds for the results.

**Overview — approximately 90 seconds**

Originally, an OpChain prepared images, ran inference and interpreted results on the CPU. DMA-backed video also needed a bridge into CPU memory, so accessing pixels could introduce a copy before useful processing started.

DMA-BUF support now preserves the original video allocation. Deferred mapping means the CPU maps those pixels only when a stage needs them. Vulkan preprocessing adds a GPU implementation of resizing, colour conversion and normalization.

For inference, the experimental backend loads ONNX models through ONNX Runtime's native WebGPU provider. On this Linux board, Dawn executes the supported operations through Vulkan on the Mali GPU.

We tested YOLO26n and YOLO26s at 320, 480 and 640 pixels. Each CPU/GPU pair uses the identical FP32 ONNX file. The measured pipeline retains DMA-backed video, prepares the input on the CPU, runs inference, and parses the results on the CPU. GPU inference still crosses those tensor boundaries, and some detection-tail operations require CPU fallback.

We checked complete video processing and detection agreement, then measured inference separately. We also tested GPU-resident tensors and a compute-only subgraph with graph capture. Those checks distinguish transfer overhead from the cost of the GPU execution path itself.

**Results — final 30 seconds**

Populate from the completed video matrix. Show the six-case table, quote the smallest and largest cases, and state whether a crossover was observed. Label pipeline FPS as one complete-video pass and inference throughput as the median of three repetitions.
