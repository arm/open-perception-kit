"""Screen documented WebGPU settings on the smallest full YOLO model."""
import json
import sys
import threading
import time
import batch

MODE = sys.argv[1]
MODEL = 'yolo26s-640' if MODE == 'tune-large' else 'yolo26n-320'
original_directory = batch.ROOT / 'models' / (MODEL + '-fp32')
original_descriptor = json.loads((original_directory / 'model.json').read_text())
CASES = (
    ('baseline', 'fp32', {}),
    ('one-cpu-thread', 'fp32', {'OPK_ORT_SINGLE_THREAD': '1'}),
    ('nchw', 'fp32', {'OPK_ORT_LAYOUT': 'NCHW'}),
    ('submit-256', 'fp32', {'OPK_ORT_PENDING_DISPATCHES': '256'}),
    ('fp16', 'fp16', {}),
    ('system-driver', 'fp32', {'OPK_VULKAN_ICD': str(batch.ROOT / 'system-panfrost.json')}),
    ('combined', 'combined-fp32', {'OPK_ORT_REFERENCE_MODEL': str(original_directory / original_descriptor['modelFile'])}),
)
assert len({case[0] for case in CASES}) == len(CASES)
hardware_path = batch.ROOT / f'hardware-{MODE}.json'
samples = json.loads(hardware_path.read_text()) if hardware_path.exists() else []
stopped = threading.Event()
def monitor():
    while not stopped.is_set():
        samples.append(batch.hardware())
        stopped.wait(batch.SAMPLE_SECONDS)
thread = threading.Thread(target=monitor)
thread.start()
result_path = batch.ROOT / 'tuning-results.json'
rows = json.loads(result_path.read_text()) if result_path.exists() else []
try:
    for name, precision, settings in CASES:
        if MODE == 'tune-large' and name not in ('baseline', 'fp16', 'combined'):
            continue
        label = f'tune-{MODEL}-{name}'
        if any(row['label'] == label for row in rows):
            continue
        batch.ENVIRONMENT.update(settings)
        descriptor = batch.ROOT / 'models' / (MODEL + '-' + precision) / 'model.json'
        arguments = ([str(batch.ROOT / 'diagnostic'), batch.RAW, str(descriptor), 'host', '0', 'disabled']
                     if precision != 'fp16' else [str(batch.ROOT / 'focused'), batch.RAW, str(descriptor)])
        batch.execute('gpu', arguments, label)
        log = (batch.ROOT / 'evidence' / (label + '.log')).read_text()
        values = [json.loads(line) for line in log.splitlines() if line.startswith('{"frames":')]
        assert len(values) == 1
        row = values[0] | {'label': label, 'model': MODEL, 'precision': precision,
                           'settings': settings}
        assert row['frames'] >= batch.MINIMUM_FOCUSED_FRAMES
        rows.append(row)
        (batch.ROOT / 'tuning-results.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(json.dumps(row), flush=True)
        for key in settings:
            del batch.ENVIRONMENT[key]
        time.sleep(batch.COOLDOWN_SECONDS)
finally:
    stopped.set()
    thread.join()
    hardware_path.write_text(json.dumps(samples, indent=2) + '\n')
