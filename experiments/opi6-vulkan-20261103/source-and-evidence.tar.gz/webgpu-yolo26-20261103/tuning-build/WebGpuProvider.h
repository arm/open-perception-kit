#pragma once

#include <onnxruntime_cxx_api.h>

#include <array>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string_view>
#include <unordered_map>

inline void configureBenchmarkProvider(Ort::Env &environment, Ort::SessionOptions &options) {
    if (const char *const singleThread = std::getenv("OPK_ORT_SINGLE_THREAD")) {
        if (std::string_view{singleThread} != "1") {
            throw std::runtime_error("OPK_ORT_SINGLE_THREAD must be unset or 1");
        }
        constexpr int SingleThread = 1;
        options.SetIntraOpNumThreads(SingleThread);
    }
    if (const char *const profile = std::getenv("OPK_ORT_PROFILE")) {
        options.EnableProfiling(profile);
    }
    const char *const library = std::getenv("OPK_ORT_WEBGPU_LIBRARY");
    if (!library) {
        return;
    }
    if (!*library) {
        throw std::runtime_error("OPK_ORT_WEBGPU_LIBRARY cannot be empty");
    }
    environment.RegisterExecutionProviderLibrary("opk-webgpu", library);
    for (const auto &device : environment.GetEpDevices()) {
        if (std::strcmp(device.EpName(), "WebGpuExecutionProvider") != 0) {
            continue;
        }
        std::unordered_map<std::string, std::string> settings{{"preferredLayout", "NHWC"},
                                                              {"enableGraphCapture", "0"},
                                                              {"adapterIndex", "0"},
                                                              {"validationMode", "disabled"}};
        const std::array tuningOptions{
            std::pair{"OPK_ORT_LAYOUT", "preferredLayout"},
            std::pair{"OPK_ORT_PENDING_DISPATCHES", "maxNumPendingDispatches"},
            std::pair{"OPK_ORT_FP32_ACCUMULATION", "enableMatmulFp32Accumulation"}};
        for (const auto &[variable, option] : tuningOptions) {
            if (const char *const value = std::getenv(variable)) {
                if (!*value) {
                    throw std::runtime_error("Empty WebGPU tuning setting");
                }
                settings[option] = value;
                std::cerr << option << '=' << value << '\n';
            }
        }
        options.AppendExecutionProvider_V2(environment, {device}, settings);
        if (const char *const strict = std::getenv("OPK_ORT_REQUIRE_GPU")) {
            if (std::string_view{strict} != "1") {
                throw std::runtime_error("OPK_ORT_REQUIRE_GPU must be unset or 1");
            }
            options.AddConfigEntry("session.disable_cpu_ep_fallback", "1");
        }
        std::cerr << "Selected native WebGPU provider; verify the physical Dawn "
                     "adapter in its log\n";
        return;
    }
    throw std::runtime_error("Native WebGPU provider did not expose a selectable device");
}
